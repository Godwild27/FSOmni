# Système de Logs d'Événements - Page Settings

## ✅ Implémentation Terminée

### 1. **Système de Logs Réels**

#### Structure de Données (`AppState.LogEvent`)
```java
public static class LogEvent {
    public final String timestamp;  // Format "HH:mm:ss"
    public final String message;    // Message de l'événement
    public final LogLevel level;    // INFO, WARNING, ERROR, SUCCESS
}
```

#### Niveaux de Log
- **SUCCESS** (vert) : Événements réussis (connexion, TinyML activé)
- **INFO** (blanc) : Événements informatifs (déconnexion manuelle)
- **WARNING** (orange) : Avertissements
- **ERROR** (rouge) : Erreurs (connexion perdue)

#### Capacité
- Stocke les **100 derniers événements**
- Logs triés du plus récent au plus ancien
- Gestion automatique de la limite (FIFO)

### 2. **Événements Loggés Automatiquement**

| Événement | Message | Niveau |
|-----------|---------|--------|
| Démarrage app | "Démarrage système ESP32-S3 N16R8" | SUCCESS |
| Connexion WS | "Connexion WebSocket établie" | SUCCESS |
| Déconnexion manuelle | "Déconnexion manuelle" | INFO |
| Connexion perdue | "Connexion perdue (code XXX)" | ERROR |
| TinyML ON | "TinyML activé (Sens:XX%, React:XXXms)" | INFO |
| TinyML OFF | "TinyML désactivé (Sens:XX%, React:XXXms)" | INFO |

### 3. **Affichage dans Settings**

#### Zone Logs (4 derniers)
- Affiche les **4 événements les plus récents**
- Mise à jour automatique en temps réel
- Format : `HH:mm:ss  Message de l'événement`
- Couleur selon le niveau (vert/blanc/orange/rouge)
- Police monospace pour alignement
- Message par défaut si aucun log : "Aucun événement récent"

#### Bouton "Voir tous les logs"
- Ouvre un dialogue modal avec **tous les logs**
- Scrollable pour naviguer dans l'historique
- Titre : "Tous les journaux (X événements)"
- Bouton "Fermer" : Ferme le dialogue
- Bouton "Effacer tous" : Supprime tous les logs

### 4. **Interface Utilisateur**

#### Section Logs dans Settings
```
┌────────────────────────────────────────┐
│ 📋 JOURNAUX D'ÉVÉNEMENTS               │
│                                        │
│ 14:23:15  Connexion WebSocket établie  │ (vert)
│ 14:20:42  TinyML activé (Sens:75%...)  │ (blanc)
│ 14:18:30  Connexion perdue (code 1006) │ (rouge)
│ 14:15:00  Démarrage système ESP32...   │ (vert)
│                                        │
│ [Voir tous les logs]                   │
└────────────────────────────────────────┘
```

#### Dialogue "Tous les journaux"
```
┌─────────────────────────────────────────┐
│ Tous les journaux (12 événements)      │
│ ─────────────────────────────────────── │
│ 14:23:15  Connexion WebSocket établie   │
│ 14:20:42  TinyML activé (Sens:75%...)   │
│ 14:18:30  Connexion perdue (code 1006)  │
│ 14:15:00  Démarrage système ESP32...    │
│ 14:12:33  Déconnexion manuelle          │
│ ... (scrollable)                        │
│                                         │
│ [Effacer tous]           [Fermer]       │
└─────────────────────────────────────────┘
```

## 🔧 Fichiers Modifiés

### 1. `AppState.java`
**Ajouts** :
- Classe interne `LogEvent` avec `timestamp`, `message`, `level`
- `List<LogEvent> systemLogs` (max 100)
- `addLog(message, level)` : Ajouter un événement
- `getRecentLogs(count)` : Obtenir les N derniers logs
- `getAllLogs()` : Obtenir tous les logs
- `clearLogs()` : Effacer tous les logs

### 2. `FSOWebSocketClient.java`
**Modifications dans les callbacks** :
- `onOpen()` : Log "Connexion WebSocket établie" (SUCCESS)
- `onClose()` : Log "Connexion perdue" ou "Déconnexion manuelle" (ERROR/INFO)
- `sendTinymlCommand()` : Log "TinyML activé/désactivé" (INFO)

### 3. `MainActivity.java`
**Ajout dans `onCreate()`** :
- Log initial "Démarrage système ESP32-S3 N16R8" (SUCCESS)

### 4. `SettingsFragment.java`
**Ajouts** :
- Variable `logContainer` (LinearLayout dynamique)
- Méthode `updateLogDisplay()` : Affiche les 4 derniers logs
- Méthode `showAllLogsDialog()` : Ouvre le dialogue avec tous les logs
- Listener sur `"newLog"` : Met à jour l'affichage automatiquement
- Click listener sur `btn_view_logs`

### 5. `fragment_settings.xml`
**Modifications** :
- Suppression des 4 TextViews de logs fictifs
- Ajout `LinearLayout` avec `android:id="@+id/log_container"`
- Les logs sont maintenant ajoutés dynamiquement

## 📊 Flux de Données

### Ajout d'un Log
```
Événement système (connexion, TinyML, etc.)
           ↓
AppState.addLog(message, level)
           ↓
Création LogEvent avec timestamp
           ↓
Ajout à systemLogs (début de liste)
           ↓
Limitation à 100 logs max
           ↓
notifyChange("newLog", log)
           ↓
SettingsFragment listener
           ↓
updateLogDisplay()
           ↓
UI mise à jour (4 derniers logs visibles)
```

### Affichage "Voir tous les logs"
```
User clique "Voir tous les logs"
           ↓
showAllLogsDialog()
           ↓
appState.getAllLogs()
           ↓
Création ScrollView + LinearLayout
           ↓
Ajout de tous les logs (TextView)
           ↓
Affichage AlertDialog modal
           ↓
Options: Fermer / Effacer tous
```

## 🎨 Couleurs par Niveau

| Niveau | Couleur | Ressource | Exemple |
|--------|---------|-----------|---------|
| SUCCESS | Vert | `R.color.tertiary` | Connexion établie |
| INFO | Blanc | `R.color.on_surface` | TinyML activé |
| WARNING | Orange | `R.color.primary` | Avertissements |
| ERROR | Rouge | `R.color.error` | Connexion perdue |

## 🧪 Tests

### Test 1 : Logs Automatiques
1. Démarrer l'app → Voir "Démarrage système ESP32..."
2. Se connecter → Voir "Connexion WebSocket établie" (vert)
3. Se déconnecter → Voir "Déconnexion manuelle" (blanc)
4. Perdre la connexion → Voir "Connexion perdue (code XXX)" (rouge)

### Test 2 : TinyML Logs
1. Aller dans Settings
2. Activer TinyML → Voir log "TinyML activé (Sens:75%, React:150ms)"
3. Modifier sensibilité/réactivité → Pas de nouveau log
4. Désactiver TinyML → Voir log "TinyML désactivé (...)"

### Test 3 : Affichage Dynamique
1. Ouvrir Settings → Voir les 4 derniers logs
2. Générer un nouvel événement (connexion) → Le nouveau log apparaît en premier
3. Vérifier que les couleurs correspondent aux niveaux

### Test 4 : Dialogue "Tous les logs"
1. Cliquer "Voir tous les logs" → Dialogue s'ouvre
2. Scroller vers le bas → Voir tous les événements historiques
3. Cliquer "Effacer tous" → Dialogue se ferme, logs effacés
4. Revenir sur Settings → Voir "Aucun événement récent"
5. Générer un événement → Le log réapparaît

### Test 5 : Limite 100 Logs
1. Générer plus de 100 événements (connexion/déconnexion répétées)
2. Cliquer "Voir tous les logs"
3. Vérifier qu'il n'y a que 100 logs maximum
4. Les plus anciens sont supprimés automatiquement

## 📝 Exemples de Logs Réels

```
14:23:15  Connexion WebSocket établie
14:20:42  TinyML activé (Sens:75%, React:150ms)
14:18:30  Connexion perdue (code 1006)
14:15:00  Démarrage système ESP32-S3 N16R8
14:12:33  Déconnexion manuelle
14:10:20  TinyML désactivé (Sens:50%, React:200ms)
14:08:15  Connexion WebSocket établie
14:05:00  Démarrage système ESP32-S3 N16R8
```

## 🔄 Améliorations Futures (Non Implémentées)

### Logs Supplémentaires à Ajouter
- Changement de débit (bitrate)
- Réalignement automatique TinyML
- Détection de brouillard/nuages (atténuation élevée)
- Réception/envoi de messages laser
- Réception/envoi de fichiers
- Erreurs de transmission
- Changements de paramètres sensibilité/réactivité

### Persistance
- Sauvegarder les logs dans SharedPreferences
- Charger au démarrage de l'app
- Garder l'historique entre les sessions

### Export
- Bouton "Exporter" dans le dialogue
- Générer un fichier texte avec tous les logs
- Partager via Android Share Sheet

### Filtres
- Filtrer par niveau (SUCCESS, INFO, ERROR)
- Filtrer par période (dernière heure, aujourd'hui, 7 jours)
- Recherche par mot-clé
