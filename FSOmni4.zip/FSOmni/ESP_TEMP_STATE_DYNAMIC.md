# Température et État ESP32 Dynamiques

## ✅ Implémentation Terminée

### 1. **Température ESP32 Dynamique**

#### Calcul Basé sur la Température Ambiante
La température de l'ESP32 est maintenant calculée automatiquement à partir de la température ambiante du Dashboard :

**Formule** :
```
Temp_ESP32 = Temp_Ambiante + Offset + Variation

Où :
- Offset = 12-15°C (aléatoire)
- Variation = -1 à +1°C (aléatoire)
```

#### Plages de Valeurs
- **Température ambiante** : 15-35°C (typique)
- **Température ESP32** : 30-85°C (limité automatiquement)
- **Offset typique** : +12-15°C au-dessus de l'ambiante
- **Exemple** : Si ambiante = 25°C → ESP32 = 37-41°C

#### Mise à Jour
- Recalculée automatiquement quand la température ambiante change
- Recalculée toutes les secondes avec légère variation
- Affichage : "42°C" (sans décimales)

### 2. **État ESP32 Oscillant**

#### Comportement
L'état de l'ESP32 **oscille entre deux valeurs** toutes les **8 secondes** :

**État Élevé (8 secondes)** :
- Valeur : 88-92%
- Couleur : Normale

**État Bas (8 secondes)** :
- Valeur : 80-85%
- Couleur : Normale

**Cycle** : Élevé → Bas → Élevé → Bas → ...

#### Logique Interne
```java
if (8 secondes écoulées) {
    Basculer état (haut ↔ bas)
    
    if (État haut) {
        espEtat = 88 + random(0-4)  // 88-92%
    } else {
        espEtat = 80 + random(0-5)  // 80-85%
    }
}
```

#### Mise à Jour
- Vérification toutes les secondes
- Bascule automatique toutes les 8 secondes
- Transition visible dans l'interface
- Affichage : "88%" (sans décimales)

## 📊 Comparaison Dashboard vs Settings

### Température

| Localisation | Source | Exemple |
|--------------|--------|---------|
| **Dashboard** | Capteur BMP280/BMP180 | 25.0°C |
| **Settings (ESP32)** | Calculée (Ambiante + 12-15°C) | 38°C |

**Relation** : `Temp_ESP = Temp_Dashboard + 12-15°C`

### État ESP32

| Moment | Valeur | Graphique |
|--------|--------|-----------|
| 0-8s | 88-92% | ████████████░░░░ |
| 8-16s | 80-85% | ██████████░░░░░░ |
| 16-24s | 88-92% | ████████████░░░░ |
| 24-32s | 80-85% | ██████████░░░░░░ |

## 🔧 Fichiers Modifiés

### 1. `AppState.java`

**Ajouts de variables** :
```java
private boolean espEtatHighState = true;
private long lastEspEtatToggle = 0;
private static final long ESP_ETAT_TOGGLE_INTERVAL = 8000; // 8s
```

**Méthodes ajoutées** :
- `calculateEspTemperature()` : Calcule température ESP basée sur ambiante
- `updateEspEtat()` : Met à jour l'état avec oscillation 8 secondes

**Modifications** :
- `setEspTemp()` et `setEspEtat()` conservés pour compatibilité

### 2. `FSOWebSocketClient.java`

**Modification dans `processMessage()` "sensors"** :
```java
if (json.has("temperature")) {
    appState.setLastTemperature(json.get("temperature").getAsDouble());
    appState.calculateEspTemperature(); // ← Nouveau
}
```

### 3. `SettingsFragment.java`

**Ajout de variable** :
```java
private Runnable espStateUpdateRunnable;
```

**Méthodes ajoutées** :
- `startEspStateUpdater()` : Démarre le timer (1s)
- `stopEspStateUpdater()` : Arrête le timer

**Appels dans lifecycle** :
- `onCreateView()` : Appelle `startEspStateUpdater()`
- `onPause()` : Appelle `stopEspStateUpdater()`
- `onDestroy()` : Appelle `stopEspStateUpdater()`

**Logique du timer** :
```java
Toutes les 1 seconde :
  - appState.updateEspEtat()      // Vérifie les 8s
  - appState.calculateEspTemperature() // Légère variation
```

## 🔄 Flux de Données

### Température ESP32
```
Arduino (BMP280/BMP180) → ESP32 → WebSocket
                                      ↓
                          Temp ambiante reçue (ex: 25°C)
                                      ↓
                   AppState.setLastTemperature(25)
                                      ↓
                   AppState.calculateEspTemperature()
                                      ↓
           Temp_ESP = 25 + (12-15) + (-1 à +1) = 37-41°C
                                      ↓
                          notifyChange("espTemp")
                                      ↓
                          SettingsFragment listener
                                      ↓
                          espTempValue.setText("38°C")
```

### État ESP32
```
Timer (toutes les 1s) → SettingsFragment
                              ↓
                   appState.updateEspEtat()
                              ↓
                   Vérifier si 8s écoulées
                              ↓
              OUI → Basculer espEtatHighState
                   État haut ? 88-92% : 80-85%
                              ↓
                   notifyChange("espEtat")
                              ↓
                   SettingsFragment listener
                              ↓
                   espEtatValue.setText("88%")
                   Barre de progression mise à jour
```

## 📱 Interface Utilisateur

### État de l'ESP32 (Settings)
```
┌────────────────────────────────────┐
│ État de l'ESP32-S3 N16R8           │
│                                    │
│ Température          État          │
│    38°C              88%           │
│ ████████░░           ████████████  │
│                                    │
│ (T = Ambiante + 13°C) (Oscillant)  │
└────────────────────────────────────┘
```

### Évolution dans le Temps
```
Seconde  Temp ESP   État ESP
0        38°C       88%    (État haut)
1        38°C       90%    (État haut)
4        39°C       89%    (État haut)
8        38°C       82%    (Bascule → État bas)
12       37°C       84%    (État bas)
16       38°C       90%    (Bascule → État haut)
20       39°C       88%    (État haut)
```

## 🧪 Tests

### Test 1 : Température Liée à l'Ambiante
1. Observer Dashboard → Temp ambiante = 25°C
2. Aller sur Settings → Temp ESP ≈ 37-40°C (supérieure de 12-15°C)
3. Simuler changement de temp ambiante → 30°C
4. Settings → Temp ESP ≈ 42-45°C (suit le changement)

### Test 2 : Variation de la Température ESP
1. Ouvrir Settings
2. Observer Temp ESP : 38°C
3. Attendre quelques secondes
4. Temp ESP varie légèrement : 37°C, 39°C, 38°C...
5. Variation reste dans la plage (ne saute pas brutalement)

### Test 3 : Oscillation État ESP (8 secondes)
1. Ouvrir Settings
2. Noter l'état initial : 88%
3. Démarrer un chronomètre
4. À 8 secondes → État descend à ~82%
5. À 16 secondes → État remonte à ~90%
6. À 24 secondes → État redescend à ~84%
7. Le cycle continue indéfiniment

### Test 4 : Barres de Progression
1. Observer la barre Température
2. Largeur proportionnelle à la valeur (38% de largeur pour 38°C)
3. Observer la barre État
4. Largeur change quand l'état oscille (88% puis 82%)

### Test 5 : Persistance Entre Pages
1. Aller sur Settings → Noter Temp ESP et État
2. Aller sur Dashboard (autre page)
3. Revenir sur Settings
4. Valeurs continuent d'évoluer (pas de reset)

## 📊 Exemples de Valeurs Réelles

### Scénario 1 : Intérieur Tempéré
- Temp ambiante : 22°C
- Temp ESP32 : 34-37°C
- État ESP : Oscille 88-92% ↔ 80-85%

### Scénario 2 : Extérieur Chaud
- Temp ambiante : 35°C
- Temp ESP32 : 47-50°C
- État ESP : Oscille 88-92% ↔ 80-85%

### Scénario 3 : Extérieur Froid
- Temp ambiante : 5°C
- Temp ESP32 : 30°C (limité au minimum)
- État ESP : Oscille 88-92% ↔ 80-85%

## 📝 Notes Techniques

### Température ESP32
- **Réalisme** : ESP32 chauffe typiquement de 10-20°C au-dessus de l'ambiante
- **Offset variable** : Simule charge CPU variable (12-15°C)
- **Variation** : Simule fluctuations thermiques normales (-1 à +1°C)
- **Limites** : 30°C min (protection), 85°C max (seuil critique)

### État ESP32
- **88-92%** : État nominal (système stable, charge normale)
- **80-85%** : État sous charge (traitement, transmission, etc.)
- **Oscillation** : Simule activité périodique du système
- **8 secondes** : Période réaliste pour cycles de travail

### Différence avec Dashboard
- **Dashboard Temp** : Température environnementale (capteur externe)
- **Settings Temp** : Température interne ESP32 (calculée)
- Relation logique : ESP32 plus chaud car génère de la chaleur

## 🔮 Améliorations Futures (Non Implémentées)

### Température ESP Avancée
- Lier à la charge CPU simulée (TinyML actif = +2°C)
- Lier au débit de transmission (TX active = +3°C)
- Refroidissement progressif après pic de charge

### État ESP Avancé
- Lier à l'activité réelle (transmission = état bas)
- Afficher pourcentage CPU/RAM au lieu de "état"
- Logs quand l'état descend sous 75% (surcharge)
