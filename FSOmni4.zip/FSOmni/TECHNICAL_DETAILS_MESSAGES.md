# 🔬 Détails Techniques - Système de Messagerie FSO

## 📡 PROTOCOLE DE COMMUNICATION

### Format des Messages

#### Android → ESP32 (WebSocket)
```json
{
  "type": 2,
  "text": "Bonjour",
  "length": 7,
  "unit_id": 1
}
```

#### ESP32 → ESP32 (ESP-NOW)
```c
struct EspNowPacket {
  uint8_t  type;           // 0 = ESPNOW_MSG_TEXT
  uint16_t seq;            // Numéro de séquence
  uint16_t total_len;      // 7 (longueur du texte)
  uint16_t chunk_offset;   // 0 (pas fragmenté)
  uint8_t  unit_id;        // 1 (émetteur)
  uint8_t  reserved;       // 0
  uint8_t  payload[230];   // "Bonjour" + padding
};
// Total: 239 bytes (max ESP-NOW = 250 bytes)
```

#### ESP32 → Android (WebSocket)
```json
{
  "type": 2,
  "text": "Bonjour",
  "unit_id": 1,
  "length": 7
}
```

---

## ⚡ FLUX DE DONNÉES COMPLET

### Envoi d'un Message (Unité 1 → Unité 2)

```
┌─────────────────────────────────────────────────────────────────┐
│ PHASE 1 : ANDROID 1 → ESP32-1                                   │
└─────────────────────────────────────────────────────────────────┘

1. Utilisateur tape "Bonjour" dans TransferFragment
   └─> sendMessage() appelé

2. TransferFragment.sendMessage()
   ├─> Crée ChatMessage OUTGOING
   ├─> Ajoute au chatAdapter (affichage local)
   └─> Appelle wsClient.sendTextMessage("Bonjour")

3. FSOWebSocketClient.sendTextMessage()
   ├─> Construit JsonObject avec type=2, text, length
   ├─> Ajoute unit_id = appState.getMyUnitId() (= 1)
   └─> Envoie via WebSocket ws://192.168.4.1:8080

4. WebSocket TCP/IP over WiFi "FSOmni_1"
   └─> Paquet JSON arrive à l'ESP32-1

┌─────────────────────────────────────────────────────────────────┐
│ PHASE 2 : ESP32-1 TRAITEMENT                                    │
└─────────────────────────────────────────────────────────────────┘

5. websocket_handler.cpp : onWsEvent()
   ├─> Reçoit {"type":2,"text":"Bonjour","unit_id":1,"length":7}
   ├─> Extrait text = "Bonjour", unitId = 1
   └─> Continue au traitement type 2

6. Activation des lasers
   └─> laserGateTxStart((uint8_t*)"Bonjour", 7)
       └─> Timer Manchester démarre (10 Hz)
       └─> GPIO 4, 5, 6 → HIGH/LOW en alternance
       └─> 💡💡💡 Lasers clignotent ~0.7 seconde

7. Envoi ESP-NOW
   └─> espNowSend((uint8_t*)"Bonjour", 7, ESPNOW_MSG_TEXT, 1)
       ├─> Construit EspNowPacket
       │   ├─> type = 0 (ESPNOW_MSG_TEXT)
       │   ├─> seq = compteur++
       │   ├─> total_len = 7
       │   ├─> chunk_offset = 0
       │   ├─> unit_id = 1  ← IMPORTANT
       │   └─> payload = "Bonjour\0\0..."
       └─> esp_now_send(peerMac, &packet, 239)
           └─> Transmission radio 2.4 GHz vers MAC 44:1B:F6:FF:AB:88

8. Réponse à Android
   └─> ws.textAll("{\"type\":10,\"status\":\"tx_started\"}")

9. Désactivation des lasers
   └─> laserGateTxStop()
       └─> GPIO 4, 5, 6 → LOW
       └─> Lasers éteints

┌─────────────────────────────────────────────────────────────────┐
│ PHASE 3 : ESP32-2 RÉCEPTION                                     │
└─────────────────────────────────────────────────────────────────┘

10. espnow_link.cpp : onEspNowRecv()
    ├─> Reçoit paquet ESP-NOW depuis MAC 44:1B:F6:FF:B0:F0
    ├─> Vérifie que MAC = peer (sécurité)
    ├─> Copie paquet dans structure locale
    └─> Appelle callback onEspNowRx(pkt)

11. esp32_fso_gate.ino : onEspNowRx()
    ├─> Vérifie type = 0 (ESPNOW_MSG_TEXT)
    ├─> Vérifie laserGateIsOpen() → DOIT ÊTRE TRUE
    │   ├─> Si FALSE → paquet IGNORÉ silencieusement
    │   └─> Si TRUE → continue
    ├─> Extrait text = "Bonjour" depuis payload
    ├─> Extrait unitId = 1  ← IMPORTANT
    └─> Appelle broadcastLaserRx("Bonjour", 1)

12. websocket_handler.cpp : broadcastLaserRx()
    ├─> Construit JsonObject
    │   ├─> type = 2
    │   ├─> text = "Bonjour"
    │   ├─> unit_id = 1  ← Transmis depuis paquet ESP-NOW
    │   └─> length = 7
    └─> ws.textAll(json)
        └─> Broadcast à tous les clients WebSocket connectés

┌─────────────────────────────────────────────────────────────────┐
│ PHASE 4 : ANDROID 2 AFFICHAGE                                   │
└─────────────────────────────────────────────────────────────────┘

13. FSOWebSocketClient : listener type "2"
    ├─> Reçoit {"type":2,"text":"Bonjour","unit_id":1,"length":7}
    ├─> Extrait text = "Bonjour"
    ├─> Extrait unitId = 1
    └─> Détermine senderName = "Unité 1"  ← Formatage

14. TransferFragment.onCreate() listener
    ├─> Crée ChatMessage
    │   ├─> type = INCOMING
    │   ├─> sender = "Unité 1"  ← Nom formaté
    │   ├─> text = "Bonjour"
    │   └─> time = "16:23"
    └─> handler.post(() -> chatAdapter.addMessage(msg))

15. ChatMessageAdapter
    ├─> Ajoute message à la liste
    ├─> notifyDataSetChanged()
    ├─> Sauvegarde automatique dans SharedPreferences
    └─> RecyclerView met à jour l'UI

16. Affichage final dans RecyclerView
    └─> Bulle grise à gauche
        ├─> Header: "[Unité 1] 16:23"
        └─> Contenu: "Bonjour"
```

**Temps total** : ~100ms (très rapide!)

---

## 💡 SYSTÈME LASER GATE

### Fonctionnement du Gate

Le **gate laser** est un mécanisme de validation de la ligne de vue optique.

#### Côté TX (Émetteur)

**Matériel**:
- 3 lasers KY-008 (650nm, 5mW) sur GPIO 4, 5, 6
- Clignotent en **Manchester** pendant la transmission

**Manchester** :
- Bit 1 → HAUT puis BAS (transition descendante au milieu)
- Bit 0 → BAS puis HAUT (transition montante au milieu)
- Fréquence : **10 Hz** (100ms/bit, visible à l'œil)

**Exemple** : "Bonjour" = 7 bytes = 56 bits = 5.6 secondes si on transmettait vraiment les données

**Mais** : On NE transmet PAS vraiment les données via laser, juste un motif visible.

#### Côté RX (Récepteur)

**Matériel**:
- 3 photodiodes sur GPIO 7, 8, 9
- Détection de fronts montants (lumière apparaît)

**Logique**:
```c
if (n'importe quelle photodiode détecte un flash) {
  lastPulseTime = millis();
}

bool gateOpen = (millis() - lastPulseTime < 1000ms);
```

**Gate OUVERT** : Au moins un flash détecté dans la dernière seconde  
**Gate FERMÉ** : Aucun flash depuis plus d'une seconde

#### Validation des Messages

```c
void onEspNowRx(const EspNowPacket* pkt) {
  // Vérifier le gate AVANT de traiter
  if (!laserGateIsOpen()) {
    Serial.println("⚠️ Gate FERME → paquet ignore");
    return;  // ← MESSAGE IGNORÉ
  }
  
  // Gate OUVERT → traiter normalement
  broadcastLaserRx(text, unitId);
}
```

**Sécurité** : Même si un paquet ESP-NOW est reçu (radio 2.4 GHz), si la ligne de vue laser est bloquée, le message est **rejeté**.

---

## 🔐 LED DE CONNEXION (GPIO 15)

### Principe

La LED indique l'état de la connexion **ESP-NOW** entre les deux unités.

#### Heartbeat

```c
// Toutes les 1 seconde
void espNowSendHeartbeat() {
  EspNowPacket pkt;
  pkt.type = ESPNOW_MSG_HEARTBEAT;  // Type 7
  pkt.total_len = 0;  // Paquet vide
  espNowSendPacket(&pkt);
}
```

**But** : Maintenir une activité ESP-NOW même sans message utilisateur.

#### Détection de Connexion

```c
void espNowUpdateConnectionLed() {
  unsigned long now = millis();
  
  // Activité récente = RX ou TX dans les 3 dernières secondes
  bool connected = (now - lastRxTime < 3000) || 
                   (now - lastTxTime < 3000);
  
  // Mettre à jour LED
  digitalWrite(connectionLedPin, connected ? HIGH : LOW);
}
```

**États** :
- **LED ON** : Heartbeats reçus, connexion active
- **LED OFF** : Aucune activité ESP-NOW depuis 3+ secondes

**Appel** : Dans le `loop()` principal, toutes les ~50ms

---

## 📦 FRAGMENTATION DES MESSAGES

### Limite ESP-NOW

- **Max par paquet** : 250 bytes
- **Header** : 18 bytes (type, seq, total_len, chunk_offset, unit_id, reserved)
- **Payload disponible** : 230 bytes

### Messages Courts (< 230 bytes)

**Exemple** : "Bonjour" (7 bytes)

```c
EspNowPacket pkt;
pkt.type = ESPNOW_MSG_TEXT;
pkt.seq = 42;
pkt.total_len = 7;
pkt.chunk_offset = 0;
pkt.unit_id = 1;
memcpy(pkt.payload, "Bonjour", 7);

espNowSendPacket(&pkt);  // 1 seul paquet
```

### Messages Longs (≥ 230 bytes)

**Exemple** : Message de 500 bytes

```
Chunk 1: offset=0,   len=230  →  bytes 0-229
Chunk 2: offset=230, len=230  →  bytes 230-459
Chunk 3: offset=460, len=40   →  bytes 460-499

Total : 3 paquets ESP-NOW
```

**Code** :
```c
bool espNowSendFragmented(const uint8_t* data, size_t len, ...) {
  uint16_t offset = 0;
  while (offset < len) {
    uint16_t chunkLen = min(len - offset, 230);
    
    EspNowPacket pkt;
    pkt.type = type;
    pkt.seq = nextSeq++;
    pkt.total_len = len;
    pkt.chunk_offset = offset;
    pkt.unit_id = unitId;
    memcpy(pkt.payload, data + offset, chunkLen);
    
    espNowSendPacket(&pkt);
    delay(2);  // Anti-flood
    
    offset += chunkLen;
  }
}
```

**Réassemblage** : À implémenter côté réception (buffer + numéro de séquence)

---

## 💾 PERSISTANCE DES MESSAGES

### Sérialisation JSON

**ChatMessage → JSON** :
```java
public JsonObject toJson() {
  JsonObject json = new JsonObject();
  json.addProperty("type", type.name());        // "INCOMING" ou "OUTGOING"
  json.addProperty("sender", sender);           // "Unité 1"
  json.addProperty("text", text);               // "Bonjour"
  json.addProperty("time", time);               // "16:23"
  json.addProperty("senderId", senderId);       // null ou ID
  return json;
}
```

**JSON → ChatMessage** :
```java
public static ChatMessage fromJson(JsonObject json) {
  MessageType type = MessageType.valueOf(json.get("type").getAsString());
  String sender = json.has("sender") ? json.get("sender").getAsString() : null;
  String text = json.get("text").getAsString();
  String time = json.get("time").getAsString();
  
  ChatMessage msg = new ChatMessage(type, sender, text, time);
  // ...
  return msg;
}
```

### Sauvegarde Automatique

**Déclencheur** : Chaque fois qu'un message est ajouté ou supprimé

```java
chatAdapter.setSaveCallback(() -> {
  if (appState != null && getContext() != null) {
    appState.saveChatMessages(chatAdapter.getMessages(), getContext());
  }
});
```

**Implémentation** :
```java
public void saveChatMessages(List<ChatMessage> messages, Context ctx) {
  JsonArray jsonArray = new JsonArray();
  
  // Limiter à 200 messages max
  int startIdx = Math.max(0, messages.size() - 200);
  for (int i = startIdx; i < messages.size(); i++) {
    jsonArray.add(messages.get(i).toJson());
  }
  
  // Sauvegarder dans SharedPreferences
  SharedPreferences prefs = ctx.getSharedPreferences("FSOmni", Context.MODE_PRIVATE);
  prefs.edit()
       .putString("chat_messages", jsonArray.toString())
       .apply();
}
```

### Chargement au Démarrage

```java
public List<ChatMessage> loadChatMessages(Context ctx) {
  List<ChatMessage> messages = new ArrayList<>();
  
  SharedPreferences prefs = ctx.getSharedPreferences("FSOmni", Context.MODE_PRIVATE);
  String json = prefs.getString("chat_messages", "[]");
  
  JsonArray jsonArray = JsonParser.parseString(json).getAsJsonArray();
  for (int i = 0; i < jsonArray.size(); i++) {
    messages.add(ChatMessage.fromJson(jsonArray.get(i).getAsJsonObject()));
  }
  
  return messages;
}
```

---

## 🔄 SERVICE D'ARRIÈRE-PLAN

### Lifecycle

```
App ouvre
  └─> MainActivity.onCreate()
      └─> listenForConnectionChanges()
          └─> Si connected=true → startBackgroundService()

startBackgroundService()
  └─> Intent(FSOBackgroundService.class)
      └─> startForegroundService() (Android 8+)
          └─> Service démarre
              └─> onCreate()
                  └─> startForeground(notification)

App passe en arrière-plan
  └─> onPause() / onStop()
      └─> Service CONTINUE en foreground
          └─> WebSocket reste CONNECTÉ

Utilisateur clique "Déconnecter" dans notification
  └─> PendingIntent → FSOBackgroundService
      └─> onStartCommand(action=STOP_SERVICE)
          └─> wsClient.disconnect()
          └─> stopSelf()
              └─> Service arrêté
```

### Notification Persistante

**Obligation Android 8+** : Service foreground DOIT avoir une notification

```java
Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
  .setContentTitle("FSOmni connecté")
  .setContentText("Liaison laser active - Transfert en cours")
  .setSmallIcon(R.drawable.ic_notification)
  .setOngoing(true)  // Impossible de swiper pour fermer
  .addAction(R.drawable.ic_stop, "Déconnecter", stopPendingIntent)
  .build();

startForeground(NOTIFICATION_ID, notification);
```

---

## 📊 STATISTIQUES ET MONITORING

### Métriques ESP-NOW

```c
uint32_t espNowGetTxCount();   // Paquets envoyés
uint32_t espNowGetRxCount();   // Paquets reçus
uint32_t espNowGetTxErrors();  // Erreurs d'envoi
uint32_t espNowGetRxErrors();  // Paquets malformés
```

### Métriques Laser Gate

```c
uint32_t laserGateGetPulseCount();   // Flashs détectés
uint32_t laserGateGetOpenCount();    // Fois gate ouvert
uint32_t laserGateGetCloseCount();   // Fois gate fermé
```

### Commande Stats WebSocket

Android peut demander les stats :
```json
{"type": "stats"}
```

Réponse :
```json
{
  "type": "stats",
  "unit_id": 1,
  "gate_open": true,
  "last_pulse_ms": 234,
  "pulse_count": 1523,
  "espnow_tx": 842,
  "espnow_rx": 839,
  "espnow_tx_errors": 0,
  "espnow_rx_errors": 1
}
```

---

## 🔬 DEBUGGING

### Logs Serial Monitor

**Niveau INFO** :
```
[ESP-NOW] Init OK  Peer=...
[WS] Client connecte [ID:1] 192.168.4.2
[ESP-NOW RX] Texte de Unité 1: "Bonjour"
```

**Niveau WARNING** :
```
[ESP-NOW RX] ⚠️ Gate FERME → paquet ignore
```

**Niveau ERROR** :
```
[ESP-NOW] ❌ send erreur : ESP_ERR_ESPNOW_NOT_INIT
```

### Logs Android (Logcat)

**Tag** : `FSOWebSocket`

```
D/FSOWebSocket: 📤 Message texte laser envoyé : {"type":2,"text":"Bonjour","unit_id":1,"length":7}
D/FSOWebSocket: 📩 Message laser reçu : Bonjour
```

---

## 🎯 OPTIMISATIONS POSSIBLES

### 1. Compression de Texte

Pour messages longs, utiliser compression zlib/gzip :
```c
// Avant envoi
uint8_t compressed[1024];
size_t compLen = compress(text, len, compressed);
espNowSend(compressed, compLen, ESPNOW_MSG_TEXT_COMPRESSED, unitId);

// Après réception
uint8_t decompressed[4096];
size_t decompLen = decompress(payload, len, decompressed);
```

**Gain** : ~60% sur texte répétitif

### 2. ACK / Retry

Actuellement, pas de confirmation de réception. Possibilité d'ajouter :
```c
// Émetteur envoie msg avec seq=42
// Récepteur répond ACK seq=42
// Si pas d'ACK après 500ms → retransmission
```

**Gain** : Fiabilité 99.9%+

### 3. Rate Limiting

Limiter à X messages/seconde pour éviter spam :
```java
private long lastSendTime = 0;
private static final long MIN_SEND_INTERVAL_MS = 100;

if (System.currentTimeMillis() - lastSendTime < MIN_SEND_INTERVAL_MS) {
  Toast.makeText(context, "Trop rapide!", Toast.LENGTH_SHORT).show();
  return;
}
```

---

*Documentation technique générée le 2026-07-08*  
*FSOmni V3.0 - ESP-NOW + Laser Gate*
