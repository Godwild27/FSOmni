// ================================================================
// sensors.cpp — Capteurs I2C AUTO-DÉTECTION (BMP280/BMP180 + BH1750/LDR)
// ================================================================

#include "sensors.h"
#include "config.h"
#include <Wire.h>

SensorData currentSensorData = {
  25.0, 1013.25, 0.0, 5000.0,
  0.0, 0.0, 1.0,
  0.0, 0.0, 0.0,
  0.0, 0.0,
  false, 0
};

// Adresses I2C
#define BMP280_ADDR 0x76
#define BMP180_ADDR 0x77
#define BH1750_ADDR 0x23
#define MPU6050_ADDR 0x68

// Type de capteur détecté
enum SensorType { NONE, BMP280, BMP180, BH1750, LDR, MPU6050 };

SensorType bmpType = NONE;
SensorType luxType = NONE;
bool mpuActive = false;

// LDR sur broche analogique A0
#define LDR_PIN A0

// ================================================================
// I2C Helpers
// ================================================================
void i2cWrite(uint8_t addr, uint8_t reg, uint8_t val) {
  Wire.beginTransmission(addr);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();
}

uint8_t i2cRead8(uint8_t addr, uint8_t reg) {
  Wire.beginTransmission(addr);
  Wire.write(reg);
  Wire.endTransmission();
  Wire.requestFrom(addr, (uint8_t)1);
  return Wire.read();
}

bool i2cExists(uint8_t addr) {
  Wire.beginTransmission(addr);
  return (Wire.endTransmission() == 0);
}

// ================================================================
// INIT AUTO-DETECTION
// ================================================================
void initSensors() {
  Wire.begin();
  Wire.setClock(100000);
  delay(50);

  // Auto-détection BMP280 ou BMP180
  if (i2cExists(BMP280_ADDR)) {
    uint8_t id = i2cRead8(BMP280_ADDR, 0xD0);
    if (id == 0x58) {
      bmpType = BMP280;
      i2cWrite(BMP280_ADDR, 0xF4, 0x27);
      i2cWrite(BMP280_ADDR, 0xF5, 0xA0);
    }
  } else if (i2cExists(BMP180_ADDR)) {
    bmpType = BMP180;
    i2cWrite(BMP180_ADDR, 0xF4, 0x2E); // Start temp conversion
  }

  // Auto-détection BH1750 ou LDR
  if (i2cExists(BH1750_ADDR)) {
    luxType = BH1750;
    Wire.beginTransmission(BH1750_ADDR);
    Wire.write(0x10);
    Wire.endTransmission();
  } else {
    luxType = LDR;
    pinMode(LDR_PIN, INPUT);
  }

  // MPU6050
  if (i2cExists(MPU6050_ADDR)) {
    i2cWrite(MPU6050_ADDR, 0x6B, 0x00);
    i2cWrite(MPU6050_ADDR, 0x1C, 0x10);
    i2cWrite(MPU6050_ADDR, 0x1B, 0x08);
    mpuActive = true;
  }
}

// ================================================================
// Lire BMP280
// ================================================================
void readBMP280() {
  Wire.beginTransmission(BMP280_ADDR);
  Wire.write(0xFA);
  Wire.endTransmission();
  Wire.requestFrom(BMP280_ADDR, (uint8_t)3);
  int32_t adc_T = ((int32_t)Wire.read() << 12) | ((int32_t)Wire.read() << 4) | (Wire.read() >> 4);
  
  Wire.beginTransmission(BMP280_ADDR);
  Wire.write(0xF7);
  Wire.endTransmission();
  Wire.requestFrom(BMP280_ADDR, (uint8_t)3);
  int32_t adc_P = ((int32_t)Wire.read() << 12) | ((int32_t)Wire.read() << 4) | (Wire.read() >> 4);
  
  currentSensorData.temperature = (adc_T / 5120.0) - 10.0;
  currentSensorData.pressure = (adc_P / 256.0) / 100.0;
  currentSensorData.altitude = 44330.0 * (1.0 - pow(currentSensorData.pressure / 1013.25, 0.1903));
}

// ================================================================
// Lire BMP180
// ================================================================
void readBMP180() {
  // Lecture simplifiée BMP180 (sans calibration complète)
  i2cWrite(BMP180_ADDR, 0xF4, 0x2E);
  delay(5);
  Wire.beginTransmission(BMP180_ADDR);
  Wire.write(0xF6);
  Wire.endTransmission();
  Wire.requestFrom(BMP180_ADDR, (uint8_t)2);
  int16_t ut = (Wire.read() << 8) | Wire.read();
  
  i2cWrite(BMP180_ADDR, 0xF4, 0x34);
  delay(5);
  Wire.beginTransmission(BMP180_ADDR);
  Wire.write(0xF6);
  Wire.endTransmission();
  Wire.requestFrom(BMP180_ADDR, (uint8_t)3);
  int32_t up = ((Wire.read() << 16) | (Wire.read() << 8) | Wire.read()) >> 8;
  
  currentSensorData.temperature = (ut / 128.0) - 100.0;
  currentSensorData.pressure = (up / 256.0) / 100.0;
  currentSensorData.altitude = 44330.0 * (1.0 - pow(currentSensorData.pressure / 1013.25, 0.1903));
}

// ================================================================
// Lire Luminosité (BH1750 ou LDR)
// ================================================================
void readLuminosity() {
  if (luxType == BH1750) {
    Wire.requestFrom(BH1750_ADDR, (uint8_t)2);
    if (Wire.available() == 2) {
      uint16_t lux = (Wire.read() << 8) | Wire.read();
      currentSensorData.luminosity = lux / 1.2;
    }
  } else if (luxType == LDR) {
    int ldrValue = analogRead(LDR_PIN);
    // Câblage: 5V → 10kΩ → A0 → LDR → GND
    // Obscurité (LDR haute résistance) = 0, Lumière (LDR faible résistance) = 1023
    currentSensorData.luminosity = map(ldrValue, 0, 1023, 0, 65000);
  } else {
    currentSensorData.luminosity = 5000.0;
  }
}

// ================================================================
// Lire MPU6050
// ================================================================
void readMPU6050() {
  if (!mpuActive) {
    currentSensorData.accelX = 0.0;
    currentSensorData.accelY = 0.0;
    currentSensorData.accelZ = 1.0;
    currentSensorData.gyroX = 0.0;
    currentSensorData.gyroY = 0.0;
    currentSensorData.gyroZ = 0.0;
    currentSensorData.vibration = 0.0;
    return;
  }
  
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(0x3B);
  Wire.endTransmission();
  Wire.requestFrom(MPU6050_ADDR, (uint8_t)6);
  
  int16_t ax = (Wire.read() << 8) | Wire.read();
  int16_t ay = (Wire.read() << 8) | Wire.read();
  int16_t az = (Wire.read() << 8) | Wire.read();
  
  currentSensorData.accelX = ax / 4096.0;
  currentSensorData.accelY = ay / 4096.0;
  currentSensorData.accelZ = az / 4096.0;
  
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(0x43);
  Wire.endTransmission();
  Wire.requestFrom(MPU6050_ADDR, (uint8_t)6);
  
  int16_t gx = (Wire.read() << 8) | Wire.read();
  int16_t gy = (Wire.read() << 8) | Wire.read();
  int16_t gz = (Wire.read() << 8) | Wire.read();
  
  currentSensorData.gyroX = gx / 65.5;
  currentSensorData.gyroY = gy / 65.5;
  currentSensorData.gyroZ = gz / 65.5;
  
  float magnitude = sqrt(currentSensorData.accelX * currentSensorData.accelX + 
                        currentSensorData.accelY * currentSensorData.accelY + 
                        (currentSensorData.accelZ - 1.0) * (currentSensorData.accelZ - 1.0));
  currentSensorData.vibration = constrain(magnitude * 100.0, 0.0, 100.0);
}

// ================================================================
// LECTURE TOUS CAPTEURS
// ================================================================
void readSensors() {
  // Température / Pression / Altitude
  if (bmpType == BMP280) {
    readBMP280();
  } else if (bmpType == BMP180) {
    readBMP180();
  } else {
    currentSensorData.temperature = 25.0;
    currentSensorData.pressure = 1013.25;
    currentSensorData.altitude = 0.0;
  }

  // Luminosité
  readLuminosity();

  // MPU6050
  readMPU6050();
  
  // Atténuation
  float temp = currentSensorData.temperature;
  float pressure = currentSensorData.pressure;
  float attenuation = 0.2 * (1.0 + (temp - 20.0) * 0.01) * (1013.25 / pressure);
  currentSensorData.attenuation = constrain(attenuation, 0.1, 5.0);
  
  currentSensorData.timestamp = millis();
  currentSensorData.valid = true;
}
