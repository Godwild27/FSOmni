// ================================================================
// sensors.h — Gestion des capteurs atmosphériques (porté depuis ESP32 V1)
// ================================================================
// Identique au sensors.h de l'ESP32 V1, mais adapté pour Arduino Uno :
//   - I2C sur A4/A5 (hardware fix)
//   - Pas de PSRAM, gestion mémoire plus stricte
//   - Lecture unique du MPU6050 par cycle (au lieu de 3 dans la V1)
// ================================================================

#ifndef SENSORS_H
#define SENSORS_H

#include <Arduino.h>

struct SensorData {
  float temperature;     // °C
  float pressure;        // hPa
  float altitude;        // m
  float luminosity;      // lux
  float accelX, accelY, accelZ;   // g
  float gyroX, gyroY, gyroZ;      // °/s
  float vibration;                // 0-100
  float attenuation;              // dB/km
  bool valid;
  unsigned long timestamp;
};

extern SensorData currentSensorData;

void initSensors();
void readSensors();

#endif
