// ================================================================
// arduino_sensors.ino — Mode SILENCIEUX TOTAL
// ================================================================
// L'Arduino envoie les données à l'ESP32 mais N'AFFICHE RIEN
// sur le Serial Monitor pour garder l'affichage propre
// ================================================================

#include "config.h"
#include "sensors.h"
#include <ArduinoJson.h>

unsigned long lastSensorReadTime = 0;

// ================================================================
// ENVOI CAPTEURS (vers ESP32 uniquement, pas d'affichage)
// ================================================================
void sendSensorsEvent() {
  StaticJsonDocument<256> doc;
  doc[F("evt")] = F("sensors");
  doc[F("temp")] = currentSensorData.temperature;
  doc[F("pres")] = currentSensorData.pressure;
  doc[F("alt")] = currentSensorData.altitude;
  doc[F("lux")] = currentSensorData.luminosity;
  doc[F("ax")] = currentSensorData.accelX;
  doc[F("ay")] = currentSensorData.accelY;
  doc[F("az")] = currentSensorData.accelZ;
  doc[F("gx")] = currentSensorData.gyroX;
  doc[F("gy")] = currentSensorData.gyroY;
  doc[F("gz")] = currentSensorData.gyroZ;
  doc[F("vib")] = currentSensorData.vibration;
  doc[F("att")] = currentSensorData.attenuation;
  serializeJson(doc, Serial);
  Serial.println();
}

// ================================================================
// ENVOI PONG
// ================================================================
void sendPong() {
  Serial.println(F("{\"evt\":\"pong\"}"));
}

// ================================================================
// TRAITEMENT COMMANDES
// ================================================================
void handleSerialCommands() {
  if (!Serial.available()) return;
  String line = Serial.readStringUntil('\n');
  line.trim();
  if (line.length() == 0) return;
  
  StaticJsonDocument<64> doc;
  if (deserializeJson(doc, line)) return;
  
  const char* cmd = doc["cmd"];
  if (cmd && strcmp(cmd, "ping") == 0) {
    sendPong();
  }
}

// ================================================================
// SETUP
// ================================================================
void setup() {
  Serial.begin(SERIAL_BAUD);
  delay(500);
  initSensors();
  readSensors();
}

// ================================================================
// LOOP
// ================================================================
void loop() {
  handleSerialCommands();
  
  if (millis() - lastSensorReadTime >= SENSOR_READ_INTERVAL_MS) {
    readSensors();
    sendSensorsEvent();
    lastSensorReadTime = millis();
  }
}
