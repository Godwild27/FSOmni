# 🛠️ Guide d'installation avec Arduino IDE

Ce guide explique pas-à-pas comment compiler et flasher les firmwares FSOmni V3 avec **Arduino IDE**.

---

## 📋 Étape 1 — Prérequis

### 1.1 Installer Arduino IDE

Télécharger la dernière version : https://www.arduino.cc/en/software

### 1.2 Ajouter le support ESP32-S3 dans Arduino IDE

1. Ouvrir **Fichier → Préférences**
2. Dans **« URL de gestionnaire de cartes supplémentaires »**, ajouter :
   ```
   https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
   ```
3. Cliquer **OK**
4. Aller dans **Outils → Type de carte → Gestionnaire de cartes**
5. Rechercher **« esp32 »** (by Espressif Systems)
6. Installer la version **3.x** (ou supérieure)

---

## 📚 Étape 2 — Installer les librairies

### 2.1 Librairies pour l'ESP32 (esp32_fso_gate)

Aller dans **Outils → Gérer les bibliothèques** et installer :

| Librairie | Auteur | Version | Notes |
|---|---|---|---|
| **ArduinoJson** | Benoit Blanchon | 6.21.x | Disponible dans le gestionnaire |
| **ESPAsyncWebServer** | me-no-dev | (latest) | ⚠️ Pas dans le gestionnaire — voir 2.2 |
| **AsyncTCP** | me-no-dev | (latest) | ⚠️ Pas dans le gestionnaire — voir 2.2 |

### 2.2 Installer ESPAsyncWebServer + AsyncTCP (depuis GitHub)

Ces 2 librairies ne sont pas dans le Library Manager. Procédure :

1. Télécharger le ZIP d'ESPAsyncWebServer :
   - Aller sur https://github.com/me-no-dev/ESPAsyncWebServer
   - Bouton vert **Code → Download ZIP**
   - Enregistrer sous `ESPAsyncWebServer-master.zip`

2. Télécharger le ZIP d'AsyncTCP :
   - Aller sur https://github.com/me-no-dev/AsyncTCP
   - Bouton vert **Code → Download ZIP**
   - Enregistrer sous `AsyncTCP-master.zip`

3. Dans Arduino IDE : **Croquis → Inclure une bibliothèque → Ajouter une bibliothèque .ZIP**
4. Sélectionner `ESPAsyncWebServer-master.zip` → Installer
5. Refaire pareil avec `AsyncTCP-master.zip`

> ⚠️ **Important** : Ne PAS installer la version "ESPAsyncWebServer" de `ESP32Async` ou `mathieucarbou` via le Library Manager — ces forks récents (v3.x) ont des bugs avec lwIP. Utiliser uniquement les versions officielles de `me-no-dev` depuis GitHub.

### 2.3 Librairies pour l'Arduino (arduino_sensors)

Aller dans **Outils → Gérer les bibliothèques** et installer :

| Librairie | Auteur | Version |
|---|---|---|
| **Adafruit BMP280 Library** | Adafruit | 2.6.x |
| **Adafruit BMP085 Library** | Adafruit | 1.2.x |
| **BH1750** | Christopher Laws | 1.3.x |
| **Adafruit MPU6050** | Adafruit | 2.2.x |
| **Adafruit Unified Sensor** | Adafruit | 1.1.x |
| **ArduinoJson** | Benoit Blanchon | 6.21.x |

> Les librairies Adafruit s'installeront avec leurs dépendances automatiquement (Adafruit BusIO, etc.).

---

## ⚙️ Étape 3 — Configurer la carte ESP32-S3

### 3.1 Brancher l'ESP32-S3

- Brancher l'ESP32-S3 N16R8 en USB
- Vérifier qu'il est détecté (port COMxx sur Windows, /dev/ttyUSBx ou /dev/cu.usbmodem sur Mac/Linux)

### 3.2 Sélectionner la carte

Dans **Outils**, configurer ainsi :

| Option | Valeur |
|---|---|
| **Type de carte** | ESP32S3 Dev Module |
| **Port** | COMxx (ou /dev/ttyUSB0) |
| **Upload Mode** | UART0 / Hardware CDC |
| **USB CDC On Boot** | Enabled |
| **USB Firmware MSC On Boot** | Disabled |
| **Upload Speed** | 921600 |
| **CPU Frequency** | 240MHz (WiFi/BT) |
| **Flash Mode** | QIO 80MHz |
| **Flash Size** | 16MB (128Mb) |
| **Partition Scheme** | Default 8MB with spiffs |
| **Core Debug Level** | None |
| **PSRAM** | Enabled |
| **Arduino Runs On** | Core 1 |
| **Events Run On** | Core 0 |

### 3.3 Configurer la carte Arduino Uno

| Option | Valeur |
|---|---|
| **Type de carte** | Arduino Uno |
| **Port** | COMyy (ou /dev/ttyACM0) |
| **Programmateur** | AVRISP mkII |

---

## 📂 Étape 4 — Ouvrir le projet V3

### 4.1 Dézipper `fso_firmware_v3.zip`

Tu obtiens :
```
fso_firmware_v3/
├── README.md
├── esp32_fso_gate/         ← Firmware ESP32
│   ├── esp32_fso_gate.ino
│   ├── config.h
│   ├── espnow_link.h/.cpp
│   ├── laser_gate.h/.cpp
│   ├── websocket_handler.h/.cpp
│   ├── wifi_manager.h/.cpp
│   ├── arduino_comm.h/.cpp
│   ├── sensors.h/.cpp
│   └── platformio.ini      ← ignore ce fichier (Arduino IDE)
└── arduino_sensors/        ← Firmware Arduino
    ├── arduino_sensors.ino
    ├── config.h
    ├── sensors.h/.cpp
    └── platformio.ini      ← ignore ce fichier
```

> ℹ️ Arduino IDE reconnaît un sketch comme un dossier contenant un fichier `.ino` du même nom. La structure est déjà conforme.

### 4.2 Ouvrir le sketch ESP32

1. **Fichier → Ouvrir**
2. Sélectionner `fso_firmware_v3/esp32_fso_gate/esp32_fso_gate.ino`
3. Arduino IDE ouvre automatiquement tous les `.cpp` et `.h` du dossier en onglets

### 4.3 Ouvrir le sketch Arduino

1. **Fichier → Ouvrir**
2. Sélectionner `fso_firmware_v3/arduino_sensors/arduino_sensors.ino`

---

## ⚙️ Étape 5 — Configurer UNIT_ID avant de flasher

### ⚠️ ÉTAPE OBLIGATOIRE

1. Ouvrir `esp32_fso_gate/config.h`
2. Chercher la ligne :
   ```cpp
   #define UNIT_ID 1
   ```
3. Pour l'**Unité 1** : laisser `UNIT_ID 1`
4. Pour l'**Unité 2** : changer en `UNIT_ID 2`

### Procédure de flash

1. **Brancher l'ESP32 n°1** → ouvrir `config.h` → mettre `UNIT_ID 1` → **Téléverser**
2. **Brancher l'ESP32 n°2** → ouvrir `config.h` → mettre `UNIT_ID 2` → **Téléverser**
3. **Brancher l'Arduino n°1** → ouvrir `arduino_sensors.ino` → **Téléverser**
4. **Brancher l'Arduino n°2** → **Téléverser** (même code pour les 2 Arduino)

> ⚠️ **Ne pas se tromper d'unité** : si tu flashes 2 fois `UNIT_ID 1` sur les 2 ESP32, ESP-NOW ne fonctionnera pas (chaque ESP32 cherchera l'autre avec la mauvaise MAC).

---

## ✅ Étape 6 — Vérifier la compilation

### 6.1 Compiler l'ESP32

1. Ouvrir `esp32_fso_gate.ino`
2. Type de carte : **ESP32S3 Dev Module**
3. Cliquer **Vérifier** (✓)
4. Doit afficher en bas :
   ```
   Le croquis utilise 806549 octets (24%) de l'espace de stockage de programmes. Le maximum est de 3342336 octets.
   Les variables globales utilisent 44960 octets (13%) de mémoire dynamique, ce qui laisse 282720 octets pour les variables locales. Le maximum est de 327680 octets.
   ```

### 6.2 Compiler l'Arduino

1. Ouvrir `arduino_sensors.ino`
2. Type de carte : **Arduino Uno**
3. Cliquer **Vérifier** (✓)
4. Doit afficher :
   ```
   Le croquis utilise 30516 octets (94%) de l'espace de stockage de programmes. Le maximum est de 32256 octets.
   Les variables globales utilisent 939 octets (45%) de mémoire dynamique, ce qui laisse 1109 octets pour les variables locales. Le maximum est de 2048 octets.
   ```

> ⚠️ L'Arduino est à **94% de flash** — c'est juste mais ça compile. Si erreur de mémoire, supprimer les `Serial.println` de debug dans `sensors.cpp` (Arduino).

---

## 🚀 Étape 7 — Flasher et tester

### 7.1 Flasher

1. Brancher l'ESP32 n°1 (UNIT_ID=1 dans config.h) → **Téléverser**
2. Brancher l'ESP32 n°2 (UNIT_ID=2 dans config.h) → **Téléverser**
3. Flasher les 2 Arduino avec `arduino_sensors.ino`

### 7.2 Tester

1. Ouvrir le **Moniteur série** (Ctrl+Shift+M) sur l'ESP32 n°1 → 115200 baud
2. Au boot, tu dois voir :
   ```
   ========================================
     ESP32 FSOmni Gate - V3.0
     Unite 1
     FSOmni V3.0 (ESP-NOW + Laser Gate)
   ========================================

   Ma MAC    : 44:1B:F6:FF:B0:F0
   Peer MAC  : 44:1B:F6:FF:AB:88
   WiFi AP   : FSOmni_1 (canal 6)
   Lasers TX : GPIO 4, 5, 6
   Photo RX  : GPIO 7, 8, 9

   [LaserGate] Init OK  TX=GPIO4,5,6  RX=GPIO7,8,9  Manchester=100 ms/bit  Gate timeout=1000 ms
   [ESP-NOW] ✅ Init OK  Peer=44:1B:F6:FF:AB:88  Channel=6
   [WS] WebSocket : ws://192.168.4.1:8080/

   ========================================
   FSOmni V3 pret:
     - WiFi AP demarre (pour Android)
     - WebSocket :8080 actif
     - ESP-NOW pair configure
     - Laser gate actif (3 TX + 3 RX)
     - Arduino comm (capteurs 20 Hz)
   ========================================
   ```

3. Quand tu alignes les lasers face-à-face :
   ```
   [Gate] OUVERT (ligne de vue OK)
   ```
4. Quand tu coupes le faisceau :
   ```
   [Gate] FERME (ligne de vue perdue)
   ```

---

## 🐛 Dépannage Arduino IDE

### Erreur "ESPAsyncWebServer.h: No such file or directory"

→ Installer ESPAsyncWebServer depuis GitHub (voir section 2.2)

### Erreur "AsyncTCP.h: No such file or directory"

→ Installer AsyncTCP depuis GitHub (voir section 2.2)

### Erreur "esp_now.h: No such file or directory"

→ Le board package ESP32 n'est pas installé (voir section 1.2)

### Erreur "PSRAM not enabled"

→ Dans **Outils → PSRAM**, sélectionner **Enabled**

### Erreur "Partition scheme too small"

→ Dans **Outils → Partition Scheme**, sélectionner **Default 8MB with spiffs** (pas "HUGE APP")

### Compilation OK mais upload échoue

→ Vérifier le port COM. Sur ESP32-S3, parfois il faut appuyer sur le bouton **BOOT** pendant l'upload, et relâcher quand "Connecting..." apparaît.

### Arduino Uno : "Sketch too big" (overflow)

→ L'Arduino est à 94% de flash. Si ça déborde, supprimer les Serial.println de debug dans `arduino_sensors/sensors.cpp`.

### Moniteur série affiche des caractères bizarres

→ Vérifier le baud rate : **115200** pour ESP32 et Arduino.
