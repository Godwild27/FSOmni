# Guide de Flashage ESP32 avec LED de Connexion

## 🎯 Résumé Rapide

Flasher le firmware sur les deux ESP32 pour activer la LED de connexion mutuelle sur GPIO 15.

## 📋 Prérequis

- Arduino IDE (v2.x recommandé)
- Board ESP32 installée (voir `ARDUINO_IDE_SETUP.md`)
- Deux ESP32-S3 N16R8
- Deux LEDs + résistances (220-330Ω)
- Câble USB-C

## 🔧 Configuration Matérielle

### Câblage LED (sur chaque unité)

```
ESP32 GPIO 15 → Résistance 220Ω → LED (Anode +)
LED (Cathode -) → GND
```

## 💾 Flashage des Deux Unités

### UNITÉ 1

1. **Ouvrir le firmware**
   - Ouvrir `esp32_fso_gate/esp32_fso_gate.ino` dans Arduino IDE

2. **Vérifier config.h**
   ```cpp
   #define UNIT_ID 1  // ✅ DOIT ÊTRE 1
   ```

3. **Sélectionner la carte**
   - Board: "ESP32-S3 Dev Module"
   - USB CDC On Boot: "Enabled"
   - Port: (votre port COM)

4. **Flasher**
   - Cliquer sur "Upload" (Ctrl+U)
   - Attendre "Hard resetting via RTS pin..."

5. **Vérifier les logs**
   - Ouvrir le Serial Monitor (115200 baud)
   ```
   ESP32 FSOmni Gate - V3.0
   Unite 1
   Ma MAC    : 44:1B:F6:FF:B0:F0
   [ESP-NOW] ✅ Init OK  Peer=44:1B:F6:FF:AB:88
   [ESP-NOW] LED connexion sur GPIO 15
   ```

6. **Test LED au démarrage**
   - La LED doit être **ÉTEINTE** (unité 2 pas encore allumée)

---

### UNITÉ 2

1. **Modifier config.h**
   ```cpp
   #define UNIT_ID 2  // ✅ CHANGER À 2
   ```

2. **Sauvegarder**
   - Ctrl+S

3. **Flasher**
   - Même procédure que l'unité 1
   - Upload (Ctrl+U)

4. **Vérifier les logs**
   ```
   ESP32 FSOmni Gate - V3.0
   Unite 2
   Ma MAC    : 44:1B:F6:FF:AB:88
   [ESP-NOW] ✅ Init OK  Peer=44:1B:F6:FF:B0:F0
   [ESP-NOW] LED connexion sur GPIO 15
   ```

---

## ✅ Test de Connexion

### Séquence de Test

1. **Alimenter l'unité 1**
   - LED éteinte (normal, peer pas allumé)

2. **Alimenter l'unité 2**
   - LED unité 1 : s'allume immédiatement
   - LED unité 2 : s'allume immédiatement
   - **✅ Succès : les deux LED sont allumées**

3. **Vérifier les logs série**
   
   **Unité 1 :**
   ```
   [ESP-NOW] 💡 LED connexion : ON (RX:245ms TX:1023ms)
   ```
   
   **Unité 2 :**
   ```
   [ESP-NOW] 💡 LED connexion : ON (RX:178ms TX:932ms)
   ```

4. **Test d'inactivité**
   - Attendre 6 secondes sans envoyer de messages
   - Les deux LED s'éteignent
   - **✅ Normal : pas d'activité ESP-NOW**

5. **Test de communication**
   - Connecter Android à l'unité 1
   - Envoyer un message texte
   - Les deux LED se rallument
   - **✅ Communication ESP-NOW active**

## 🐛 Dépannage Flashage

### Erreur "Failed to connect"

**Solutions :**
1. Maintenir le bouton BOOT pendant le flashage
2. Vérifier que "USB CDC On Boot" est activé
3. Essayer un autre port USB
4. Réduire la vitesse : Tools → Upload Speed → 115200

### Erreur "MAC address mismatch"

**Cause :** Les vraies adresses MAC ne correspondent pas à config.h

**Solution :**
1. Flasher avec un firmware de test qui affiche la vraie MAC :
   ```cpp
   void setup() {
     Serial.begin(115200);
     delay(1000);
     Serial.print("MAC: ");
     Serial.println(WiFi.macAddress());
   }
   ```
2. Noter les vraies MAC des deux ESP
3. Mettre à jour `config.h` avec les bonnes valeurs

### LED ne s'allume pas

**Vérifications :**
1. ✅ GPIO 15 câblé correctement
2. ✅ Polarité LED correcte (longue patte = anode vers résistance)
3. ✅ Résistance présente (220-330Ω)
4. ✅ Les deux ESP flashés avec des UNIT_ID différents (1 et 2)
5. ✅ Serial Monitor affiche `[ESP-NOW] LED connexion sur GPIO 15`

**Test manuel :**
Ajouter temporairement dans `setup()` après `espNowSetConnectionLed()` :
```cpp
digitalWrite(LED_CONNECTION_PIN, HIGH);
delay(2000);  // LED allumée 2 secondes au boot
```

### Les deux LED ne s'allument pas mutuellement

**Vérifications :**
1. ✅ Distance < 20 mètres
2. ✅ Pas d'obstacles métalliques épais
3. ✅ Les deux ESP sur le même canal WiFi (défini dans config.h)
4. ✅ Les adresses MAC PEER_MAC correctes
5. ✅ Serial Monitor affiche des paquets TX/RX

**Debug :**
```cpp
// Dans loop(), ajouter temporairement :
static unsigned long lastDebug = 0;
if (millis() - lastDebug > 1000) {
  Serial.printf("TX:%lu RX:%lu Errors:%lu\n", 
                espNowGetTxCount(), 
                espNowGetRxCount(),
                espNowGetTxErrors());
  lastDebug = millis();
}
```

Si `TxCount` augmente mais `RxCount` reste à 0 sur le peer → problème radio/MAC

## 📊 Comportement Normal

| Situation | LED Unité 1 | LED Unité 2 | Logs |
|-----------|-------------|-------------|------|
| Démarrage unité 1 seule | OFF | - | `Init OK` |
| Démarrage unité 2 | ON | ON | `LED connexion : ON` |
| Inactivité 5s+ | OFF | OFF | `LED connexion : OFF` |
| Message Android | ON | ON | `LED connexion : ON` |
| Unité 2 éteinte | OFF | - | Timeout 5s |

## 🔄 Reflashage Après Modification

Si vous modifiez le code (ex: changer `CONNECTION_TIMEOUT_MS`) :

1. Modifier le fichier source
2. Sauvegarder (Ctrl+S)
3. Upload (Ctrl+U)
4. **Pas besoin de changer UNIT_ID** si vous reflashez la même unité

## 📝 Checklist Finale

- [ ] Unité 1 flashée avec `UNIT_ID = 1`
- [ ] Unité 2 flashée avec `UNIT_ID = 2`
- [ ] LED + résistance câblées sur GPIO 15 (chaque unité)
- [ ] Serial Monitor montre `Init OK` sur les deux
- [ ] LED s'allument mutuellement au démarrage
- [ ] LED s'éteignent après 5s d'inactivité
- [ ] LED se rallument lors d'un message Android

✅ **Si tous les points sont validés, le système est opérationnel !**

## 🎓 Conseils

1. **Flasher les deux unités le même jour** pour éviter les décalages de version
2. **Étiqueter physiquement** les unités (UNIT_ID 1 et UNIT_ID 2)
3. **Garder un ESP branché au PC** pour debug en temps réel
4. **Tester à 1 mètre d'abord**, puis augmenter la distance
5. **Logs série = votre meilleur ami** pour comprendre ce qui se passe

---

**Version Firmware :** FSOmni V3.0  
**Date :** 2026-01-07  
**Testé sur :** ESP32-S3 N16R8
