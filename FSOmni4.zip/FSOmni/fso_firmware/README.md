# 🛰️ FSOmni V3 — Firmware

**Version 3.0** — Architecture ESP-NOW + Laser Gate Validation

## 🎯 Principe (Nouveau)

```
┌─────────────────────────────────────────────────────────────────────┐
│                          UNITÉ 1                                     │
│  ┌──────────┐  WebSocket  ┌───────────────┐                         │
│  │ Android  │ ◄─────────► │   ESP32-S3    │ ──┐                     │
│  │ App      │   :8080     │   (AP+STA)    │   │                     │
│  └──────────┘             │               │   │ ESP-NOW (données)   │
│                           │  + AP WiFi    │   │                     │
│                           │  + WebSocket  │   │                     │
│                           │  + ESP-NOW    │   │                     │
│                           │  + Laser Gate │   │                     │
│                           └──┬─────────┬──┘   │                     │
│                              │ UART    │ Laser│ Manchester          │
│                              ▼         ▼      │ (preuve optique)    │
│                           ┌──────┐  ┌────────┐│                     │
│                           │Arduino│  │3 lasers││                     │
│                           │ + cap │  │3 photo ││                     │
│                           └──────┘  └────────┘│                     │
└────────────────────────────────────────────────┼─────────────────────┘
                                                 │
                                                 ▼
┌─────────────────────────────────────────────────────────────────────┐
│                          UNITÉ 2                                     │
│  ┌──────────┐  WebSocket  ┌───────────────┐                         │
│  │ Android  │ ◄─────────► │   ESP32-S3    │ ◄──┐                    │
│  │ App      │   :8080     │   (AP+STA)    │    │                    │
│  └──────────┘             │  + Laser Gate │    │                    │
│                           └──┬─────────┬──┘    │                    │
│                              │ UART    │ Laser │                    │
│                              ▼         ▼       │                    │
│                           ┌──────┐  ┌────────┐│                    │
│                           │Arduino│  │3 lasers││                    │
│                           │ + cap │  │3 photo ││                    │
│                           └──────┘  └────────┘│                    │
└────────────────────────────────────────────────┴────────────────────┘
```

### Logique du système

1. **Transport réel des données** : ESP-NOW entre les 2 ESP32 (~1-2 Mbits/s)
2. **Preuve optique** : Lasers clignotent en Manchester pendant le transfert
3. **Gate (verrou)** : OUVERT si n'importe quelle photodiode voit un flash < 1s
4. **Règle** : Un paquet ESP-NOW reçu n'est transmis à Android QUE SI le gate est OUVERT

### Avantages vs V2

| Aspect | V2 (laser = données) | V3 (ESP-NOW + gate) |
|---|---|---|
| Débit réel | 5 octets/s (40 bits/s) | **~100 KB/s** (1+ Mbits/s ESP-NOW) |
| Vocal possible | Non (trop lent) | **Oui** (500 kbits/s × 10s) |
| Fichiers | Non | **Oui** (jusqu'à 500 KB) |
| Robustesse laser | Dépend du décodage | **Indépendant** (juste flash/no-flash) |
| Latence | ~25 s pour 50 octets | **< 100 ms** |

## 📁 Structure

```
fso_firmware_v3/
├── README.md
│
├── esp32_fso_gate/                   # Firmware ESP32-S3 N16R8
│   ├── platformio.ini
│   ├── esp32_fso_gate.ino            # Point d'entrée
│   ├── config.h                      # ⚠️ UNIT_ID à changer avant flash
│   ├── wifi_manager.h/.cpp           # WiFi AP+STA (modifié pour ESP-NOW)
│   ├── websocket_handler.h/.cpp      # type:2 → espNowSend() + laserGate
│   ├── arduino_comm.h/.cpp           # UART capteurs (inchangé V2)
│   ├── sensors.h/.cpp                # Structure SensorData (inchangé V2)
│   ├── espnow_link.h/.cpp            # ⭐ NOUVEAU — Transport ESP-NOW
│   └── laser_gate.h/.cpp             # ⭐ NOUVEAU — Manchester TX + gate RX
│
└── arduino_sensors/                  # Firmware Arduino Uno (inchangé V2)
    ├── platformio.ini
    ├── arduino_sensors.ino
    ├── config.h
    └── sensors.h/.cpp
```

## ⚙️ Configuration avant flash

### ÉTAPE OBLIGATOIRE : Changer UNIT_ID dans `esp32_fso_gate/config.h`

```cpp
#define UNIT_ID 1   // ← 1 pour unité 1, 2 pour unité 2
```

| UNIT_ID | PEER_MAC (l'autre unité) | SSID WiFi |
|---|---|---|
| 1 | `44:1B:F6:FF:AB:88` (unité 2) | `FSOmni_1` |
| 2 | `44:1B:F6:FF:B0:F0` (unité 1) | `FSOmni_2` |

**⚠️ ATTENTION** : Flasher l'unité 1 avec `UNIT_ID=1` et l'unité 2 avec `UNIT_ID=2`. Si tu inverses, ESP-NOW ne fonctionnera pas.

## 🔌 Hardware

### ESP32-S3 N16R8

| GPIO | Rôle |
|---|---|
| 4 | Laser TX 1 (KY-008 via transistor) |
| 5 | Laser TX 2 |
| 6 | Laser TX 3 |
| 7 | Photodiode RX 1 (INPUT_PULLUP) |
| 8 | Photodiode RX 2 |
| 9 | Photodiode RX 3 |
| 16 | UART2 RX (depuis Arduino TX) |
| 17 | UART2 TX (vers Arduino RX) |

### Arduino Uno

| Pin | Rôle |
|---|---|
| A4 (SDA) | I2C — BMP280, BH1750, MPU6050 |
| A5 (SCL) | I2C — idem |
| 0 (RX) | UART (depuis ESP32 GPIO 17, via level shifter) |
| 1 (TX) | UART (vers ESP32 GPIO 16, via level shifter) |

### Connexion ESP32 ↔ Arduino

```
ESP32 GPIO 17 (TX, 3.3V) ──[Level shifter]──> Arduino pin 0 (RX, 5V)
ESP32 GPIO 16 (RX, 3.3V) ◄──[Level shifter]── Arduino pin 1 (TX, 5V)
ESP32 GND                  ────────────────── Arduino GND
```

⚠️ **Level shifter obligatoire** — l'ESP32 sort du 3.3V, l'Arduino attend du 5V sur RX.

## 🚀 Compilation

### Arduino IDE (recommandé)

👉 **Voir le guide détaillé : [ARDUINO_IDE_SETUP.md](ARDUINO_IDE_SETUP.md)**

Résumé rapide :
1. Ajouter le board ESP32-S3 dans Arduino IDE (URL: `https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json`)
2. Installer les librairies (voir guide) — notamment ESPAsyncWebServer + AsyncTCP depuis GitHub
3. Ouvrir `esp32_fso_gate/esp32_fso_gate.ino` ou `arduino_sensors/arduino_sensors.ino`
4. Configurer la carte (ESP32S3 Dev Module avec PSRAM + 16MB Flash + 8MB partition)
5. ⚠️ Changer `UNIT_ID` dans `config.h` (1 ou 2) avant de flasher
6. Téléverser

### PlatformIO (alternative)

```bash
cd esp32_fso_gate
pio run
pio run -t upload
pio device monitor
```

### Stats de compilation (mesurées)

| Firmware | RAM | Flash | Statut |
|---|---|---|---|
| **ESP32-S3 V3** | 13.7% (45 KB / 327 KB) | 24.1% (806 KB / 3.3 MB) | ✅ OK |
| **Arduino Uno** | 45.8% (939 B / 2 KB) | 94.6% (30.5 KB / 32 KB) | ✅ OK |

## 🧪 Tests fonctionnels

### Étape 1 — Flasher

1. Ouvrir `esp32_fso_gate/config.h`, mettre `UNIT_ID 1`, compiler, flasher sur l'ESP32 n°1
2. Mettre `UNIT_ID 2`, compiler, flasher sur l'ESP32 n°2
3. Flasher `arduino_sensors.ino` sur les 2 Arduino Uno

### Étape 2 — Câbler

Voir section Hardware ci-dessus.

### Étape 3 — Tests

| Test | Action | Résultat attendu |
|---|---|---|
| Boot | Allumer les 2 ESP32 | "FSOmni V3 pret" sur le moniteur série |
| WiFi | Scanner WiFi sur Android | Voir `FSOmni_1` et `FSOmni_2` |
| Android 1 | Se connecter à `FSOmni_1` | WebSocket connecté, données capteurs |
| Android 2 | Se connecter à `FSOmni_2` | WebSocket connecté, données capteurs |
| Gate | Couper le laser entre les 2 unités | `[Gate] FERME` sur le moniteur série |
| Gate | Réaligner les lasers | `[Gate] OUVERT` sur le moniteur série |
| Envoi texte gate fermé | Envoyer "Hello" depuis Android 1 (gate fermé) | Android 2 ne reçoit rien |
| Envoi texte gate ouvert | Envoyer "Hello" depuis Android 1 (gate ouvert) | Android 2 reçoit "Hello" |
| Stats | Envoyer `{"type":"stats"}` | Affiche TX/RX/gate stats |

### Vérifications spécifiques

1. **ESP-NOW pair-à-pair** : Sur le moniteur série ESP32 au boot, tu dois voir :
   ```
   [ESP-NOW] ✅ Init OK  Peer=44:1B:F6:FF:AB:88  Channel=6
   ```

2. **Laser gate** : Quand tu alignes les lasers face-à-face, tu dois voir :
   ```
   [Gate] OUVERT (ligne de vue OK)
   ```
   Et quand tu coupes le faisceau :
   ```
   [Gate] FERME (ligne de vue perdue)
   ```

3. **Envoi texte** : Depuis Android, envoyer `{"type":2,"text":"Salut"}` → l'autre Android doit recevoir `{"type":2,"text":"Salut",...}` (si gate OUVERT).

## 📊 Limites

| Aspect | Limite |
|---|---|
| Distance | 20 mètres max (ligne de vue) |
| Vocal | 500 kbits/s × 10s = 625 KB max |
| Fichier | 500 KB max, chunks de 50 KB |
| Texte | 232 octets par paquet (fragmentation auto au-delà) |
| Fréquence Manchester | 10 Hz (100 ms/bit, visible à l'œil) |
| Gate timeout | 1000 ms (1 seconde) |

## 🆕 Améliorations V3 vs V2

| Ajout | Bénéfice |
|---|---|
| **ESP-NOW** | Débit réel ~100 KB/s (vs 5 octets/s en V2) |
| **Laser Manchester** | Juste preuve optique, ne bloque plus le débit |
| **Gate intelligent** | Filtre les paquets si ligne de vue coupée |
| **3 lasers + 3 photodiodes** | Tolérance alignement (1 sur 3 suffit) |
| **Vocal + Fichiers** | Maintenant possibles grâce à ESP-NOW |
| **WiFi AP+STA** | Coexistence AP (Android) + ESP-NOW (pair) |

## 🐛 Dépannage

### ESP-NOW ne marche pas

1. Vérifier `UNIT_ID` dans `config.h` (1 ou 2)
2. Vérifier que les 2 ESP32 sont sur le **même canal WiFi** (canal 6 par défaut)
3. Vérifier que le WiFi est en mode `AP+STA` (au boot : `Mode : AP+STA (ESP-NOW ready)`)
4. Vérifier que les MAC sont correctes dans `config.h`

### Gate toujours fermé

1. Vérifier l'alignement des lasers (les 3 paires)
2. Vérifier la polarité des photodiodes
3. Vérifier `INPUT_PULLUP` dans `laser_gate.cpp` (peut-être à inverser selon ton câblage)
4. Si photodiode **active-low** (lumière = LOW), changer `RISING` en `FALLING` dans `attachInterrupt`

### Gate toujours ouvert (faux positifs)

1. Lumière ambiante trop forte → filtrer optiquement (rouge 650nm)
2. Réduire `GATE_TIMEOUT_MS` à 500 ms
3. Augmenter `GATE_DEBOUNCE_MS` à 20 ms

### Capteurs ne s'affichent pas

1. Vérifier moniteur série Arduino : `OK BMP280 @ 0x76`, etc.
2. Vérifier level shifter UART (Arduino 5V → ESP32 3.3V)

## 🎯 Prochaines étapes (V3.1)

- Assemblage des chunks vocaux côté réception
- Assemblage des chunks fichier côté réception
- ACK/NACK pour retry automatique
- Statistiques temps réel (throughput, BER)
- Servos pan/tilt pour alignement auto
