// ================================================================
// websocket_handler.h — Gestion WebSocket
// ================================================================

#ifndef WEBSOCKET_HANDLER_H
#define WEBSOCKET_HANDLER_H

#include <ESPAsyncWebServer.h>
#include <ArduinoJson.h>
#include "config.h"

// WebSocket instance
extern AsyncWebServer server;
extern AsyncWebSocket ws;

// Initialisation
void initWebSocket();

// Envoi de messages vers les clients
void broadcastLaserRx(const String& text, int unitId);
void broadcastTxStatus(const String& status, int queueLen);
void broadcastError(const String& error);
void broadcastSensorsData();
void sendWebSocketPing();  // Keepalive ping

// Boucle de maintenance
void websocketLoop();

#endif
