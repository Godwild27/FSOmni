// ================================================================
// sensors.cpp — Stubs capteurs côté ESP32 (V2)
// ================================================================
// V2 : Les capteurs physiques (BMP280, BH1750, MPU6050) sont lus par
//      l'Arduino et envoyés via UART. L'ESP32 ne fait que stocker
//      les valeurs dans currentSensorData (rempli par arduino_comm.cpp)
//      et les broadcaster vers Android.
// ================================================================

#include "sensors.h"

// Variable globale (lue par websocket_handler.cpp)
SensorData currentSensorData = {
  25.0, 1013.25, 0.0,       // temp, pressure, altitude
  5000.0,                    // luminosity
  0.0, 0.0, 1.0,            // accelX, Y, Z (gravité au repos)
  0.0, 0.0, 0.0,            // gyroX, Y, Z
  0.0,                       // vibration
  0.0,                       // attenuation
  false, 0                   // valid, timestamp
};

void initSensors() {
  Serial.println("[Sensors] V2 — capteurs gérés par Arduino, initialisation ESP32 OK");
}

void readSensors() {
  // V2 : no-op, les données sont mises à jour par le callback
  // setArduinoSensorsCallback() dans esp32_fsomni.ino
}
