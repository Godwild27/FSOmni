// ================================================================
// wifi_manager.h — Gestion WiFi Access Point
// ================================================================

#ifndef WIFI_MANAGER_H
#define WIFI_MANAGER_H

#include <WiFi.h>
#include "config.h"

void initWiFiAP();
IPAddress getAPIP();

#endif
