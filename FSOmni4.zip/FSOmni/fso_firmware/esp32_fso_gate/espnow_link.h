// ================================================================
// espnow_link.h — Liaison ESP-NOW pair-à-pair FSO V3
// ================================================================
// Rôle :
//   - Transport RÉEL des données entre les 2 ESP32 (texte, vocal, fichiers)
//   - Fragmentation automatique des gros messages
//   - Callback de réception (le gate laser est vérifié par l'appelant)
// ================================================================

#ifndef ESPNOW_LINK_H
#define ESPNOW_LINK_H

#include <Arduino.h>

// ================================================================
// TYPES DE MESSAGES
// ================================================================
enum EspNowMsgType : uint8_t {
  ESPNOW_MSG_TEXT         = 0,
  ESPNOW_MSG_VOCAL        = 1,
  ESPNOW_MSG_FILE_META    = 2,  // métadonnées fichier (nom, taille, hash)
  ESPNOW_MSG_FILE_CHUNK   = 3,  // chunk de fichier
  ESPNOW_MSG_FILE_END     = 4,  // fin de fichier
  ESPNOW_MSG_ACK          = 5,  // acquittement
  ESPNOW_MSG_CONTROL      = 6,  // contrôle (start/stop/pause)
  ESPNOW_MSG_HEARTBEAT    = 7   // heartbeat pour maintenir la connexion LED
};

// ================================================================
// STRUCTURE PAQUET ESP-NOW (250 octets max)
// ================================================================
struct EspNowPacket {
  uint8_t  type;            // EspNowMsgType
  uint16_t seq;             // numéro de séquence (incrémental)
  uint16_t total_len;       // taille totale du message (si fragmenté)
  uint16_t chunk_offset;    // offset dans le message (en octets)
  uint8_t  unit_id;         // NOUVEAU : ID de l'unité émettrice (1, 2, 3...)
  uint8_t  reserved;        // Padding pour alignement
  uint8_t  payload[230];    // données utiles (réduit de 232 à 230 pour unit_id)
};  // sizeof = 1 + 2 + 2 + 2 + 1 + 1 + 230 = 239 octets (sous la limite 250)

// ================================================================
// CALLBACK RÉCEPTION
// ================================================================
// Appelé quand un paquet ESP-NOW est reçu.
// ⚠️ Le gate laser doit être vérifié par l'appelant AVANT de traiter.
typedef void (*EspNowRxCallback)(const EspNowPacket* pkt);

// ================================================================
// API PUBLIQUE
// ================================================================

// Initialisation (à appeler dans setup(), après initWiFiAP())
bool espNowInit();

// Envoi d'un message simple (texte court, < 230 octets)
// type : EspNowMsgType
// unitId : numéro de l'unité émettrice (1, 2, 3...)
// Retourne true si envoyé avec succès
bool espNowSend(const uint8_t* data, size_t len, uint8_t type, uint8_t unitId = 0);

// Envoi d'un message texte LENT avec lasers Manchester actifs
// text : texte à envoyer
// unitId : numéro de l'unité émettrice (1, 2, 3...)
// Débit : ~0.6 seconde par caractère (3 lettres = 2s, 10 lettres = 5s)
// Les 3 lasers clignotent en Manchester pendant tout le transfert
// Retourne true si envoyé avec succès
bool espNowSendTextSlow(const char* text, uint8_t unitId);

// Envoi d'un message fragmenté (vocal, fichier)
// Découpe automatiquement en chunks de 230 octets
// slowMode : si true, ajoute un délai entre les chunks pour ralentir la transmission
// Retourne true si tous les chunks ont été envoyés
bool espNowSendFragmented(const uint8_t* data, size_t len, uint8_t type, uint8_t unitId = 0, bool slowMode = false);

// Envoi d'un paquet brut (déjà construit par l'appelant)
bool espNowSendPacket(const EspNowPacket* pkt);

// Enregistre le callback de réception
void espNowOnReceive(EspNowRxCallback cb);

// Stats
uint32_t espNowGetTxCount();
uint32_t espNowGetRxCount();
uint32_t espNowGetTxErrors();
uint32_t espNowGetRxErrors();
void espNowResetStats();

// État
bool espNowIsReady();

// LED de connexion
void espNowSetConnectionLed(uint8_t pin);
void espNowUpdateConnectionLed();

// Heartbeat pour maintenir la LED active
void espNowSendHeartbeat();

#endif
