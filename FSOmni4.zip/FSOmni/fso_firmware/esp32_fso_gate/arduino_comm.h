// ================================================================
// arduino_comm.h — Communication avec Arduino (capteurs uniquement, V2)
// ================================================================
// V2 : L'Arduino ne gère plus les lasers. Il ne fait que :
//   - lire les capteurs I2C à 20 Hz
//   - envoyer {"evt":"sensors",...} sur UART
//   - répondre aux {"cmd":"ping"} et {"cmd":"status"} de l'ESP32
// ================================================================

#ifndef ARDUINO_COMM_H
#define ARDUINO_COMM_H

#include <Arduino.h>
#include <ArduinoJson.h>
#include "config.h"
#include "sensors.h"  // pour SensorData

// État de l'Arduino
extern bool arduinoReady;

// Initialisation UART
void initArduinoComm();

// Envoi de commandes vers Arduino (en V2, seulement ping et status)
void sendArduinoPing();
void sendArduinoStatus();

// Réception des messages Arduino (à appeler dans loop())
void handleArduinoMessages();

// Callbacks pour traiter les événements Arduino
typedef void (*ArduinoSensorsCallback)(const SensorData& data);
typedef void (*ArduinoErrorCallback)(const String& error);

void setArduinoSensorsCallback(ArduinoSensorsCallback callback);
void setArduinoErrorCallback(ArduinoErrorCallback callback);

#endif
