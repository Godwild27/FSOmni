// ================================================================
// config.h — Configuration FSOmni V3 (ESP-NOW + Laser Gate)
// ================================================================
// ⚠️ AVANT DE FLASHER : changer UNIT_ID selon l'unité (1 ou 2)
// Le PEER_MAC et le SSID WiFi se configureront automatiquement.
// ================================================================

#ifndef CONFIG_H
#define CONFIG_H

// ================================================================
// IDENTITÉ DE L'UNITÉ — À CHANGER AVANT DE FLASHER
// ================================================================
// Unité 1 → flasher avec UNIT_ID = 1
// Unité 2 → flasher avec UNIT_ID = 2
#define UNIT_ID 1

// ================================================================
// ADRESSES MAC (codées en dur comme spécifié dans le principe V3)
// ================================================================
// MAC Unité 1 : 44:1B:F6:FF:B0:F0
// MAC Unité 2 : 44:1B:F6:FF:AB:88

#if UNIT_ID == 1
  // Je suis l'unité 1 → mon peer est l'unité 2
  #define PEER_MAC {0x44, 0x1B, 0xF6, 0xFF, 0xAB, 0x88}
  #define MY_MAC_STR  "44:1B:F6:FF:B0:F0"
  #define PEER_MAC_STR "44:1B:F6:FF:AB:88"
#elif UNIT_ID == 2
  // Je suis l'unité 2 → mon peer est l'unité 1
  #define PEER_MAC {0x44, 0x1B, 0xF6, 0xFF, 0xB0, 0xF0}
  #define MY_MAC_STR  "44:1B:F6:FF:AB:88"
  #define PEER_MAC_STR "44:1B:F6:FF:B0:F0"
#else
  #error "UNIT_ID doit être 1 ou 2"
#endif

// ================================================================
// CONFIGURATION WiFi + ESP-NOW
// ================================================================
// ⚠️ ESP-NOW et AP doivent partager le MÊME canal radio
#define WIFI_CHANNEL 6

#if UNIT_ID == 1
  #define WIFI_SSID "FSOmni_1"
#elif UNIT_ID == 2
  #define WIFI_SSID "FSOmni_2"
#endif
#define WIFI_PASSWORD "fsomni2026"
#define MAX_CLIENTS 4

// ================================================================
// CONFIGURATION WEBSOCKET
// ================================================================
#define WS_PORT 8080

// ================================================================
// CONFIGURATION COMMUNICATION ARDUINO (capteurs via UART)
// ================================================================
#define ARDUINO_SERIAL Serial2
#define ARDUINO_BAUD 115200
#define ARDUINO_RX_PIN 16
#define ARDUINO_TX_PIN 17

// ================================================================
// CONFIGURATION LASER (3 canaux TX + 3 photodiodes RX)
// ================================================================
// Lasers TX (KY-008 via transistor) — tous clignotent en parallèle
#define LASER_TX_PIN_1   4
#define LASER_TX_PIN_2   5
#define LASER_TX_PIN_3   6

// Photodiodes RX (directes sur GPIO, logique inversée)
#define PHOTODIODE_PIN_1 7
#define PHOTODIODE_PIN_2 8
#define PHOTODIODE_PIN_3 9

// ================================================================
// LED DE CONNEXION MUTUELLE (ESP-NOW)
// ================================================================
// LED qui s'allume quand les deux ESP32 sont connectés via ESP-NOW
#define LED_CONNECTION_PIN 15

// ================================================================
// CONFIGURATION DU GATE (verrou optique)
// ================================================================
// Le gate est OUVERT si n'importe quelle photodiode a détecté un
// front montant ces dernières GATE_TIMEOUT_MS millisecondes.
#define GATE_TIMEOUT_MS        1000    // 1 seconde
#define GATE_DEBOUNCE_MS       5       // anti-rebond logiciel

// ================================================================
// CONFIGURATION MANCHESTER (clignotement laser visible)
// ================================================================
// Fréquence visible à l'œil nu (juste pour la preuve optique,
// la photodiode ne décode PAS les bits).
// 100 ms/bit = 10 Hz (bien visible)
#define MANCHESTER_BIT_DUR_MS  100

// ================================================================
// LIMITES DE TRANSFERT ESP-NOW
// ================================================================
#define ESPNOW_MAX_PACKET      250     // max ESP-NOW (octets)
#define ESPNOW_PAYLOAD_MAX     232     // 250 - header (18 octets)
#define VOCAL_MAX_DURATION_S   10      // 10 secondes max
#define VOCAL_MAX_BITRATE      500000  // 500 kbits/s
#define FILE_MAX_SIZE_KB       500     // 500 KB max
#define FILE_CHUNK_SIZE_KB     50      // chunks de 50 KB max

// ================================================================
// CONFIGURATION GÉNÉRALE
// ================================================================
#define SERIAL_BAUD 115200
#define PING_INTERVAL 30000  // Ping Arduino toutes les 30s

// Versions
#define FIRMWARE_VERSION "FSOmni V3.0 (ESP-NOW + Laser Gate)"

#endif
