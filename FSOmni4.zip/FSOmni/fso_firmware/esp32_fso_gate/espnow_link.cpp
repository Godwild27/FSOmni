// ================================================================
// espnow_link.cpp — Implémentation liaison ESP-NOW FSO V3
// ================================================================

#include "espnow_link.h"
#include "config.h"
#include "laser_gate.h"    // Pour contrôler les lasers pendant transmission
#include <esp_now.h>
#include <esp_wifi.h>      // pour esp_now_recv_info_t et wifi_tx_info_t (v3.3.x)
#include <WiFi.h>

// ───────────────────────── Variables internes ─────────────────────────
static bool              espNowReady = false;
static EspNowRxCallback  rxCb = nullptr;
static uint16_t          nextSeq = 0;
static uint8_t           peerMac[6] = PEER_MAC;

// Stats
static volatile uint32_t txCount = 0;
static volatile uint32_t rxCount = 0;
static volatile uint32_t txErrors = 0;
static volatile uint32_t rxErrors = 0;

// LED de connexion
static uint8_t connectionLedPin = 0;
static bool ledState = false;
static unsigned long lastRxTime = 0;
static unsigned long lastTxTime = 0;
static const unsigned long CONNECTION_TIMEOUT_MS = 3000;  // 3 secondes sans activité = déconnecté
static const unsigned long HEARTBEAT_INTERVAL_MS = 1000;  // Envoyer heartbeat toutes les 1 seconde
static unsigned long lastHeartbeatTime = 0;

// ───────────────────────── Callback ESP-NOW (réception) ─────────────────────────
// Appelé par l'ESP-IDF quand un paquet ESP-NOW est reçu.
// Doit être statique et IRAM_ATTR.
//
// ⚠️ L'API a changé dans Arduino-ESP32 v3.3.x :
//   - Avant : void cb(const uint8_t* mac, const uint8_t* data, int len)
//   - Maintenant : void cb(const esp_now_recv_info_t* info, const uint8_t* data, int len)
// On gère les deux versions avec une macro.
#if defined(ESP_ARDUINO_VERSION_MAJOR) && \
    (ESP_ARDUINO_VERSION_MAJOR > 3 || \
     (ESP_ARDUINO_VERSION_MAJOR == 3 && ESP_ARDUINO_VERSION_MINOR >= 3))
// ── Nouvelle API (Arduino-ESP32 >= 3.3.0) ──
static void IRAM_ATTR onEspNowRecv(const esp_now_recv_info_t* info, const uint8_t* data, int dataLen) {
  // Récupérer la MAC source depuis la nouvelle structure
  const uint8_t* mac = (info != nullptr) ? info->src_addr : nullptr;
#else
// ── Ancienne API (Arduino-ESP32 < 3.3.0) ──
static void IRAM_ATTR onEspNowRecv(const uint8_t* mac, const uint8_t* data, int dataLen) {
#endif
  if (dataLen < (int)sizeof(EspNowPacket)) {
    rxErrors++;
    return;
  }

  // Vérifier que ça vient bien du peer (pas d'un autre ESP32)
  if (mac == nullptr || memcmp(mac, peerMac, 6) != 0) {
    // Paquet d'un appareil inconnu → ignorer
    return;
  }

  rxCount++;
  lastRxTime = millis();  // Marquer réception pour LED connexion

  // Copier dans une structure locale (data peut être invalidé)
  EspNowPacket pkt;
  memcpy(&pkt, data, sizeof(EspNowPacket));

  // Appeler le callback
  if (rxCb != nullptr) {
    rxCb(&pkt);
  }
}

// ───────────────────────── Callback ESP-NOW (envoi) ─────────────────────────
// ⚠️ L'API a changé dans Arduino-ESP32 v3.3.x :
//   - Avant : void cb(const uint8_t* mac, esp_now_send_status_t status)
//   - Maintenant : void cb(const wifi_tx_info_t* info, esp_now_send_status_t status)
#if defined(ESP_ARDUINO_VERSION_MAJOR) && \
    (ESP_ARDUINO_VERSION_MAJOR > 3 || \
     (ESP_ARDUINO_VERSION_MAJOR == 3 && ESP_ARDUINO_VERSION_MINOR >= 3))
// ── Nouvelle API (Arduino-ESP32 >= 3.3.0) ──
static void IRAM_ATTR onEspNowSend(const wifi_tx_info_t* info, esp_now_send_status_t status) {
  (void)info;  // non utilisé
#else
// ── Ancienne API (Arduino-ESP32 < 3.3.0) ──
static void IRAM_ATTR onEspNowSend(const uint8_t* mac, esp_now_send_status_t status) {
  (void)mac;  // non utilisé
#endif
  if (status == ESP_NOW_SEND_SUCCESS) {
    lastTxTime = millis();  // Marquer envoi réussi pour LED connexion
  } else {
    txErrors++;
  }
}

// ───────────────────────── Init ─────────────────────────
bool espNowInit() {
  Serial.println("[ESP-NOW] Initialisation...");

  // WiFi doit être en mode AP_STA pour ESP-NOW + AP
  if (WiFi.getMode() != WIFI_AP_STA) {
    Serial.println("[ESP-NOW] ⚠️ WiFi pas en AP_STA, tentative de correction...");
    WiFi.mode(WIFI_AP_STA);
    delay(100);
  }

  // Init ESP-NOW
  esp_err_t err = esp_now_init();
  if (err != ESP_OK) {
    Serial.printf("[ESP-NOW] ❌ esp_now_init() a échoué : %s\n", esp_err_to_name(err));
    return false;
  }

  // Enregistrer les callbacks
  esp_now_register_recv_cb(onEspNowRecv);
  esp_now_register_send_cb(onEspNowSend);

  // Ajouter le peer
  esp_now_peer_info_t peerInfo;
  memset(&peerInfo, 0, sizeof(peerInfo));
  memcpy(peerInfo.peer_addr, peerMac, 6);
  peerInfo.channel = WIFI_CHANNEL;       // même canal que WiFi AP
  peerInfo.encrypt = false;              // pas de chiffrement (V3)

  err = esp_now_add_peer(&peerInfo);
  if (err != ESP_OK) {
    Serial.printf("[ESP-NOW] ❌ esp_now_add_peer() a échoué : %s\n", esp_err_to_name(err));
    return false;
  }

  espNowReady = true;
  lastRxTime = millis();  // Initialiser le timer
  lastTxTime = millis();
  Serial.printf("[ESP-NOW] ✅ Init OK  Peer=%s  Channel=%d\n", PEER_MAC_STR, WIFI_CHANNEL);
  return true;
}

// ───────────────────────── Envoi ─────────────────────────
bool espNowSendPacket(const EspNowPacket* pkt) {
  if (!espNowReady) return false;

  esp_err_t err = esp_now_send(peerMac, (const uint8_t*)pkt, sizeof(EspNowPacket));
  if (err != ESP_OK) {
    txErrors++;
    Serial.printf("[ESP-NOW] ❌ send erreur : %s\n", esp_err_to_name(err));
    return false;
  }

  txCount++;
  return true;
}

bool espNowSend(const uint8_t* data, size_t len, uint8_t type, uint8_t unitId) {
  if (!espNowReady) return false;
  if (len > ESPNOW_PAYLOAD_MAX) {
    // Trop grand → fragmentation
    return espNowSendFragmented(data, len, type, unitId, false);
  }

  EspNowPacket pkt;
  memset(&pkt, 0, sizeof(pkt));
  pkt.type = type;
  pkt.seq = nextSeq++;
  pkt.total_len = (uint16_t)len;
  pkt.chunk_offset = 0;
  pkt.unit_id = unitId;
  pkt.reserved = 0;
  if (data != nullptr && len > 0) {
    memcpy(pkt.payload, data, len);
  }

  return espNowSendPacket(&pkt);
}

bool espNowSendFragmented(const uint8_t* data, size_t len, uint8_t type, uint8_t unitId, bool slowMode) {
  if (!espNowReady) return false;
  if (data == nullptr || len == 0) return false;

  uint16_t total = (uint16_t)len;
  uint16_t offset = 0;
  uint16_t baseSeq = nextSeq;

  // Calculer le délai pour obtenir ~0.6 sec/caractère en mode lent
  // Pour un message de 3 caractères → 2 secondes total
  // Délai par chunk = (2000 ms / 3 car) * (230 bytes / chunk) / (1 byte/car)
  // Simplifié : ~600 ms par chunk de 1 caractère
  // Pour chunk plein (230 bytes) : 600 * 230 / 1 = trop long
  // Ajustement : 500 ms par chunk de texte
  const int DELAY_PER_CHUNK_MS = slowMode ? 500 : 2;

  while (offset < total) {
    uint16_t chunkLen = total - offset;
    if (chunkLen > ESPNOW_PAYLOAD_MAX) chunkLen = ESPNOW_PAYLOAD_MAX;

    EspNowPacket pkt;
    memset(&pkt, 0, sizeof(pkt));
    pkt.type = type;
    pkt.seq = baseSeq++;
    pkt.total_len = total;
    pkt.chunk_offset = offset;
    pkt.unit_id = unitId;
    pkt.reserved = 0;
    memcpy(pkt.payload, data + offset, chunkLen);

    if (!espNowSendPacket(&pkt)) {
      Serial.printf("[ESP-NOW] ❌ Fragment %u/%u échec\n", offset, total);
      return false;
    }

    offset += chunkLen;

    // Délai pour ralentir la transmission
    delay(DELAY_PER_CHUNK_MS);
  }

  nextSeq = baseSeq;
  Serial.printf("[ESP-NOW] ✅ %u octets envoyés en %u fragments (%s)\n",
                total, (total + ESPNOW_PAYLOAD_MAX - 1) / ESPNOW_PAYLOAD_MAX,
                slowMode ? "slow" : "fast");
  return true;
}

// ───────────────────────── Callback ─────────────────────────
void espNowOnReceive(EspNowRxCallback cb) {
  rxCb = cb;
}

// ───────────────────────── Stats ─────────────────────────
uint32_t espNowGetTxCount()   { return txCount; }
uint32_t espNowGetRxCount()   { return rxCount; }
uint32_t espNowGetTxErrors()  { return txErrors; }
uint32_t espNowGetRxErrors()  { return rxErrors; }
bool     espNowIsReady()      { return espNowReady; }

void espNowResetStats() {
  txCount = 0;
  rxCount = 0;
  txErrors = 0;
  rxErrors = 0;
}

// ───────────────────────── LED de connexion ─────────────────────────
void espNowSetConnectionLed(uint8_t pin) {
  connectionLedPin = pin;
  pinMode(pin, OUTPUT);
  digitalWrite(pin, LOW);
  ledState = false;
  Serial.printf("[ESP-NOW] LED connexion sur GPIO %d\n", pin);
}

void espNowUpdateConnectionLed() {
  if (connectionLedPin == 0 || !espNowReady) return;
  
  unsigned long now = millis();
  
  // Envoyer un heartbeat automatiquement toutes les 2 secondes
  if (now - lastHeartbeatTime >= HEARTBEAT_INTERVAL_MS) {
    espNowSendHeartbeat();
    lastHeartbeatTime = now;
  }
  
  // Considérer connecté si on a reçu OU envoyé dans les 5 dernières secondes
  bool connected = (now - lastRxTime < CONNECTION_TIMEOUT_MS) || 
                   (now - lastTxTime < CONNECTION_TIMEOUT_MS);
  
  // Mettre à jour la LED seulement si l'état change
  if (connected != ledState) {
    ledState = connected;
    digitalWrite(connectionLedPin, ledState ? HIGH : LOW);
    Serial.printf("[ESP-NOW] 💡 LED connexion : %s (RX:%lums TX:%lums)\n", 
                  ledState ? "ON" : "OFF",
                  now - lastRxTime,
                  now - lastTxTime);
  }
}

// ───────────────────────── Heartbeat ─────────────────────────
void espNowSendHeartbeat() {
  if (!espNowReady) return;
  
  // Envoyer un petit paquet heartbeat vide
  EspNowPacket pkt;
  memset(&pkt, 0, sizeof(pkt));
  pkt.type = ESPNOW_MSG_HEARTBEAT;
  pkt.seq = nextSeq++;
  pkt.total_len = 0;
  pkt.chunk_offset = 0;
  
  espNowSendPacket(&pkt);
  // Pas de log pour ne pas polluer la console
}

// ───────────────────────── Envoi texte LENT avec lasers ─────────────────────────
bool espNowSendTextSlow(const char* text, uint8_t unitId) {
  if (!espNowReady || text == nullptr) return false;
  
  size_t len = strlen(text);
  if (len == 0) return false;
  
  Serial.printf("[ESP-NOW] 📤 Envoi texte LENT: \"%s\" (unitId=%u, %u caractères)\n", 
                text, unitId, len);
  
  // 💡💡💡 ALLUMER LES 3 LASERS EN MANCHESTER
  laserGateTxStart((const uint8_t*)text, len);
  
  // Calculer le délai pour obtenir ~0.6 seconde par caractère
  // 3 caractères = 2s → 2000ms / 3 = ~666ms par caractère
  // 10 caractères = 5s → 5000ms / 10 = 500ms par caractère
  // Moyenne : ~600ms par caractère
  const unsigned long DELAY_PER_CHAR_MS = 600;
  
  // Fragmenter si nécessaire (max 220 bytes de texte par paquet pour laisser place au unitId)
  const size_t MAX_TEXT_PER_PACKET = 220;
  size_t offset = 0;
  uint16_t totalLen = (uint16_t)len;
  
  while (offset < len) {
    size_t chunkLen = len - offset;
    if (chunkLen > MAX_TEXT_PER_PACKET) chunkLen = MAX_TEXT_PER_PACKET;
    
    // Construire le paquet
    EspNowPacket pkt;
    memset(&pkt, 0, sizeof(pkt));
    pkt.type = ESPNOW_MSG_TEXT;
    pkt.seq = nextSeq++;
    pkt.total_len = totalLen;
    pkt.chunk_offset = (uint16_t)offset;
    pkt.unit_id = unitId;
    
    // Copier le chunk de texte
    memcpy(pkt.payload, text + offset, chunkLen);
    
    // Envoyer le paquet
    if (!espNowSendPacket(&pkt)) {
      Serial.printf("[ESP-NOW] ❌ Échec envoi chunk %u/%u\n", offset, totalLen);
      laserGateTxStop();  // Éteindre les lasers en cas d'erreur
      return false;
    }
    
    // Délai proportionnel au nombre de caractères dans ce chunk
    unsigned long delayMs = chunkLen * DELAY_PER_CHAR_MS;
    Serial.printf("[ESP-NOW] 📡 Chunk %u/%u envoyé, attente %lums...\n", 
                  offset + chunkLen, totalLen, delayMs);
    delay(delayMs);
    
    offset += chunkLen;
  }
  
  // 💡💡💡 ÉTEINDRE LES LASERS
  laserGateTxStop();
  
  Serial.printf("[ESP-NOW] ✅ Texte complet envoyé en %lums\n", len * DELAY_PER_CHAR_MS);
  return true;
}
