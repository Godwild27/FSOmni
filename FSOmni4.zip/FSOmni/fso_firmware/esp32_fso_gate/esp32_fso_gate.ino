// ================================================================
// esp32_fso_gate.ino — ESP32 FSOmni V3 (ESP-NOW + Laser Gate)
// ================================================================
// Architecture V3 :
//   - WiFi AP "FSOmni_X" (pour l'app Android, inchangé)
//   - WebSocket :8080 (pour l'app Android, inchangé)
//   - ESP-NOW pair-à-pair (transport RÉEL des données entre les 2 ESP32)
//   - Laser Manchester (juste preuve optique, ne transporte PAS de données)
//   - Gate : OUVERT si n'importe quelle photodiode voit un flash < 1s
//   - Arduino Uno : lit les capteurs I2C et envoie sur UART (inchangé V2)
//
// ⚠️ AVANT DE FLASHER : changer UNIT_ID dans config.h (1 ou 2)
// ================================================================

#include "config.h"
#include "wifi_manager.h"
#include "arduino_comm.h"
#include "websocket_handler.h"
#include "sensors.h"
#include "espnow_link.h"
#include "laser_gate.h"

// ================================================================
// VARIABLES GLOBALES
// ================================================================
unsigned long lastPingTime = 0;
unsigned long lastSensorReadTime = 0;
const unsigned long SENSOR_READ_INTERVAL = 50;       // 50 ms = 20 Hz
const unsigned long WEBSOCKET_PING_INTERVAL = 15000; // 15 s keepalive
unsigned long lastWebSocketPing = 0;

// ================================================================
// CALLBACK ESP-NOW RÉCEPTION
// ================================================================
// Appelé quand un paquet ESP-NOW est reçu depuis l'unité peer.
// ⚠️ On ne transmet à Android QUE SI le gate laser est OUVERT.
void onEspNowRx(const EspNowPacket* pkt) {
  // Heartbeat : ne pas afficher de log pour ne pas polluer la console
  if (pkt->type != ESPNOW_MSG_HEARTBEAT) {
    Serial.printf("[ESP-NOW RX] type=%u seq=%u offset=%u/%u\n",
                  pkt->type, pkt->seq, pkt->chunk_offset, pkt->total_len);
  }

  // ─── HEARTBEAT : juste maintenir la connexion LED, pas de traitement ───
  if (pkt->type == ESPNOW_MSG_HEARTBEAT) {
    // Le heartbeat est reçu, la LED reste allumée automatiquement
    return;
  }

  // ─── VÉRIFIER LE GATE LASER ───
  // Si gate fermé → ignorer silencieusement
  if (!laserGateIsOpen()) {
    Serial.println("[ESP-NOW RX] ⚠️ Gate FERME → paquet ignore");
    return;
  }

  // ─── Gate OUVERT → traiter le paquet ───
  switch (pkt->type) {
    case ESPNOW_MSG_TEXT:
      // Message texte (court, non fragmenté)
      {
        String text = "";
        text.reserve(pkt->total_len);
        for (uint16_t i = 0; i < pkt->total_len; i++) {
          text += (char)pkt->payload[i];
        }
        // Récupérer le unit_id de l'émetteur
        int unitId = pkt->unit_id;
        Serial.printf("[ESP-NOW RX] Texte de Unité %d: \"%s\"\n", unitId, text.c_str());
        broadcastLaserRx(text, unitId);
      }
      break;

    case ESPNOW_MSG_VOCAL:
      // TODO V3.1 : assembler les chunks vocaux
      Serial.println("[ESP-NOW RX] Vocal chunk (TODO: assembler)");
      break;

    case ESPNOW_MSG_FILE_META:
      Serial.println("[ESP-NOW RX] File metadata (TODO)");
      break;

    case ESPNOW_MSG_FILE_CHUNK:
      Serial.println("[ESP-NOW RX] File chunk (TODO)");
      break;

    case ESPNOW_MSG_FILE_END:
      Serial.println("[ESP-NOW RX] File end (TODO)");
      break;

    default:
      Serial.printf("[ESP-NOW RX] Type inconnu: %u\n", pkt->type);
      break;
  }
}

// ================================================================
// CALLBACK GATE STATE CHANGE
// ================================================================
void onGateStateChange(bool isOpen) {
  Serial.printf("[Gate] %s\n", isOpen ? "OUVERT (ligne de vue OK)" : "FERME (ligne de vue perdue)");

  // Notifier l'app Android du changement d'état
  if (ws.count() > 0) {
    String msg = String("{\"type\":\"gate_state\",\"open\":") +
                 (isOpen ? "true" : "false") + "}";
    ws.textAll(msg);
  }
}

// ================================================================
// SETUP
// ================================================================
void setup() {
  Serial.begin(SERIAL_BAUD);
  delay(1000);

  Serial.println("\n========================================");
  Serial.printf("  ESP32 FSOmni Gate - V3.0\n");
  Serial.printf("  Unite %d\n", UNIT_ID);
  Serial.printf("  %s\n", FIRMWARE_VERSION);
  Serial.println("========================================\n");

  Serial.printf("Ma MAC    : %s\n", MY_MAC_STR);
  Serial.printf("Peer MAC  : %s\n", PEER_MAC_STR);
  Serial.printf("WiFi AP   : %s (canal %d)\n", WIFI_SSID, WIFI_CHANNEL);
  Serial.printf("Lasers TX : GPIO %d, %d, %d\n",
                LASER_TX_PIN_1, LASER_TX_PIN_2, LASER_TX_PIN_3);
  Serial.printf("Photo RX  : GPIO %d, %d, %d\n",
                PHOTODIODE_PIN_1, PHOTODIODE_PIN_2, PHOTODIODE_PIN_3);
  Serial.println();

  // 1. Initialiser WiFi AP+STA (requis pour ESP-NOW)
  initWiFiAP();

  // 2. Initialiser structure capteurs
  initSensors();

  // 3. Initialiser communication Arduino (capteurs via UART)
  initArduinoComm();

  // 4. Callbacks Arduino → WebSocket
  setArduinoSensorsCallback([](const SensorData& data) {
    currentSensorData = data;
  });

  setArduinoErrorCallback([](const String& error) {
    broadcastError(error);
  });

  // 5. Initialiser le gate laser (3 lasers TX + 3 photodiodes RX)
  laserGateInit();
  laserGateOnStateChange(onGateStateChange);

  // 6. Initialiser ESP-NOW (après WiFi, obligatoire)
  if (!espNowInit()) {
    Serial.println("[ESP-NOW] ERREUR INIT — continuation sans ESP-NOW");
  } else {
    // Configurer la LED de connexion sur GPIO 15
    espNowSetConnectionLed(LED_CONNECTION_PIN);
  }
  espNowOnReceive(onEspNowRx);

  // 7. Initialiser WebSocket (pour Android)
  initWebSocket();

  Serial.println("\n========================================");
  Serial.println("FSOmni V3 pret:");
  Serial.println("  - WiFi AP demarre (pour Android)");
  Serial.println("  - WebSocket :8080 actif");
  Serial.println("  - ESP-NOW pair configure");
  Serial.println("  - Laser gate actif (3 TX + 3 RX)");
  Serial.println("  - Arduino comm (capteurs 20 Hz)");
  Serial.println("========================================\n");
}

// ================================================================
// LOOP PRINCIPAL
// ================================================================
void loop() {
  // 1. Traiter les messages Arduino (capteurs + pong + errors)
  handleArduinoMessages();

  // 2. Mettre à jour l'état du gate laser (détecte changements OUVERT↔FERMÉ)
  laserGateIsOpen();  // appel pour déclencher le callback si changement

  // 3. Mettre à jour la LED de connexion ESP-NOW
  espNowUpdateConnectionLed();

  // 4. Maintenance WebSocket
  websocketLoop();

  // 5. Ping Arduino (30 s)
  if (millis() - lastPingTime > PING_INTERVAL) {
    sendArduinoPing();
    lastPingTime = millis();
  }

  // 6. Diffusion capteurs (20 Hz)
  if (millis() - lastSensorReadTime >= SENSOR_READ_INTERVAL) {
    broadcastSensorsData();
    lastSensorReadTime = millis();
  }

  // 7. WebSocket keepalive (15 s)
  if (millis() - lastWebSocketPing >= WEBSOCKET_PING_INTERVAL) {
    sendWebSocketPing();
    lastWebSocketPing = millis();
  }
}
