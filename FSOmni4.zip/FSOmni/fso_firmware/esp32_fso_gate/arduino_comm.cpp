// ================================================================
// arduino_comm.cpp — Implémentation Communication Arduino (V2)
// ================================================================
// V2 : ne gère plus que les capteurs et le ping/pong.
//      Les commandes laser "tx" et "servo" ont été supprimées
//      (le laser est maintenant piloté directement par l'ESP32 via LaserEngine).
// ================================================================

#include "arduino_comm.h"

// État
bool arduinoReady = false;

// Callbacks
ArduinoSensorsCallback sensorsCallback = nullptr;
ArduinoErrorCallback   errorCallback   = nullptr;

// ================================================================
// INITIALISATION
// ================================================================
void initArduinoComm() {
  ARDUINO_SERIAL.begin(ARDUINO_BAUD, SERIAL_8N1, ARDUINO_RX_PIN, ARDUINO_TX_PIN);
  Serial.printf("Communication Arduino : RX=GPIO%d, TX=GPIO%d @ %d baud\n",
                ARDUINO_RX_PIN, ARDUINO_TX_PIN, ARDUINO_BAUD);
}

// ================================================================
// ENVOI DE COMMANDES VERS ARDUINO (en V2 : seulement ping et status)
// ================================================================
void sendArduinoPing() {
  ARDUINO_SERIAL.println("{\"cmd\":\"ping\"}");
  Serial.println("→ Arduino: Ping");
}

void sendArduinoStatus() {
  ARDUINO_SERIAL.println("{\"cmd\":\"status\"}");
  Serial.println("→ Arduino: Status request");
}

// ================================================================
// RÉCEPTION DES MESSAGES ARDUINO (MODE SILENCIEUX + ROBUST)
// ================================================================
void handleArduinoMessages() {
  while (ARDUINO_SERIAL.available()) {
    String jsonMsg = ARDUINO_SERIAL.readStringUntil('\n');
    jsonMsg.trim();
    
    // Ignorer les messages vides ou trop courts
    if (jsonMsg.length() < 10) continue;
    
    // Vérifier que ça ressemble à du JSON
    if (!jsonMsg.startsWith("{") || !jsonMsg.endsWith("}")) {
      // Message corrompu, ignorer silencieusement
      continue;
    }

    StaticJsonDocument<768> doc;
    DeserializationError error = deserializeJson(doc, jsonMsg);

    if (error) {
      // Logger seulement si ce n'est pas une erreur triviale
      if (error != DeserializationError::EmptyInput) {
        Serial.printf("❌ JSON Arduino: %s\n", error.c_str());
      }
      continue;
    }

    const char* evt = doc["evt"];
    if (evt == nullptr) continue;

    // ──────────────────────────────────────────────────────────
    // DONNÉES CAPTEURS (5 Hz depuis l'Arduino)
    // ──────────────────────────────────────────────────────────
    if (strcmp(evt, "sensors") == 0) {
      SensorData data;
      data.temperature = doc["temp"] | 25.0;
      data.pressure    = doc["pres"] | 1013.25;
      data.altitude    = doc["alt"]  | 0.0;
      data.luminosity  = doc["lux"]  | 5000.0;

      data.accelX = doc["ax"] | 0.0;
      data.accelY = doc["ay"] | 0.0;
      data.accelZ = doc["az"] | 1.0;

      data.gyroX = doc["gx"] | 0.0;
      data.gyroY = doc["gy"] | 0.0;
      data.gyroZ = doc["gz"] | 0.0;

      data.vibration   = doc["vib"] | 0.0;
      data.attenuation = doc["att"] | 0.0;
      data.valid       = true;
      data.timestamp   = millis();

      if (sensorsCallback != nullptr) {
        sensorsCallback(data);
      }
    }

    // ──────────────────────────────────────────────────────────
    // ERREUR ARDUINO (logger seulement les erreurs)
    // ──────────────────────────────────────────────────────────
    else if (strcmp(evt, "error") == 0) {
      String errMsg = doc["msg"] | "Erreur inconnue";
      Serial.printf("❌ Erreur Arduino: %s\n", errMsg.c_str());
      if (errorCallback != nullptr) {
        errorCallback(errMsg);
      }
    }

    // ──────────────────────────────────────────────────────────
    // PONG (logger uniquement)
    // ──────────────────────────────────────────────────────────
    else if (strcmp(evt, "pong") == 0) {
      arduinoReady = true;
      Serial.println("🏓 Arduino: Pong");
    }

    // ──────────────────────────────────────────────────────────
    // ARDUINO PRÊT (logger uniquement au boot)
    // ──────────────────────────────────────────────────────────
    else if (strcmp(evt, "ready") == 0) {
      arduinoReady = true;
      Serial.println("✅ Arduino: Prêt");
    }
  }
}

// ================================================================
// CALLBACKS
// ================================================================
void setArduinoSensorsCallback(ArduinoSensorsCallback callback) {
  sensorsCallback = callback;
}

void setArduinoErrorCallback(ArduinoErrorCallback callback) {
  errorCallback = callback;
}
