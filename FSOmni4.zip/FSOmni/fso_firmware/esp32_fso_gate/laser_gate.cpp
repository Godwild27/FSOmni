// ================================================================
// laser_gate.cpp — Implémentation du verrou optique laser FSO V3
// ================================================================
// Logique :
//   TX : 3 lasers (GPIO 4, 5, 6) clignotent en Manchester pendant le transfert
//        Manchester : bit 1 = HAUT-BAS, bit 0 = BAS-HAUT (transition par bit)
//        Fréquence : 10 Hz (100 ms/bit, visible à l'œil)
//
//   RX : 3 photodiodes (GPIO 7, 8, 9) en INPUT_PULLUP (logique inversée)
//        Front montant sur n'importe quelle photodiode → lastPulseTime = millis()
//        Gate OUVERT si millis() - lastPulseTime < GATE_TIMEOUT_MS (1000 ms)
//
//   Important : le laser NE TRANSPORTE PAS de données utiles.
//   Les données réelles transitent par ESP-NOW.
// ================================================================

#include "laser_gate.h"
#include "config.h"

// ───────────────────────── Variables TX ─────────────────────────
static volatile bool     txActive = false;
static const uint8_t     txPins[3] = {LASER_TX_PIN_1, LASER_TX_PIN_2, LASER_TX_PIN_3};
static const uint8_t*    txData = nullptr;
static size_t            txDataLen = 0;
static size_t            txBitIndex = 0;        // index du bit courant dans data
static size_t            txBitCount = 0;        // total bits à envoyer
static bool              txHalf = false;        // false = première moitié, true = seconde
static hw_timer_t*       txTimer = nullptr;

// ───────────────────────── Variables RX ─────────────────────────
static const uint8_t     rxPins[3] = {PHOTODIODE_PIN_1, PHOTODIODE_PIN_2, PHOTODIODE_PIN_3};
static volatile uint32_t lastPulseTime = 0;
static volatile uint32_t pulseCount = 0;
static volatile uint32_t lastDebounceTime[3] = {0, 0, 0};

// ───────────────────────── État du gate ─────────────────────────
static volatile bool     gateOpen = false;
static uint32_t          openCount = 0;
static uint32_t          closeCount = 0;
static GateStateCallback stateCallback = nullptr;

// ───────────────────────── ISR TX (Manchester) ─────────────────────────
// Timer à 20 Hz (50 ms = demi-bit), donc bit complet = 100 ms = 10 Hz
static void IRAM_ATTR onTxTimer() {
  if (!txActive || txData == nullptr || txBitIndex >= txBitCount) {
    // Terminé ou arrêté → éteindre les lasers
    for (int i = 0; i < 3; i++) digitalWrite(txPins[i], LOW);
    txActive = false;
    return;
  }

  // Bit courant
  size_t byteIdx = txBitIndex / 8;
  size_t bitPos  = txBitIndex % 8;
  bool bit = (txData[byteIdx] >> bitPos) & 0x01;

  // Manchester : bit=1 → première moitié HAUT, seconde BAS
  //              bit=0 → première moitié BAS, seconde HAUT
  bool level;
  if (bit) {
    level = txHalf ? false : true;   // 1: HAUT puis BAS
  } else {
    level = txHalf ? true : false;   // 0: BAS puis HAUT
  }

  // Appliquer sur les 3 lasers en parallèle
  for (int i = 0; i < 3; i++) digitalWrite(txPins[i], level ? HIGH : LOW);

  // Avancer
  if (txHalf) {
    txHalf = false;
    txBitIndex++;
  } else {
    txHalf = true;
  }
}

// ───────────────────────── ISR RX (fronts montants) ─────────────────────────
// Forward declaration
static void IRAM_ATTR handlePhotodiodeIsrImpl(int idx);

static void IRAM_ATTR onPhotodiode1() { handlePhotodiodeIsrImpl(0); }
static void IRAM_ATTR onPhotodiode2() { handlePhotodiodeIsrImpl(1); }
static void IRAM_ATTR onPhotodiode3() { handlePhotodiodeIsrImpl(2); }

static void IRAM_ATTR handlePhotodiodeIsrImpl(int idx) {
  uint32_t now = millis();

  // Anti-rebond logiciel
  if (now - lastDebounceTime[idx] < GATE_DEBOUNCE_MS) return;
  lastDebounceTime[idx] = now;

  // Front montant = flash détecté
  lastPulseTime = now;
  pulseCount++;
}

// ───────────────────────── Init ─────────────────────────
void laserGateInit() {
  // ─── TX : 3 lasers en sortie ───
  for (int i = 0; i < 3; i++) {
    pinMode(txPins[i], OUTPUT);
    digitalWrite(txPins[i], LOW);
  }

  // ─── RX : 3 photodiodes en entrée avec interruption ───
  // Logique inversée (photodiode active-low) :
  //   - Lumière sur photodiode → tension basse → LOW
  //   - Pas de lumière → pull-up → HIGH
  //   - Front montant = lumière qui disparaît... NON
  // En fait, sur photodiode active-high :
  //   - Lumière → HIGH, pas de lumière → LOW
  //   - Front montant = lumière qui apparaît = flash détecté
  // On suppose ici photodiode active-high (le plus courant avec TIA)
  // Si active-low, inverser RISING/FALLING dans les attachInterrupt
  for (int i = 0; i < 3; i++) {
    pinMode(rxPins[i], INPUT_PULLUP);
  }
  attachInterrupt(rxPins[0], onPhotodiode1, RISING);
  attachInterrupt(rxPins[1], onPhotodiode2, RISING);
  attachInterrupt(rxPins[2], onPhotodiode3, RISING);

  // ─── Timer TX Manchester ───
  // L'API Timer a changé entre Arduino-ESP32 v3.2.x et v3.3.x.
  // On détecte la version avec ESP_ARDUINO_VERSION.
  //
  // v3.2.x (PlatformIO / anciens Arduino IDE) :
  //   timerBegin(timer_num, divider, countUp) — 3 args
  //   timerAttachInterrupt(timer, fn, edge)   — 3 args
  //   timerAlarmWrite(timer, alarm, autoreload) — 3 args
  //   timerAlarmEnable(timer)                  — 1 arg
  //
  // v3.3.x (Arduino IDE récent ≥ 3.3.0) :
  //   timerBegin(frequency)                    — 1 arg (Hz)
  //   timerAttachInterrupt(timer, fn)          — 2 args
  //   timerAlarm(timer, alarm, autoreload, reload_count) — 4 args
  //
  // Fréquence timer = 1 MHz (1 tick = 1 µs)
  // Alarme toutes les 50 ms (= 50000 µs) pour demi-bit Manchester à 100 ms/bit
#if defined(ESP_ARDUINO_VERSION_MAJOR) && \
    (ESP_ARDUINO_VERSION_MAJOR > 3 || \
     (ESP_ARDUINO_VERSION_MAJOR == 3 && ESP_ARDUINO_VERSION_MINOR >= 3))
  // ── Nouvelle API (Arduino-ESP32 >= 3.3.0) ──
  txTimer = timerBegin(1000000);                                   // 1 MHz
  timerAttachInterrupt(txTimer, &onTxTimer);
  timerAlarm(txTimer, MANCHESTER_BIT_DUR_MS * 1000 / 2, true, 0); // autoreload
#else
  // ── Ancienne API (Arduino-ESP32 < 3.3.0) ──
  txTimer = timerBegin(1, 80, true);                               // 1 MHz (80 MHz / 80)
  timerAttachInterrupt(txTimer, &onTxTimer, true);
  timerAlarmWrite(txTimer, MANCHESTER_BIT_DUR_MS * 1000 / 2, true);
  timerAlarmEnable(txTimer);
#endif

  // Gate initialement fermé
  gateOpen = false;
  lastPulseTime = 0;

  Serial.printf("[LaserGate] Init OK  TX=GPIO%d,%d,%d  RX=GPIO%d,%d,%d  Manchester=%d ms/bit  Gate timeout=%d ms\n",
                txPins[0], txPins[1], txPins[2],
                rxPins[0], rxPins[1], rxPins[2],
                MANCHESTER_BIT_DUR_MS, GATE_TIMEOUT_MS);
}

// ───────────────────────── TX ─────────────────────────
void laserGateTxStart(const uint8_t* data, size_t len) {
  if (data == nullptr || len == 0) {
    // Pas de données → clignoter un motif par défaut (10 Hz fixe)
    // pour maintenir la preuve optique pendant le transfert
    txData = nullptr;
    txDataLen = 0;
    txBitIndex = 0;
    txBitCount = 0;
    txHalf = false;
    txActive = true;
    return;
  }

  // Encoder les données en Manchester
  txData = data;
  txDataLen = len;
  txBitCount = len * 8;
  txBitIndex = 0;
  txHalf = false;
  txActive = true;

  Serial.printf("[LaserGate] TX démarré (%u bits Manchester)\n", txBitCount);
}

void laserGateTxStop() {
  txActive = false;
  txData = nullptr;
  txDataLen = 0;
  for (int i = 0; i < 3; i++) digitalWrite(txPins[i], LOW);
}

// ───────────────────────── RX / Gate ─────────────────────────
bool laserGateIsOpen() {
  if (lastPulseTime == 0) return false;  // jamais vu de flash
  uint32_t elapsed = millis() - lastPulseTime;
  bool nowOpen = (elapsed < GATE_TIMEOUT_MS);

  // Détection de changement d'état (pour stats + callback)
  if (nowOpen != gateOpen) {
    gateOpen = nowOpen;
    if (nowOpen) {
      openCount++;
    } else {
      closeCount++;
    }
    if (stateCallback != nullptr) {
      stateCallback(nowOpen);
    }
  }

  return nowOpen;
}

uint32_t laserGateTimeSinceLastPulse() {
  if (lastPulseTime == 0) return UINT32_MAX;
  return millis() - lastPulseTime;
}

// ───────────────────────── Callback ─────────────────────────
void laserGateOnStateChange(GateStateCallback cb) {
  stateCallback = cb;
}

// ───────────────────────── Stats ─────────────────────────
uint32_t laserGateGetPulseCount()  { return pulseCount; }
uint32_t laserGateGetOpenCount()   { return openCount; }
uint32_t laserGateGetCloseCount()  { return closeCount; }

void laserGateResetStats() {
  pulseCount = 0;
  openCount = 0;
  closeCount = 0;
}
