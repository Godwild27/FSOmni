// ================================================================
// sensors.h — Structure de données capteurs (V2)
// ================================================================
// V2 : Les capteurs sont lus par l'Arduino, pas par l'ESP32.
//      Ce fichier ne définit QUE la structure SensorData, qui est :
//      - remplie par arduino_comm.cpp quand l'Arduino envoie {"evt":"sensors",...}
//      - lue par websocket_handler.cpp pour broadcast vers Android
// ================================================================

#ifndef SENSORS_H
#define SENSORS_H

#include <Arduino.h>

// ================================================================
// STRUCTURE DE DONNÉES CAPTEURS
// ================================================================
struct SensorData {
  // BMP180/BMP280 - Température et Pression
  float temperature;     // °C
  float pressure;        // hPa
  float altitude;        // m

  // BH1750 - Luminosité
  float luminosity;      // lux

  // MPU6050 - Accéléromètre et Gyroscope
  float accelX, accelY, accelZ;   // g
  float gyroX, gyroY, gyroZ;      // °/s
  float vibration;                // 0-100

  // Calculs dérivés
  float attenuation;     // dB/km

  // Métadonnées
  bool valid;
  unsigned long timestamp;
};

// ================================================================
// VARIABLE GLOBALE
// ================================================================
extern SensorData currentSensorData;

// ================================================================
// INITIALISATION (V2 : juste initialise currentSensorData avec valeurs défaut)
// ================================================================
void initSensors();

// ================================================================
// LECTURE (V2 : no-op, les données viennent de l'Arduino via arduino_comm)
// ================================================================
void readSensors();

#endif
