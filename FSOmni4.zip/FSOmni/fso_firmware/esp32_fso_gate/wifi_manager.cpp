// ================================================================
// wifi_manager.cpp — Implémentation WiFi (V3 : WIFI_AP_STA pour ESP-NOW)
// ================================================================

#include "wifi_manager.h"

void initWiFiAP() {
  Serial.println("Configuration du point d'accès WiFi...");

  // V3 : WIFI_AP_STA requis pour coexistence AP + ESP-NOW
  WiFi.mode(WIFI_AP_STA);

  WiFi.setSleep(false);

  WiFi.softAP(WIFI_SSID, WIFI_PASSWORD, WIFI_CHANNEL, 0, MAX_CLIENTS);

  IPAddress IP = WiFi.softAPIP();
  Serial.print("  SSID : ");         Serial.println(WIFI_SSID);
  Serial.print("  Canal : ");        Serial.println(WIFI_CHANNEL);
  Serial.print("  Mot de passe : "); Serial.println(WIFI_PASSWORD);
  Serial.print("  Adresse IP : ");   Serial.println(IP);
  Serial.println("  Mode : AP+STA (ESP-NOW ready)");
  Serial.println("  WiFi Power Save : DESACTIVE");
  Serial.println("OK WiFi AP demarre");
}

IPAddress getAPIP() {
  return WiFi.softAPIP();
}
