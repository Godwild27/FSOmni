// ================================================================
// laser_gate.h — Verrou optique laser FSO V3
// ================================================================
// Rôle : 
//   - TX : fait clignoter les 3 lasers en Manchester pendant le transfert
//   - RX : détecte les fronts montants sur les 3 photodiodes
//   - Gate : OUVERT si n'importe quelle photodiode a vu un flash < 1s
//
// ⚠️ Le laser NE TRANSPORTE PAS de données utiles.
//    Il prouve juste que la ligne de vue est dégagée.
//    Les données réelles transitent par ESP-NOW.
// ================================================================

#ifndef LASER_GATE_H
#define LASER_GATE_H

#include <Arduino.h>

// ================================================================
// CALLBACK — appelé quand l'état du gate change
// ================================================================
typedef void (*GateStateCallback)(bool isOpen);

// ================================================================
// API PUBLIQUE
// ================================================================

// Initialisation (à appeler dans setup())
void laserGateInit();

// ─── TX (côté émetteur) ───
// Démarre le clignotement Manchester sur les 3 lasers pendant le transfert
// data/len : données à encoder (juste pour respecter le doc, non décodées)
void laserGateTxStart(const uint8_t* data, size_t len);

// Arrête le clignotement (éteint les lasers)
void laserGateTxStop();

// ─── RX (côté récepteur) ───
// Indique si le gate est OUVERT (ligne de vue confirmée)
bool laserGateIsOpen();

// Retourne le temps écoulé depuis le dernier flash détecté (ms)
uint32_t laserGateTimeSinceLastPulse();

// ─── Callback ───
// Enregistre un callback appelé quand l'état du gate change (OUVERT↔FERMÉ)
void laserGateOnStateChange(GateStateCallback cb);

// ─── Stats ───
uint32_t laserGateGetPulseCount();
uint32_t laserGateGetOpenCount();
uint32_t laserGateGetCloseCount();
void laserGateResetStats();

#endif
