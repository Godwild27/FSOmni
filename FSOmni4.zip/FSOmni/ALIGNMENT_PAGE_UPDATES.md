# Mise à Jour de la Page Alignement

## ✅ Modifications Effectuées

### 1. **Métriques Dynamiques Ajoutées**

#### FPS (Frames Per Second)
- **Localisation** : `AppState.fps`
- **Calcul** : Valeur simulée entre 58-62 fps avec variabilité réaliste
- **Mise à jour** : Toutes les secondes
- **Affichage** : Format "60.2" (1 décimale)

#### LAT (Latence)
- **Localisation** : `AppState.latency`
- **Calcul** : Valeur simulée entre 12-20ms avec variabilité
- **Mise à jour** : Toutes les secondes
- **Affichage** : Format "15ms" (entier)

#### SIG (Qualité du Signal)
- **Localisation** : `AppState.signalQuality`
- **Calcul** : Basé sur le RSSI
  - Formule : `(RSSI + 80) / 50 × 100`
  - RSSI -80 dBm → 0%
  - RSSI -30 dBm → 100%
- **Mise à jour** : Quand le RSSI change (temps réel)
- **Affichage** : Format "84%" (couleur verte `tertiary`)

#### GAIN (Gain de Stabilisation)
- **Localisation** : `AppState.stabilizationGain`
- **Calcul** : Basé sur la magnitude du gyroscope
  - Formule : `sqrt(gyroX² + gyroY² + gyroZ²) / 50 × 100`
  - 0°/s → 0% gain
  - 50°/s ou plus → 100% gain
- **Mise à jour** : Quand les données gyroscope changent
- **Affichage** : Format "23%" (couleur primaire)

### 2. **Switch Auto-Alignement Fonctionnel**

#### État ON (Auto-alignement activé)
- Les boutons servo (← →) sont **désactivés**
- Opacité réduite à 0.4 (grisés)
- `btnServoLeft.setEnabled(false)`
- `btnServoRight.setEnabled(false)`
- Le système contrôle automatiquement l'alignement

#### État OFF (Contrôle manuel)
- Les boutons servo sont **activés**
- Opacité normale à 1.0
- L'utilisateur peut ajuster manuellement l'axe X (Tilt)

#### Comportement
```java
updateServoControlsState(boolean autoAlignEnabled) {
    boolean manualControlEnabled = !autoAlignEnabled;
    btnServoLeft.setEnabled(manualControlEnabled);
    btnServoRight.setEnabled(manualControlEnabled);
    btnServoLeft.setAlpha(manualControlEnabled ? 1.0f : 0.4f);
    btnServoRight.setAlpha(manualControlEnabled ? 1.0f : 0.4f);
}
```

### 3. **Valeurs Servo Réelles**

#### Avant
- Valeur fixe : "14.22°" (ne changeait jamais)

#### Après
- Valeur provenant de `AppState.servoTilt`
- Incrémente/décrémente de 0.5° à chaque clic
- Plage : -45° à +45°
- Maintien du bouton = répétition automatique toutes les 200ms
- Envoi de la commande servo au WebSocket
- Format : "14.22°" (2 décimales)

#### Logique de Contrôle
```java
private void moveServo(double delta) {
    // Ne pas bouger si auto-align est activé
    if (appState.isAutoAlignEnabled()) {
        return;
    }
    
    double newTilt = appState.getServoTilt() + delta;
    newTilt = Math.max(-45, Math.min(45, newTilt)); // Limiter la plage
    appState.setServoTilt(newTilt);
    
    // Envoyer au WebSocket
    wsClient.sendServoCommand("tilt", newTilt);
}
```

## 📊 Interface Utilisateur

### Layout Ajouté (4 Petites Cartes Métriques)
```
┌─────────┬─────────┬─────────┬─────────┐
│  FPS    │  LAT    │  SIG    │  GAIN   │
│  60.2   │  15ms   │  84%    │  23%    │
└─────────┴─────────┴─────────┴─────────┘
```

### État Auto-Align OFF (Contrôle Manuel)
```
┌────────────────────────────────────────┐
│ CONTRÔLE SERVOMOTEUR                   │
│                                        │
│  ◄──────  AXE X (TILT)  ──────►      │
│            14.22°                      │
│ (boutons actifs, opacité 1.0)        │
└────────────────────────────────────────┘
```

### État Auto-Align ON (Automatique)
```
┌────────────────────────────────────────┐
│ CONTRÔLE SERVOMOTEUR                   │
│                                        │
│  ◄──────  AXE X (TILT)  ──────►      │
│            18.72°                      │
│ (boutons grisés, opacité 0.4)        │
└────────────────────────────────────────┘
```

## 🔧 Fichiers Modifiés

### 1. `AppState.java`
**Ajout de champs** :
- `fps`, `latency`, `signalQuality`, `stabilizationGain`

**Méthodes ajoutées** :
- `calculateStabilizationGain()` : Calcule le gain basé sur le gyroscope
- `calculateSignalQuality()` : Calcule SIG basé sur le RSSI
- `updatePerformanceMetrics()` : Met à jour FPS et LAT avec variabilité
- Getters/Setters pour tous les nouveaux champs

### 2. `FSOWebSocketClient.java`
**Modification dans `processMessage()` "sensors"** :
- Appel à `appState.calculateStabilizationGain()` quand gyroscope reçu

### 3. `fragment_alignment.xml`
**Ajout de 4 cartes métriques** (lignes ~237-400) :
- Card FPS avec `android:id="@+id/fps_value"`
- Card LAT avec `android:id="@+id/lat_value"`
- Card SIG avec `android:id="@+id/sig_value"`
- Card GAIN avec `android:id="@+id/gain_value"`

### 4. `AlignmentFragment.java`
**Ajout de variables** :
- `fpsValue`, `latValue`, `sigValue`, `gainValue`
- `btnServoLeft`, `btnServoRight`
- `performanceUpdateRunnable`

**Méthodes ajoutées** :
- `updateServoControlsState(boolean)` : Active/désactive les boutons servo
- `startPerformanceUpdater()` : Timer pour FPS/LAT (toutes les 1s)
- `stopPerformanceUpdater()` : Arrête le timer
- `onResume()`, `onPause()`, `onDestroy()` : Lifecycle

**Listeners modifiés** :
- Ajout de `updateServoControlsState()` dans le toggle listener
- Ajout de checks dans `moveServo()` pour empêcher le mouvement si auto-align ON
- Ajout des cas `fps`, `latency`, `signalQuality`, `stabilizationGain` dans le state listener

## 🔄 Flux de Données

### FPS et Latence
```
Timer (1s) → AppState.updatePerformanceMetrics()
           → Génère valeurs aléatoires réalistes
           → notifyChange("fps") / notifyChange("latency")
           → AlignmentFragment listener → UI Update
```

### Signal Quality (SIG)
```
WebSocket → RSSI reçu → AppState.recalculateRSSI()
                      → calculateSignalQuality()
                      → (RSSI + 80) / 50 × 100
                      → notifyChange("signalQuality")
                      → AlignmentFragment listener → UI Update
```

### Gain de Stabilisation
```
WebSocket → Gyroscope reçu → AppState.setLastGyro[XYZ]()
                            → calculateStabilizationGain()
                            → sqrt(gx² + gy² + gz²) / 50 × 100
                            → notifyChange("stabilizationGain")
                            → AlignmentFragment listener → UI Update
```

### Contrôle Servo
```
User clique bouton ← ou →
↓
moveServo(delta) check si auto-align OFF
↓
AppState.servoTilt += delta (limité -45° à +45°)
↓
notifyChange("servoTilt")
↓
wsClient.sendServoCommand("tilt", newTilt)
↓
ESP32 reçoit et ajuste le servo moteur
```

## 🧪 Tests

### Test 1 : Métriques Dynamiques
1. Ouvrir la page Alignement
2. Observer **FPS** : Doit varier entre 58-62 chaque seconde
3. Observer **LAT** : Doit varier entre 12-20ms chaque seconde
4. Observer **SIG** : Change avec le RSSI (si connecté)
5. Bouger le téléphone → Observer **GAIN** : Augmente avec le mouvement

### Test 2 : Switch Auto-Alignement
1. **Auto-align OFF** :
   - Cliquer ← → : La valeur d'angle change
   - Boutons sont actifs (opacité 1.0)
2. **Activer Auto-align** :
   - Cliquer ← → : Rien ne se passe
   - Boutons sont grisés (opacité 0.4)
3. **Désactiver Auto-align** :
   - Boutons redeviennent actifs

### Test 3 : Valeurs Servo Réelles
1. Auto-align OFF
2. Cliquer ← une fois : Angle diminue de 0.5° (ex: 14.22° → 13.72°)
3. Cliquer → une fois : Angle augmente de 0.5° (ex: 13.72° → 14.22°)
4. Maintenir ← : Angle décrémente continuellement
5. Vérifier que l'angle ne dépasse pas -45° ou +45°

### Test 4 : Qualité Signal avec RSSI
1. Se connecter au WebSocket
2. Aller dans Settings → Modifier Sensibilité/Réactivité
3. Observer que SIG change en temps réel dans Alignement

## 📝 Notes

- **FPS et LAT** sont simulés (pas de vraie caméra)
- **SIG** est calculé côté Android à partir du RSSI
- **GAIN** est calculé à partir des données réelles du gyroscope MPU6050
- Les contrôles servo envoient réellement des commandes WebSocket
- La logique auto-align est simulée (pas d'IA réelle), mais le switch fonctionne
- Les valeurs des métriques persistent dans `AppState` entre les pages
