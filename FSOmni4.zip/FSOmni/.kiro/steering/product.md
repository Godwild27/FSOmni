# FSOmni — Product Overview

FSOmni is an Android control and monitoring application for a **Free-Space Optical (FSO) communication system**. It connects to an ESP-based hardware node over a local Wi-Fi WebSocket link and provides a real-time dashboard for link telemetry, servo alignment control, encrypted message/file transfer, and system configuration.

## Core Screens

| Screen | Purpose |
|---|---|
| **Config** | Enter device IP, initiate WebSocket connection, verify link status |
| **Dashboard** | Monitor live telemetry: throughput, BER, RSSI, alignment precision, weather metrics |
| **Alignment** | Manual servo control (tilt axis), auto-align toggle via TinyML, signal quality feedback |
| **Transfer** | Encrypted chat (AES-128) and file transmission over the optical link |
| **Settings** | App and system configuration |

## Key Domain Concepts

- The hardware node is an ESP microcontroller reachable at a configurable IP (default `192.168.4.1`) on port `8080` over WebSocket.
- Telemetry is pushed by the device in JSON frames typed with a `"type"` field (`telemetry`, `weather`, `alignment`, `esp_status`, `channel_status`).
- The optical link uses AES-128 encryption for the Transfer screen.
- TinyML auto-alignment adjusts servo tilt automatically based on signal quality.
- UI language is **French** (labels, status text, chat messages).
