# Tech Stack

## Platform
- **Android** (native Java), `minSdk 24`, `targetSdk / compileSdk 34`
- **Java 17** (`sourceCompatibility` / `targetCompatibility VERSION_17`)
- Package namespace: `com.fso.fsoomni`

## Build System
- **Gradle** with Android Gradle Plugin `8.1.4`
- Single-module project: root project + `:app` module
- `viewBinding` enabled — always use ViewBinding to access views, never `findViewById` in new code
- ProGuard rules file present but minification disabled in release builds

## Key Libraries

| Library | Version | Usage |
|---|---|---|
| `androidx.appcompat` | 1.6.1 | Base Activity/Fragment support |
| `androidx.constraintlayout` | 2.1.4 | Layouts |
| `androidx.recyclerview` | 1.3.2 | Chat message list |
| `com.google.android.material` | 1.11.0 | Material components |
| `org.java-websocket:Java-WebSocket` | 1.5.4 | WebSocket client |
| `com.google.code.gson` | 2.10.1 | JSON parsing of WebSocket frames |
| `androidx.cardview` | 1.0.0 | Card containers |
| `androidx.swiperefreshlayout` | 1.1.0 | Pull-to-refresh |
| `androidx.core` | 1.12.0 | Core AndroidX utilities |

## Common Commands

```bash
# Assemble debug APK
./gradlew assembleDebug

# Assemble release APK
./gradlew assembleRelease

# Install debug build on connected device
./gradlew installDebug

# Run lint checks
./gradlew lint

# Clean build outputs
./gradlew clean
```

> On Windows use `gradlew.bat` instead of `./gradlew`.

## Notes
- `android.useAndroidX=true` and `android.enableJetifier=true` are set — always use AndroidX imports, never legacy support library.
- No test framework is currently configured (no unit test or instrumented test source sets present).
- `android:usesCleartextTraffic="true"` is set in the manifest — WebSocket connects over plain `ws://` (not `wss://`).
