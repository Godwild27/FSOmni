# Project Structure

## Root Layout

```
FSOmni/
├── build.gradle              # Root build file (AGP classpath)
├── settings.gradle           # Module includes (only :app)
├── gradle.properties         # JVM args, AndroidX flags
├── gradle/                   # Gradle wrapper files
└── app/                      # Single application module
    ├── build.gradle          # App-level dependencies, SDK versions, buildFeatures
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/fso/fsoomni/
        └── res/
```

## Java Source Packages

```
com.fso.fsoomni/
├── activity/
│   └── MainActivity.java         # Single activity host; owns AppState + FSOWebSocketClient
├── fragment/
│   ├── ConfigFragment.java        # IP entry, WebSocket connect/test
│   ├── DashboardFragment.java     # Live telemetry display
│   ├── AlignmentFragment.java     # Servo control + auto-align toggle
│   ├── TransferFragment.java      # Chat + file transmission (AES-128)
│   └── SettingsFragment.java      # TinyML sliders, ESP status
├── model/
│   ├── AppState.java              # Central shared state; observer pattern via OnStateChangeListener
│   ├── ChatMessage.java           # Chat message model (INCOMING / OUTGOING)
│   └── TransferFileItem.java      # File transfer history item
├── adapter/
│   └── ChatMessageAdapter.java    # RecyclerView adapter for chat
├── view/
│   ├── BarChartView.java          # Custom bar chart (throughput history)
│   ├── GaugeRingView.java         # Animated arc gauge (alignment precision)
│   ├── CameraCrosshairView.java   # Crosshair overlay for camera alignment
│   ├── WaveformView.java          # Animated voice waveform
│   └── ToggleSwitchView.java      # Custom toggle switch
├── websocket/
│   └── FSOWebSocketClient.java    # WebSocket wrapper; typed event dispatch
└── utils/                         # (empty — utilities go here)
```

## Resources

```
res/
├── layout/
│   ├── activity_main.xml
│   ├── fragment_config.xml
│   ├── fragment_dashboard.xml
│   ├── fragment_alignment.xml
│   ├── fragment_transfer.xml
│   ├── fragment_settings.xml
│   └── item_chat_message.xml
├── drawable/                      # All XML drawables (bg_*, ic_*)
│   └── bg_bento_card*.xml         # Bento-style card backgrounds (base, accent, error, nominal, surface)
├── anim/                          # Animation resources
└── font/                          # Custom font files
```

## Architecture Patterns

- **Single Activity / Multiple Fragments** — `MainActivity` is the sole Activity; all screens are Fragments swapped into `R.id.fragment_container`.
- **Shared state via `AppState`** — Fragments do not communicate directly. All live data lives in `AppState`, which fires `OnStateChangeListener` callbacks on mutation. Fragments register listeners in `onCreateView` and post UI updates to the main thread via `Handler(Looper.getMainLooper())`.
- **WebSocket event dispatch** — `FSOWebSocketClient` parses incoming JSON frames by `"type"` field, updates `AppState`, then notifies registered `WebSocketListener` callbacks. Listeners can subscribe to all events (`"*"`) or a specific type string.
- **Custom Views** — Stateless drawing logic is encapsulated in `view/` classes that extend `View`. They expose simple setters (`setProgress()`, `setValues()`) and handle their own animation/invalidation.
- **No ViewModel / LiveData** — The project uses a hand-rolled observer pattern (`AppState` + `OnStateChangeListener`) rather than Android Architecture Components.

## Naming Conventions

- Layouts: `activity_<name>.xml`, `fragment_<name>.xml`, `item_<name>.xml`
- Drawables: `bg_<component>_<variant>.xml` for backgrounds, `ic_<name>.xml` for icons
- Java classes: standard PascalCase; fragments suffixed `Fragment`, adapters suffixed `Adapter`, custom views no suffix
- Resource IDs: `snake_case`, prefixed by widget type where helpful (e.g. `btn_send`, `tv_label`, `nav_dashboard`)
- String keys in `AppState` callbacks match the field semantic (e.g. `"throughput"`, `"rssi"`, `"connected"`)
