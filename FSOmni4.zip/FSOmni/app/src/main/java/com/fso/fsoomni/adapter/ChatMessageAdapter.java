package com.fso.fsoomni.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fso.fsoomni.R;
import com.fso.fsoomni.model.ChatMessage;

import java.util.ArrayList;
import java.util.List;

public class ChatMessageAdapter extends RecyclerView.Adapter<ChatMessageAdapter.ViewHolder> {

    private final List<ChatMessage> messages = new ArrayList<>();
    private final Context context;
    private SaveMessagesCallback saveCallback;
    
    public interface SaveMessagesCallback {
        void onMessageAdded();
    }

    public ChatMessageAdapter(Context context) {
        this.context = context;
    }
    
    public void setSaveCallback(SaveMessagesCallback callback) {
        this.saveCallback = callback;
    }

    public void addMessage(ChatMessage message) {
        messages.add(message);
        notifyItemInserted(messages.size() - 1);
        
        // Sauvegarder automatiquement
        if (saveCallback != null) {
            saveCallback.onMessageAdded();
        }
    }

    public void setMessages(List<ChatMessage> messages) {
        this.messages.clear();
        this.messages.addAll(messages);
        notifyDataSetChanged();
    }
    
    public List<ChatMessage> getMessages() {
        return new ArrayList<>(messages);
    }
    
    public void clearMessages() {
        messages.clear();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_chat_message, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ChatMessage message = messages.get(position);

        LinearLayout root = holder.root;
        TextView sender = holder.sender;
        LinearLayout bubbleContainer = holder.bubbleContainer;
        TextView text = holder.text;
        TextView time = holder.time;

        if (message.getType() == ChatMessage.MessageType.INCOMING) {
            root.setGravity(Gravity.START);
            bubbleContainer.setBackgroundResource(R.drawable.bg_chat_incoming);
            text.setTextColor(context.getResources().getColor(R.color.chat_incoming_text, context.getTheme()));
            time.setTextColor(context.getResources().getColor(R.color.chat_incoming_time, context.getTheme()));

            if (message.getSender() != null && !message.getSender().isEmpty()) {
                sender.setVisibility(View.VISIBLE);
                sender.setText(message.getSender());
            } else {
                sender.setVisibility(View.GONE);
            }
        } else {
            root.setGravity(Gravity.END);
            bubbleContainer.setBackgroundResource(R.drawable.bg_chat_outgoing);
            text.setTextColor(Color.WHITE);
            time.setTextColor(Color.WHITE);
            sender.setVisibility(View.GONE);
        }

        text.setText(message.getText());
        time.setText(message.getTime());
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout root;
        TextView sender;
        LinearLayout bubbleContainer;
        TextView text;
        TextView time;

        ViewHolder(View itemView) {
            super(itemView);
            root = itemView.findViewById(R.id.chat_item_root);
            sender = itemView.findViewById(R.id.chat_sender);
            bubbleContainer = itemView.findViewById(R.id.chat_bubble);
            text = itemView.findViewById(R.id.chat_text);
            time = itemView.findViewById(R.id.chat_time);
        }
    }
}
