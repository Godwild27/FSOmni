package com.fso.fsoomni.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.fso.fsoomni.R;
import com.fso.fsoomni.FSOmniApp;
import com.fso.fsoomni.activity.MainActivity;
import com.fso.fsoomni.model.AppState;
import com.fso.fsoomni.websocket.FSOWebSocketClient;

/**
 * Service en arrière-plan pour maintenir la connexion WebSocket active
 * même quand l'application est en arrière-plan ou fermée.
 */
public class FSOBackgroundService extends Service {

    private static final String TAG = "FSOBackgroundService";
    private static final String CHANNEL_ID = "fso_background_channel";
    private static final int NOTIFICATION_ID = 1001;
    
    private AppState appState;
    private FSOWebSocketClient wsClient;
    private boolean isServiceRunning = false;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Service créé");
        
        // Récupérer les instances singleton
        appState = FSOmniApp.getAppState();
        wsClient = FSOmniApp.getWsClient();
        
        // Créer le canal de notification
        createNotificationChannel();
        
        // Démarrer en foreground immédiatement
        startForeground(NOTIFICATION_ID, createNotification(
            "FSOmni en arrière-plan", 
            "Liaison laser active"
        ));
        
        isServiceRunning = true;
        
        // Écouter les changements de connexion
        if (appState != null) {
            appState.addOnStateChangeListener((key, value) -> {
                if ("connected".equals(key)) {
                    updateNotification((Boolean) value);
                }
            });
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "Service démarré");
        
        // Vérifier l'action demandée
        if (intent != null) {
            String action = intent.getAction();
            if ("STOP_SERVICE".equals(action)) {
                // Déconnecter le WebSocket
                if (wsClient != null) {
                    wsClient.disconnect();
                }
                stopSelf();
                return START_NOT_STICKY;
            }
        }
        
        // Redémarrer automatiquement si le système tue le service
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Service détruit");
        isServiceRunning = false;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null; // Service non lié
    }

    /**
     * Créer le canal de notification (requis pour Android 8+)
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "FSOmni Service",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Maintient la connexion laser active en arrière-plan");
            channel.setShowBadge(false);
            
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    /**
     * Créer la notification persistante
     */
    private Notification createNotification(String title, String text) {
        // Intent pour ouvrir l'application
        Intent notificationIntent = new Intent(this, MainActivity.class);
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 
            0, 
            notificationIntent, 
            PendingIntent.FLAG_IMMUTABLE
        );
        
        // Intent pour arrêter le service
        Intent stopIntent = new Intent(this, FSOBackgroundService.class);
        stopIntent.setAction("STOP_SERVICE");
        
        PendingIntent stopPendingIntent = PendingIntent.getService(
            this, 
            0, 
            stopIntent, 
            PendingIntent.FLAG_IMMUTABLE
        );

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification) // Nous allons créer cette icône
            .setContentIntent(pendingIntent)
            .addAction(R.drawable.ic_stop, "Déconnecter", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build();
    }

    /**
     * Mettre à jour la notification selon l'état de connexion
     */
    private void updateNotification(boolean connected) {
        if (!isServiceRunning) return;
        
        String title = connected ? "FSOmni connecté" : "FSOmni déconnecté";
        String text = connected ? 
            "Liaison laser active - Transfert en cours" : 
            "En attente de connexion";
        
        Notification notification = createNotification(title, text);
        
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) {
            manager.notify(NOTIFICATION_ID, notification);
        }
    }
    
    /**
     * Vérifier si le service est en cours d'exécution
     */
    public static boolean isRunning() {
        return false; // Sera implémenté si nécessaire
    }
}
