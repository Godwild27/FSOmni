package com.fso.fsoomni.websocket;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;

/**
 * WebSocketManager — Gestion de la connexion WebSocket pour l'ÉTAPE 1
 * 
 * Cette classe gère la connexion WebSocket avec l'ESP32-S3.
 * Elle notifie l'activité des changements d'état via WebSocketListener.
 */
public class WebSocketManager {
    
    private static final String TAG = "WebSocketManager";
    
    // Client WebSocket
    private WebSocketClient wsClient;
    private String serverUrl;
    private boolean isConnected = false;
    
    // Handler pour revenir sur le thread UI
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    
    // Listener pour les événements WebSocket
    private WebSocketListener listener;
    
    /**
     * Interface pour recevoir les événements WebSocket
     */
    public interface WebSocketListener {
        void onConnected();
        void onDisconnected(String reason);
        void onMessage(String message);
        void onError(String error);
    }
    
    /**
     * Constructeur
     * @param listener Le listener pour recevoir les événements
     */
    public WebSocketManager(WebSocketListener listener) {
        this.listener = listener;
    }
    
    /**
     * Se connecter au serveur WebSocket
     * @param ipAddress L'adresse IP de l'ESP32 (ex: "192.168.4.1")
     */
    public void connect(String ipAddress) {
        if (isConnected) {
            Log.w(TAG, "Déjà connecté");
            return;
        }
        
        try {
            // Construction de l'URL WebSocket
            serverUrl = "ws://" + ipAddress + ":8080/ws";
            Log.d(TAG, "Connexion à : " + serverUrl);
            
            // Création du client WebSocket
            wsClient = new WebSocketClient(new URI(serverUrl)) {
                @Override
                public void onOpen(ServerHandshake handshakedata) {
                    Log.d(TAG, "WebSocket ouvert");
                    isConnected = true;
                    
                    // Notifier sur le thread UI
                    mainHandler.post(() -> {
                        if (listener != null) {
                            listener.onConnected();
                        }
                    });
                }
                
                @Override
                public void onMessage(String message) {
                    Log.d(TAG, "Message reçu : " + message);
                    
                    // Notifier sur le thread UI
                    mainHandler.post(() -> {
                        if (listener != null) {
                            listener.onMessage(message);
                        }
                    });
                }
                
                @Override
                public void onClose(int code, String reason, boolean remote) {
                    Log.d(TAG, "WebSocket fermé : " + reason);
                    isConnected = false;
                    
                    // Notifier sur le thread UI
                    mainHandler.post(() -> {
                        if (listener != null) {
                            listener.onDisconnected(reason);
                        }
                    });
                }
                
                @Override
                public void onError(Exception ex) {
                    Log.e(TAG, "Erreur WebSocket", ex);
                    isConnected = false;
                    
                    // Notifier sur le thread UI
                    mainHandler.post(() -> {
                        if (listener != null) {
                            listener.onError(ex.getMessage());
                        }
                    });
                }
            };
            
            // Lancer la connexion
            wsClient.connect();
            
        } catch (Exception e) {
            Log.e(TAG, "Erreur lors de la connexion", e);
            if (listener != null) {
                listener.onError(e.getMessage());
            }
        }
    }
    
    /**
     * Se déconnecter du serveur WebSocket
     */
    public void disconnect() {
        if (wsClient != null && isConnected) {
            wsClient.close();
            isConnected = false;
        }
    }
    
    /**
     * Vérifier si connecté
     * @return true si connecté, false sinon
     */
    public boolean isConnected() {
        return isConnected;
    }
    
    /**
     * Envoyer un message de façon thread-safe
     * @param message Le message à envoyer
     */
    public void safeSend(String message) {
        if (wsClient != null && isConnected) {
            try {
                wsClient.send(message);
                Log.d(TAG, "Message envoyé : " + message);
            } catch (Exception e) {
                Log.e(TAG, "Erreur lors de l'envoi", e);
            }
        }
    }
}
