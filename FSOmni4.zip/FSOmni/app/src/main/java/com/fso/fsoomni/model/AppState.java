package com.fso.fsoomni.model;

import java.util.concurrent.CopyOnWriteArrayList;

public class AppState {

    private boolean connected = false;
    private String ip = "192.168.4.1";
    private double servoTilt = 14.22;
    private boolean tinymlEnabled = true;
    private boolean autoAlignEnabled = true;
    private int signalSensitivity = 75;          // Seuil de sensibilité signal (0-100%)
    private int alignmentReactivity = 150;       // Réactivité correction d'alignement (ms)
    private double lastThroughput = 9.8;
    private double lastBer = 1.2e-9;
    private double lastRssi = -42;
    private double lastAlignmentPrecision = 90.0;
    private double lastLuminosity = 5000.0;       // Luminosité ambiante (lux)
    private double lastAttenuation = 0.4;          // Atténuation (dB/km)
    private double lastTemperature = 25.0;         // Température (°C)
    private double lastPressure = 1013.25;         // Pression (hPa)
    private double lastAltitude = 0.0;             // Altitude (m)
    private double lastAccelX = 0.0;               // Accélération X (g)
    private double lastAccelY = 0.0;               // Accélération Y (g)
    private double lastAccelZ = 1.0;               // Accélération Z (g)
    private double lastGyroX = 0.0;                // Gyroscope X (°/s)
    private double lastGyroY = 0.0;                // Gyroscope Y (°/s)
    private double lastGyroZ = 0.0;                // Gyroscope Z (°/s)
    private double lastVibration = 0.0;            // Niveau de vibration (0-100%)
    private double fps = 60.0;                     // Frames per second (caméra/tracking)
    private double latency = 15.0;                 // Latence en millisecondes
    private double signalQuality = 84.0;           // Qualité du signal (0-100%)
    private double stabilizationGain = 0.0;        // Gain de stabilisation basé sur gyroscope
    private double espTemp = 42.0;
    private double espEtat = 88.0;
    private String espUptime = "0h 00m 00s";
    private long connectionStartTime = 0; // Timestamp de connexion (millis)
    private double lightIntensity = -18.4;
    
    // Gestion de l'oscillation de l'état ESP
    private boolean espEtatHighState = true; // true = état élevé, false = état bas
    private long lastEspEtatToggle = 0; // Timestamp du dernier changement
    private static final long ESP_ETAT_TOGGLE_INTERVAL = 8000; // 8 secondes en millisecondes
    
    // TinyML performance tracking (24 heures)
    private double rssiWithoutTinyML = 0.0;     // RSSI moyen sans TinyML
    private double rssiWithTinyML = 0.0;        // RSSI moyen avec TinyML
    private int rssiSampleCount = 0;            // Nombre d'échantillons
    private double tinyMLImprovementPercent = 0.0; // % d'amélioration
    
    // Système de logs d'événements
    private final java.util.List<LogEvent> systemLogs = new java.util.ArrayList<>();
    private static final int MAX_LOGS = 100; // Garder les 100 derniers logs
    
    public static class LogEvent {
        public final String timestamp;
        public final String message;
        public final LogLevel level;
        
        public enum LogLevel {
            INFO, WARNING, ERROR, SUCCESS
        }
        
        public LogEvent(String message, LogLevel level) {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("HH:mm:ss");
            this.timestamp = sdf.format(new java.util.Date());
            this.message = message;
            this.level = level;
        }
    }

    // Channel status
    private String ch1Status = "ok";
    private String ch2Status = "ok";
    private String ch3Status = "ok";

    // ÉTAPE 2 : Numéro de l'unité (0 = non configuré)
    private int myUnitId = 0;

    // Bar chart data
    private int[] barValues = {65, 72, 58, 80, 92, 85, 70, 95, 88, 78, 90, 98};

    // Callback for state changes - supports multiple listeners
    public interface OnStateChangeListener {
        void onStateChanged(String key, Object value);
    }

    private final CopyOnWriteArrayList<OnStateChangeListener> listeners = new CopyOnWriteArrayList<>();

    public void addOnStateChangeListener(OnStateChangeListener listener) {
        if (listener != null && !listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public void removeOnStateChangeListener(OnStateChangeListener listener) {
        listeners.remove(listener);
    }

    private void notifyChange(String key, Object value) {
        for (OnStateChangeListener l : listeners) {
            l.onStateChanged(key, value);
        }
    }

    public boolean isConnected() {
        return connected;
    }

    public void setConnected(boolean connected) {
        this.connected = connected;
        notifyChange("connected", connected);
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public double getServoTilt() {
        return servoTilt;
    }

    public void setServoTilt(double servoTilt) {
        this.servoTilt = servoTilt;
        notifyChange("servoTilt", servoTilt);
    }

    public boolean isTinymlEnabled() {
        return tinymlEnabled;
    }

    public void setTinymlEnabled(boolean tinymlEnabled) {
        this.tinymlEnabled = tinymlEnabled;
        notifyChange("tinymlEnabled", tinymlEnabled);
    }

    public boolean isAutoAlignEnabled() {
        return autoAlignEnabled;
    }

    public void setAutoAlignEnabled(boolean autoAlignEnabled) {
        this.autoAlignEnabled = autoAlignEnabled;
        notifyChange("autoAlignEnabled", autoAlignEnabled);
    }

    public double getLastThroughput() {
        return lastThroughput;
    }

    public void setLastThroughput(double lastThroughput) {
        this.lastThroughput = lastThroughput;
        notifyChange("throughput", lastThroughput);
    }

    public double getLastBer() {
        return lastBer;
    }

    public void setLastBer(double lastBer) {
        this.lastBer = lastBer;
        notifyChange("ber", lastBer);
    }

    public double getLastRssi() {
        return lastRssi;
    }

    public void setLastRssi(double lastRssi) {
        this.lastRssi = lastRssi;
        notifyChange("rssi", lastRssi);
    }

    public double getLastAlignmentPrecision() {
        return lastAlignmentPrecision;
    }

    public void setLastAlignmentPrecision(double lastAlignmentPrecision) {
        this.lastAlignmentPrecision = lastAlignmentPrecision;
        notifyChange("alignmentPrecision", lastAlignmentPrecision);
    }

    public double getLastLuminosity() {
        return lastLuminosity;
    }

    public void setLastLuminosity(double lastLuminosity) {
        this.lastLuminosity = lastLuminosity;
        notifyChange("luminosity", lastLuminosity);
    }

    public double getLastAttenuation() {
        return lastAttenuation;
    }

    public void setLastAttenuation(double lastAttenuation) {
        this.lastAttenuation = lastAttenuation;
        notifyChange("attenuation", lastAttenuation);
    }

    public double getLastTemperature() {
        return lastTemperature;
    }

    public void setLastTemperature(double lastTemperature) {
        this.lastTemperature = lastTemperature;
        notifyChange("temperature", lastTemperature);
    }

    public double getLastPressure() {
        return lastPressure;
    }

    public void setLastPressure(double lastPressure) {
        this.lastPressure = lastPressure;
        notifyChange("pressure", lastPressure);
    }

    public double getLastAltitude() {
        return lastAltitude;
    }

    public void setLastAltitude(double lastAltitude) {
        this.lastAltitude = lastAltitude;
        notifyChange("altitude", lastAltitude);
    }

    public double getLastAccelX() {
        return lastAccelX;
    }

    public void setLastAccelX(double lastAccelX) {
        this.lastAccelX = lastAccelX;
        notifyChange("accelX", lastAccelX);
    }

    public double getLastAccelY() {
        return lastAccelY;
    }

    public void setLastAccelY(double lastAccelY) {
        this.lastAccelY = lastAccelY;
        notifyChange("accelY", lastAccelY);
    }

    public double getLastAccelZ() {
        return lastAccelZ;
    }

    public void setLastAccelZ(double lastAccelZ) {
        this.lastAccelZ = lastAccelZ;
        notifyChange("accelZ", lastAccelZ);
    }

    public double getLastGyroX() {
        return lastGyroX;
    }

    public void setLastGyroX(double lastGyroX) {
        this.lastGyroX = lastGyroX;
        notifyChange("gyroX", lastGyroX);
    }

    public double getLastGyroY() {
        return lastGyroY;
    }

    public void setLastGyroY(double lastGyroY) {
        this.lastGyroY = lastGyroY;
        notifyChange("gyroY", lastGyroY);
    }

    public double getLastGyroZ() {
        return lastGyroZ;
    }

    public void setLastGyroZ(double lastGyroZ) {
        this.lastGyroZ = lastGyroZ;
        notifyChange("gyroZ", lastGyroZ);
    }

    public double getLastVibration() {
        return lastVibration;
    }

    public void setLastVibration(double lastVibration) {
        this.lastVibration = lastVibration;
        notifyChange("vibration", lastVibration);
    }

    public double getEspTemp() {
        return espTemp;
    }

    public void setEspTemp(double espTemp) {
        this.espTemp = espTemp;
        notifyChange("espTemp", espTemp);
    }
    
    /**
     * Calculer la température ESP32 en fonction de la température ambiante
     * ESP32 = Température ambiante + 10-15°C + légère variation
     */
    public void calculateEspTemperature() {
        // Température de base : ambiante + offset (10-15°C)
        double offset = 12.0 + (Math.random() * 3.0); // 12-15°C
        
        // Légère variation aléatoire (-1 à +1°C)
        double variation = -1.0 + (Math.random() * 2.0);
        
        espTemp = lastTemperature + offset + variation;
        
        // Limiter entre 30°C et 85°C (plage normale ESP32)
        espTemp = Math.max(30, Math.min(85, espTemp));
        
        notifyChange("espTemp", espTemp);
    }

    public double getEspEtat() {
        return espEtat;
    }

    public void setEspEtat(double espEtat) {
        this.espEtat = espEtat;
        notifyChange("espEtat", espEtat);
    }
    
    /**
     * Mettre à jour l'état ESP32 (oscille toutes les 8 secondes)
     * État haut : 85-92%
     * État bas : 78-85%
     */
    public void updateEspEtat() {
        long currentTime = System.currentTimeMillis();
        
        // Initialiser le timestamp si c'est la première fois
        if (lastEspEtatToggle == 0) {
            lastEspEtatToggle = currentTime;
        }
        
        // Vérifier si 8 secondes se sont écoulées
        if (currentTime - lastEspEtatToggle >= ESP_ETAT_TOGGLE_INTERVAL) {
            // Basculer entre état haut et bas
            espEtatHighState = !espEtatHighState;
            lastEspEtatToggle = currentTime;
        }
        
        // Calculer la valeur selon l'état
        if (espEtatHighState) {
            // État élevé : 85-92% avec légère variation
            espEtat = 88.0 + (Math.random() * 4.0); // 88-92%
        } else {
            // État bas : 78-85% avec légère variation
            espEtat = 80.0 + (Math.random() * 5.0); // 80-85%
        }
        
        notifyChange("espEtat", espEtat);
    }

    public String getEspUptime() {
        return espUptime;
    }

    public void setEspUptime(String espUptime) {
        this.espUptime = espUptime;
        notifyChange("espUptime", espUptime);
    }
    
    /**
     * Démarrer le compteur d'uptime lors de la connexion
     */
    public void startUptimeCounter() {
        connectionStartTime = System.currentTimeMillis();
    }
    
    /**
     * Calculer l'uptime depuis la connexion
     */
    public void updateUptime() {
        if (connectionStartTime == 0) {
            espUptime = "0h 00m 00s";
            return;
        }
        
        long elapsedMillis = System.currentTimeMillis() - connectionStartTime;
        long seconds = elapsedMillis / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;
        
        if (days > 0) {
            espUptime = String.format("%dj %02dh %02dm", days, hours % 24, minutes % 60);
        } else if (hours > 0) {
            espUptime = String.format("%dh %02dm %02ds", hours, minutes % 60, seconds % 60);
        } else {
            espUptime = String.format("%dm %02ds", minutes, seconds % 60);
        }
        
        notifyChange("espUptime", espUptime);
    }

    public long getConnectionStartTime() {
        return connectionStartTime;
    }

    public double getLightIntensity() {
        return lightIntensity;
    }

    public void setLightIntensity(double lightIntensity) {
        this.lightIntensity = lightIntensity;
        notifyChange("lightIntensity", lightIntensity);
    }

    public String getCh1Status() {
        return ch1Status;
    }

    public void setCh1Status(String ch1Status) {
        this.ch1Status = ch1Status;
    }

    public String getCh2Status() {
        return ch2Status;
    }

    public void setCh2Status(String ch2Status) {
        this.ch2Status = ch2Status;
    }

    public String getCh3Status() {
        return ch3Status;
    }

    public void setCh3Status(String ch3Status) {
        this.ch3Status = ch3Status;
    }

    public int[] getBarValues() {
        return barValues;
    }

    public void pushBarValue(int newValue) {
        // Shift all values left
        System.arraycopy(barValues, 1, barValues, 0, barValues.length - 1);
        barValues[barValues.length - 1] = newValue;
        notifyChange("barValues", barValues);
    }

    // ================================================================
    // ÉTAPE 2 : Gestion du numéro d'unité
    // ================================================================

    public int getMyUnitId() {
        return myUnitId;
    }

    public void setMyUnitId(int myUnitId) {
        this.myUnitId = myUnitId;
        notifyChange("myUnitId", myUnitId);
    }

    public boolean isUnitIdConfigured() {
        return myUnitId > 0;
    }

    public int getSignalSensitivity() {
        return signalSensitivity;
    }

    public void setSignalSensitivity(int signalSensitivity) {
        this.signalSensitivity = signalSensitivity;
        notifyChange("signalSensitivity", signalSensitivity);
    }

    public int getAlignmentReactivity() {
        return alignmentReactivity;
    }

    public void setAlignmentReactivity(int alignmentReactivity) {
        this.alignmentReactivity = alignmentReactivity;
        notifyChange("alignmentReactivity", alignmentReactivity);
    }

    // ================================================================
    // CALCULS DYNAMIQUES BASÉS SUR LUMINOSITÉ ET TINYML
    // ================================================================

    /**
     * Calculer le BER en fonction de la luminosité
     * Luminosité faible → BER élevé (mauvaise qualité)
     * Luminosité élevée → BER faible (bonne qualité)
     */
    public void recalculateBER() {
        // BER optimal : 1e-9 pour luminosité élevée (>10000 lux)
        // BER dégradé : jusqu'à 1e-5 pour luminosité faible (<100 lux)
        double lux = Math.max(1, lastLuminosity); // Éviter division par 0
        double berFactor;
        
        if (lux < 100) {
            // Très faible luminosité : BER entre 1e-5 et 1e-6
            berFactor = 1e-5;
        } else if (lux < 1000) {
            // Faible luminosité : BER entre 1e-6 et 1e-7
            berFactor = 1e-6 + (1000 - lux) / 1000 * (1e-5 - 1e-6);
        } else if (lux < 10000) {
            // Luminosité moyenne : BER entre 1e-7 et 1e-8
            berFactor = 1e-7 + (10000 - lux) / 10000 * (1e-6 - 1e-7);
        } else {
            // Haute luminosité : BER optimal entre 1e-8 et 1e-9
            berFactor = 1e-9 + (30000 - Math.min(lux, 30000)) / 30000 * (1e-8 - 1e-9);
        }
        
        lastBer = berFactor;
        notifyChange("ber", lastBer);
    }

    /**
     * Calculer l'atténuation en fonction de la luminosité
     * Luminosité faible → atténuation élevée (brouillard/obstruction)
     * Luminosité élevée → atténuation faible (air clair)
     */
    public void recalculateAttenuation() {
        double lux = Math.max(1, lastLuminosity);
        double attenuation;
        
        if (lux < 100) {
            // Très faible luminosité : forte atténuation (3-5 dB/km)
            attenuation = 3.0 + (100 - lux) / 100 * 2.0;
        } else if (lux < 1000) {
            // Faible luminosité : atténuation moyenne (1-3 dB/km)
            attenuation = 1.0 + (1000 - lux) / 1000 * 2.0;
        } else if (lux < 10000) {
            // Luminosité moyenne : faible atténuation (0.3-1 dB/km)
            attenuation = 0.3 + (10000 - lux) / 10000 * 0.7;
        } else {
            // Haute luminosité : atténuation minimale (0.1-0.3 dB/km)
            attenuation = 0.1 + (30000 - Math.min(lux, 30000)) / 30000 * 0.2;
        }
        
        lastAttenuation = attenuation;
        notifyChange("attenuation", lastAttenuation);
    }

    /**
     * Calculer le RSSI en fonction de la sensibilité signal et de la réactivité
     * Sensibilité élevée + Réactivité faible → RSSI meilleur (signal fort)
     * Sensibilité faible + Réactivité élevée → RSSI dégradé (signal faible)
     */
    public void recalculateRSSI() {
        double rssiWithoutML = -80; // RSSI de base sans TinyML
        
        if (!tinymlEnabled) {
            // TinyML désactivé : RSSI par défaut moyen (-50 dBm)
            lastRssi = -50;
            rssiWithoutTinyML = lastRssi;
        } else {
            // RSSI optimal : -30 dBm (très fort)
            // RSSI dégradé : -80 dBm (très faible)
            
            // Sensibilité : 0-100% → influence 60% du RSSI
            // Réactivité : 0-500ms → influence 40% du RSSI (réactivité faible = meilleur signal)
            
            double sensitivityFactor = signalSensitivity / 100.0; // 0.0 à 1.0
            double reactivityFactor = 1.0 - Math.min(alignmentReactivity, 500) / 500.0; // 0.0 à 1.0 (inversé)
            
            // Formule : RSSI = -80 + (50 * combinaison)
            double combinedFactor = (sensitivityFactor * 0.6) + (reactivityFactor * 0.4);
            lastRssi = -80 + (50 * combinedFactor);
            rssiWithTinyML = lastRssi;
            
            // Simuler le RSSI sans TinyML (environ -50 dBm)
            rssiWithoutML = -50;
        }
        
        // Mettre à jour les statistiques de performance TinyML
        updateTinyMLPerformance(rssiWithoutML, lastRssi);
        
        notifyChange("rssi", lastRssi);
    }
    
    /**
     * Mettre à jour les statistiques de performance TinyML
     */
    private void updateTinyMLPerformance(double rssiWithout, double rssiWith) {
        rssiSampleCount++;
        
        // Moyenne mobile
        rssiWithoutTinyML = ((rssiWithoutTinyML * (rssiSampleCount - 1)) + rssiWithout) / rssiSampleCount;
        rssiWithTinyML = ((rssiWithTinyML * (rssiSampleCount - 1)) + rssiWith) / rssiSampleCount;
        
        // Calculer l'amélioration en pourcentage
        // Amélioration = (RSSI_avec_TinyML - RSSI_sans_TinyML) / |RSSI_sans_TinyML| * 100
        // Exemple : (-35 - (-50)) / 50 * 100 = 30% d'amélioration
        if (rssiWithoutTinyML != 0) {
            double improvement = (rssiWithTinyML - rssiWithoutTinyML) / Math.abs(rssiWithoutTinyML) * 100;
            tinyMLImprovementPercent = Math.max(0, improvement); // Ne pas afficher de valeurs négatives
        }
        
        // Recalculer la qualité du signal basée sur le nouveau RSSI
        calculateSignalQuality();
        
        notifyChange("tinyMLImprovement", tinyMLImprovementPercent);
    }
    
    public double getTinyMLImprovementPercent() {
        return tinyMLImprovementPercent;
    }
    
    public void resetTinyMLStats() {
        rssiWithoutTinyML = 0.0;
        rssiWithTinyML = 0.0;
        rssiSampleCount = 0;
        tinyMLImprovementPercent = 0.0;
    }
    
    // ================================================================
    // FPS, Latence, Signal Quality, Stabilization Gain
    // ================================================================
    
    public double getFps() {
        return fps;
    }
    
    public void setFps(double fps) {
        this.fps = fps;
        notifyChange("fps", fps);
    }
    
    public double getLatency() {
        return latency;
    }
    
    public void setLatency(double latency) {
        this.latency = latency;
        notifyChange("latency", latency);
    }
    
    public double getSignalQuality() {
        return signalQuality;
    }
    
    public void setSignalQuality(double signalQuality) {
        this.signalQuality = signalQuality;
        notifyChange("signalQuality", signalQuality);
    }
    
    public double getStabilizationGain() {
        return stabilizationGain;
    }
    
    public void setStabilizationGain(double stabilizationGain) {
        this.stabilizationGain = stabilizationGain;
        notifyChange("stabilizationGain", stabilizationGain);
    }
    
    /**
     * Calculer le gain de stabilisation basé sur le gyroscope
     * Plus le mouvement est important, plus le gain est élevé
     */
    public void calculateStabilizationGain() {
        // Magnitude du mouvement angulaire (°/s)
        double gyroMagnitude = Math.sqrt(
            lastGyroX * lastGyroX +
            lastGyroY * lastGyroY +
            lastGyroZ * lastGyroZ
        );
        
        // Gain = fonction du mouvement (0-100%)
        // 0°/s = 0% gain, 50°/s+ = 100% gain
        stabilizationGain = Math.min(100, (gyroMagnitude / 50.0) * 100);
        notifyChange("stabilizationGain", stabilizationGain);
    }
    
    /**
     * Calculer la qualité du signal basée sur le RSSI
     * RSSI élevé (-30) = 100% signal
     * RSSI faible (-80) = 0% signal
     */
    public void calculateSignalQuality() {
        // Formule : (RSSI + 80) / 50 * 100
        // -80 dBm = 0%, -30 dBm = 100%
        signalQuality = Math.max(0, Math.min(100, ((lastRssi + 80) / 50.0) * 100));
        notifyChange("signalQuality", signalQuality);
    }
    
    /**
     * Simuler FPS et Latence (valeurs réalistes avec variabilité)
     */
    public void updatePerformanceMetrics() {
        // FPS : varie entre 55-62 fps (simulation réaliste)
        fps = 58.0 + (Math.random() * 4.0);
        notifyChange("fps", fps);
        
        // Latence : varie entre 10-20ms en fonction de la charge
        latency = 12.0 + (Math.random() * 8.0);
        notifyChange("latency", latency);
    }
    
    // ================================================================
    // Système de Logs d'Événements
    // ================================================================
    
    /**
     * Ajouter un log événement
     */
    public void addLog(String message, LogEvent.LogLevel level) {
        LogEvent log = new LogEvent(message, level);
        systemLogs.add(0, log); // Ajouter au début (plus récent en premier)
        
        // Limiter à MAX_LOGS
        if (systemLogs.size() > MAX_LOGS) {
            systemLogs.remove(systemLogs.size() - 1);
        }
        
        notifyChange("newLog", log);
    }
    
    /**
     * Obtenir les N derniers logs
     */
    public java.util.List<LogEvent> getRecentLogs(int count) {
        int size = Math.min(count, systemLogs.size());
        return new java.util.ArrayList<>(systemLogs.subList(0, size));
    }
    
    /**
     * Obtenir tous les logs
     */
    public java.util.List<LogEvent> getAllLogs() {
        return new java.util.ArrayList<>(systemLogs);
    }
    
    /**
     * Effacer tous les logs
     */
    public void clearLogs() {
        systemLogs.clear();
        notifyChange("logsCleared", true);
    }
    
    // ================================================================
    // Persistance des Messages de Chat
    // ================================================================
    
    private static final String PREFS_CHAT_MESSAGES = "chat_messages";
    private static final int MAX_MESSAGES = 200; // Limiter à 200 messages
    
    /**
     * Sauvegarder les messages dans SharedPreferences
     */
    public void saveChatMessages(java.util.List<com.fso.fsoomni.model.ChatMessage> messages, 
                                  android.content.Context context) {
        if (context == null) return;
        
        try {
            com.google.gson.JsonArray jsonArray = new com.google.gson.JsonArray();
            
            // Limiter au nombre maximum de messages
            int startIndex = Math.max(0, messages.size() - MAX_MESSAGES);
            java.util.List<com.fso.fsoomni.model.ChatMessage> messagesToSave = 
                messages.subList(startIndex, messages.size());
            
            for (com.fso.fsoomni.model.ChatMessage message : messagesToSave) {
                jsonArray.add(message.toJson());
            }
            
            String jsonString = new com.google.gson.Gson().toJson(jsonArray);
            
            context.getSharedPreferences(com.fso.fsoomni.FSOmniApp.PREFS_NAME, 
                                        android.content.Context.MODE_PRIVATE)
                .edit()
                .putString(PREFS_CHAT_MESSAGES, jsonString)
                .apply();
                
            android.util.Log.d("AppState", "Messages sauvegardés : " + messagesToSave.size());
        } catch (Exception e) {
            android.util.Log.e("AppState", "Erreur sauvegarde messages : " + e.getMessage());
        }
    }
    
    /**
     * Charger les messages depuis SharedPreferences
     */
    public java.util.List<com.fso.fsoomni.model.ChatMessage> loadChatMessages(android.content.Context context) {
        java.util.List<com.fso.fsoomni.model.ChatMessage> messages = new java.util.ArrayList<>();
        
        if (context == null) return messages;
        
        try {
            String jsonString = context.getSharedPreferences(com.fso.fsoomni.FSOmniApp.PREFS_NAME, 
                                                            android.content.Context.MODE_PRIVATE)
                .getString(PREFS_CHAT_MESSAGES, null);
            
            if (jsonString != null && !jsonString.isEmpty()) {
                com.google.gson.JsonArray jsonArray = com.google.gson.JsonParser.parseString(jsonString)
                    .getAsJsonArray();
                
                for (com.google.gson.JsonElement element : jsonArray) {
                    com.google.gson.JsonObject jsonObject = element.getAsJsonObject();
                    messages.add(com.fso.fsoomni.model.ChatMessage.fromJson(jsonObject));
                }
                
                android.util.Log.d("AppState", "Messages chargés : " + messages.size());
            }
        } catch (Exception e) {
            android.util.Log.e("AppState", "Erreur chargement messages : " + e.getMessage());
        }
        
        return messages;
    }
    
    /**
     * Effacer tous les messages sauvegardés
     */
    public void clearChatMessages(android.content.Context context) {
        if (context == null) return;
        
        context.getSharedPreferences(com.fso.fsoomni.FSOmniApp.PREFS_NAME, 
                                    android.content.Context.MODE_PRIVATE)
            .edit()
            .remove(PREFS_CHAT_MESSAGES)
            .apply();
            
        android.util.Log.d("AppState", "Messages effacés");
    }
}
