package com.fso.fsoomni.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.fso.fsoomni.R;
import com.fso.fsoomni.model.AppState;
import com.fso.fsoomni.view.ToggleSwitchView;
import com.fso.fsoomni.websocket.FSOWebSocketClient;

public class AlignmentFragment extends Fragment {

    private AppState appState;
    private FSOWebSocketClient wsClient;
    private Handler handler = new Handler(Looper.getMainLooper());

    private ToggleSwitchView toggleAutoAlign;
    private TextView servoXValue;
    private TextView alignBerValue;
    private View alignBerProgress;
    private TextView lightIntensityValue;
    private View lightIntensityProgress;
    private TextView fpsValue;
    private TextView latValue;
    private TextView sigValue;
    private TextView gainValue;
    private ImageButton btnServoLeft;
    private ImageButton btnServoRight;
    private Runnable performanceUpdateRunnable;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() != null) {
            appState = ((com.fso.fsoomni.activity.MainActivity) getActivity()).getAppState();
            wsClient = ((com.fso.fsoomni.activity.MainActivity) getActivity()).getWsClient();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_alignment, container, false);

        toggleAutoAlign = view.findViewById(R.id.toggle_auto_align);
        servoXValue = view.findViewById(R.id.servo_x_value);
        alignBerValue = view.findViewById(R.id.align_ber_value);
        alignBerProgress = view.findViewById(R.id.align_ber_progress);
        lightIntensityValue = view.findViewById(R.id.light_intensity_value);
        lightIntensityProgress = view.findViewById(R.id.light_intensity_progress);
        fpsValue = view.findViewById(R.id.fps_value);
        latValue = view.findViewById(R.id.lat_value);
        sigValue = view.findViewById(R.id.sig_value);
        gainValue = view.findViewById(R.id.gain_value);

        // Initialize toggle
        if (appState != null) {
            toggleAutoAlign.setChecked(appState.isAutoAlignEnabled());
        }

        // Toggle listener
        toggleAutoAlign.setOnCheckedChangeListener(isChecked -> {
            if (appState != null) {
                appState.setAutoAlignEnabled(isChecked);
            }
            if (wsClient != null) {
                wsClient.sendAutoAlignCommand(isChecked);
            }
            // Activer/désactiver les contrôles servo
            updateServoControlsState(isChecked);
        });

        // Servo left
        btnServoLeft = view.findViewById(R.id.btn_servo_left);
        btnServoLeft.setOnClickListener(v -> moveServo(-0.5));

        btnServoLeft.setOnTouchListener(new View.OnTouchListener() {
            private Handler repeatHandler = new Handler(Looper.getMainLooper());
            private Runnable repeatRunnable;

            @Override
            public boolean onTouch(View v, android.view.MotionEvent event) {
                if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                    v.setAlpha(0.7f);
                    repeatRunnable = () -> moveServo(-0.5);
                    repeatHandler.postDelayed(repeatRunnable, 200);
                    return true;
                } else if (event.getAction() == android.view.MotionEvent.ACTION_UP) {
                    v.setAlpha(1.0f);
                    if (repeatRunnable != null) repeatHandler.removeCallbacks(repeatRunnable);
                    return true;
                } else if (event.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
                    v.setAlpha(1.0f);
                    if (repeatRunnable != null) repeatHandler.removeCallbacks(repeatRunnable);
                    return true;
                }
                return false;
            }
        });

        // Servo right
        btnServoRight = view.findViewById(R.id.btn_servo_right);
        btnServoRight.setOnClickListener(v -> moveServo(0.5));

        btnServoRight.setOnTouchListener(new View.OnTouchListener() {
            private Handler repeatHandler = new Handler(Looper.getMainLooper());
            private Runnable repeatRunnable;

            @Override
            public boolean onTouch(View v, android.view.MotionEvent event) {
                if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                    v.setAlpha(0.7f);
                    repeatRunnable = () -> moveServo(0.5);
                    repeatHandler.postDelayed(repeatRunnable, 200);
                    return true;
                } else if (event.getAction() == android.view.MotionEvent.ACTION_UP) {
                    v.setAlpha(1.0f);
                    if (repeatRunnable != null) repeatHandler.removeCallbacks(repeatRunnable);
                    return true;
                } else if (event.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
                    v.setAlpha(1.0f);
                    if (repeatRunnable != null) repeatHandler.removeCallbacks(repeatRunnable);
                    return true;
                }
                return false;
            }
        });

        // State listener
        if (appState != null) {
            appState.addOnStateChangeListener((key, value) -> handler.post(() -> {
                switch (key) {
                    case "servoTilt":
                        servoXValue.setText(String.format("%.2f°", (Double) value));
                        break;
                    case "ber":
                        double ber = (Double) value;
                        alignBerValue.setText(String.format("%.0e", ber).replace("e-0", "⁻"));
                        break;
                    case "luminosity":
                        // Intensité lumineuse = luminosité du capteur (en lux)
                        double lux = (Double) value;
                        lightIntensityValue.setText(String.format("%.0f lux", lux));
                        // Barre de progression : 0 lux = 0%, 30000+ lux = 100%
                        int progress = (int) Math.max(0, Math.min(100, (lux / 30000.0) * 100));
                        View parent = (View) lightIntensityProgress.getParent();
                        if (parent.getWidth() > 0) {
                            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) lightIntensityProgress.getLayoutParams();
                            params.width = (int) (progress / 100f * parent.getWidth());
                            lightIntensityProgress.setLayoutParams(params);
                        }
                        break;
                    case "fps":
                        fpsValue.setText(String.format("%.1f", (Double) value));
                        break;
                    case "latency":
                        latValue.setText(String.format("%.0fms", (Double) value));
                        break;
                    case "signalQuality":
                        sigValue.setText(String.format("%.0f%%", (Double) value));
                        break;
                    case "stabilizationGain":
                        gainValue.setText(String.format("%.0f%%", (Double) value));
                        break;
                }
            }));
        }
        
        // Mettre à jour l'état initial des contrôles servo
        if (appState != null) {
            updateServoControlsState(appState.isAutoAlignEnabled());
        }
        
        // Démarrer la mise à jour périodique des métriques de performance
        startPerformanceUpdater();

        return view;
    }
    
    /**
     * Activer ou désactiver les contrôles servo selon l'auto-alignement
     */
    private void updateServoControlsState(boolean autoAlignEnabled) {
        // Si auto-align est ON, désactiver les contrôles manuels
        // Si auto-align est OFF, activer les contrôles manuels
        boolean manualControlEnabled = !autoAlignEnabled;
        
        if (btnServoLeft != null) {
            btnServoLeft.setEnabled(manualControlEnabled);
            btnServoLeft.setAlpha(manualControlEnabled ? 1.0f : 0.4f);
        }
        
        if (btnServoRight != null) {
            btnServoRight.setEnabled(manualControlEnabled);
            btnServoRight.setAlpha(manualControlEnabled ? 1.0f : 0.4f);
        }
    }
    
    /**
     * Démarrer la mise à jour périodique des métriques FPS et Latence
     */
    private void startPerformanceUpdater() {
        performanceUpdateRunnable = new Runnable() {
            @Override
            public void run() {
                if (appState != null) {
                    appState.updatePerformanceMetrics();
                }
                handler.postDelayed(this, 1000); // Mise à jour toutes les secondes
            }
        };
        handler.post(performanceUpdateRunnable);
    }
    
    /**
     * Arrêter la mise à jour des métriques
     */
    private void stopPerformanceUpdater() {
        if (performanceUpdateRunnable != null) {
            handler.removeCallbacks(performanceUpdateRunnable);
        }
    }

    private void moveServo(double delta) {
        if (appState == null) return;
        
        // Ne pas bouger si auto-align est activé
        if (appState.isAutoAlignEnabled()) {
            return;
        }

        double newTilt = appState.getServoTilt() + delta;
        newTilt = Math.max(-45, Math.min(45, newTilt));
        appState.setServoTilt(newTilt);
        servoXValue.setText(String.format("%.2f°", newTilt));

        if (wsClient != null) {
            wsClient.sendServoCommand("tilt", newTilt);
        }
    }
    
    @Override
    public void onResume() {
        super.onResume();
        if (appState != null) {
            // Mettre à jour les valeurs initiales
            servoXValue.setText(String.format("%.2f°", appState.getServoTilt()));
            alignBerValue.setText(String.format("%.0e", appState.getLastBer()).replace("e-0", "⁻"));
            lightIntensityValue.setText(String.format("%.0f lux", appState.getLastLuminosity()));
            fpsValue.setText(String.format("%.1f", appState.getFps()));
            latValue.setText(String.format("%.0fms", appState.getLatency()));
            sigValue.setText(String.format("%.0f%%", appState.getSignalQuality()));
            gainValue.setText(String.format("%.0f%%", appState.getStabilizationGain()));
        }
    }
    
    @Override
    public void onPause() {
        super.onPause();
        stopPerformanceUpdater();
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        stopPerformanceUpdater();
    }
}
