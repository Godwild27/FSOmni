package com.fso.fsoomni.view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

public class GaugeRingView extends View {

    private float progress = 0.9f; // 90%
    private float animatedProgress = 0.9f;

    private Paint trackPaint;
    private Paint fillPaint;
    private Paint textPaint;
    private Paint labelPaint;
    private LinearGradient gradient;

    private RectF arcRect = new RectF();

    public GaugeRingView(Context context) {
        super(context);
        init();
    }

    public GaugeRingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public GaugeRingView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs);
        init();
    }

    private void init() {
        trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        trackPaint.setStyle(Paint.Style.STROKE);
        trackPaint.setColor(Color.parseColor("#E3E2E6"));
        trackPaint.setStrokeWidth(8f * getResources().getDisplayMetrics().density);
        trackPaint.setStrokeCap(Paint.Cap.ROUND);

        fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        fillPaint.setStyle(Paint.Style.STROKE);
        fillPaint.setColor(Color.parseColor("#00488D"));
        fillPaint.setStrokeWidth(8f * getResources().getDisplayMetrics().density);
        fillPaint.setStrokeCap(Paint.Cap.ROUND);

        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.parseColor("#00488D"));
        textPaint.setTextSize(22f * getResources().getDisplayMetrics().scaledDensity);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

        labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        labelPaint.setColor(Color.parseColor("#424752"));
        labelPaint.setTextSize(9f * getResources().getDisplayMetrics().scaledDensity);
        labelPaint.setTextAlign(Paint.Align.CENTER);
    }

    public void setProgress(float progress) {
        this.progress = Math.max(0, Math.min(1, progress));

        ValueAnimator anim = ValueAnimator.ofFloat(animatedProgress, this.progress);
        anim.setDuration(1000);
        anim.setInterpolator(new AccelerateDecelerateInterpolator());
        anim.addUpdateListener(animation -> {
            animatedProgress = (float) animation.getAnimatedValue();
            invalidate();
        });
        anim.start();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        float padding = 10f * getResources().getDisplayMetrics().density;
        float radius = (Math.min(w, h) / 2f) - padding;
        float cx = w / 2f;
        float cy = h / 2f;
        arcRect.set(cx - radius, cy - radius, cx + radius, cy + radius);

        // Create gradient
        gradient = new LinearGradient(0, arcRect.top, 0, arcRect.bottom,
                Color.parseColor("#00488D"), Color.parseColor("#005FB8"),
                Shader.TileMode.CLAMP);
        fillPaint.setShader(gradient);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (arcRect.width() == 0 || arcRect.height() == 0) return;

        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;

        // Draw track (full circle)
        canvas.drawArc(arcRect, 0, 360, false, trackPaint);

        // Draw fill (partial arc, starting from top -90 degrees)
        float sweepAngle = 360 * animatedProgress;
        canvas.drawArc(arcRect, -90, sweepAngle, false, fillPaint);

        // Draw center text
        String percentText = Math.round(animatedProgress * 100) + "%";
        float textY = cy - 4f * getResources().getDisplayMetrics().density;
        canvas.drawText(percentText, cx, textY, textPaint);

        // Draw label below
        String labelText = "PRÉCISION";
        float labelY = cy + 14f * getResources().getDisplayMetrics().density;
        canvas.drawText(labelText, cx, labelY, labelPaint);
    }
}
