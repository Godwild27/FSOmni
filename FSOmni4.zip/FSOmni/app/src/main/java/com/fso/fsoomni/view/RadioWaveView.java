package com.fso.fsoomni.view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import androidx.annotation.Nullable;

/**
 * Vue personnalisée pour afficher des ondes radio qui partent d'un point central
 * et se propagent horizontalement vers la gauche et la droite.
 */
public class RadioWaveView extends View {

    private Paint wavePaint;
    private ValueAnimator animator;
    private float animationProgress = 0f;
    private int waveColor = 0xFF00488D; // Bleu par défaut
    private static final int WAVE_COUNT = 5;
    private static final float MAX_WAVE_WIDTH = 200f; // Distance maximale en dp
    private static final float WAVE_SPACING = 40f; // Espacement entre les ondes en dp

    public RadioWaveView(Context context) {
        super(context);
        init();
    }

    public RadioWaveView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public RadioWaveView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        wavePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        wavePaint.setStyle(Paint.Style.STROKE);
        wavePaint.setStrokeWidth(3f);
    }

    public void setWaveColor(int color) {
        this.waveColor = color;
        invalidate();
    }

    public void startAnimation() {
        stopAnimation();
        
        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(2000); // 2 secondes par cycle
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(animation -> {
            animationProgress = (float) animation.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    public void stopAnimation() {
        if (animator != null && animator.isRunning()) {
            animator.cancel();
        }
        animationProgress = 0f;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (animationProgress == 0f) {
            return; // Pas d'animation, ne rien dessiner
        }

        float centerX = getWidth() / 2f;
        float centerY = getHeight() / 2f;
        float density = getResources().getDisplayMetrics().density;
        float maxWidth = MAX_WAVE_WIDTH * density;
        float spacing = WAVE_SPACING * density;

        // Dessiner 5 couches d'ondes
        for (int i = 0; i < WAVE_COUNT; i++) {
            // Calculer l'offset de cette onde basé sur l'animation et son index
            float waveOffset = (animationProgress + (i * 0.2f)) % 1f;
            
            // Calculer la largeur et la hauteur de cette onde
            float waveWidth = waveOffset * maxWidth;
            float waveHeight = 30f * density * (1f - waveOffset * 0.5f); // Hauteur diminue légèrement
            
            // Calculer l'opacité (fade out progressif)
            int alpha = (int) (255 * (1f - waveOffset) * 0.8f);
            wavePaint.setColor(waveColor);
            wavePaint.setAlpha(alpha);
            
            // Dessiner l'onde gauche (arc de cercle)
            float left = centerX - waveWidth - waveHeight / 2f;
            float top = centerY - waveHeight / 2f;
            float right = centerX - waveWidth + waveHeight / 2f;
            float bottom = centerY + waveHeight / 2f;
            
            if (left > 0) {
                canvas.drawArc(left, top, right, bottom, -90, 180, false, wavePaint);
            }
            
            // Dessiner l'onde droite (arc de cercle)
            left = centerX + waveWidth - waveHeight / 2f;
            right = centerX + waveWidth + waveHeight / 2f;
            
            if (right < getWidth()) {
                canvas.drawArc(left, top, right, bottom, 90, 180, false, wavePaint);
            }
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopAnimation();
    }
}
