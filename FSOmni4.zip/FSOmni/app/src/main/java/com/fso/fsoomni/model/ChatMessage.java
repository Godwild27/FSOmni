package com.fso.fsoomni.model;

public class ChatMessage {

    public enum MessageType {
        INCOMING, OUTGOING
    }

    private MessageType type;
    private String sender;
    private String text;
    private String time;
    private String senderId;

    public ChatMessage(MessageType type, String sender, String text, String time) {
        this.type = type;
        this.sender = sender;
        this.text = text;
        this.time = time;
    }

    public ChatMessage(MessageType type, String text, String time) {
        this.type = type;
        this.text = text;
        this.time = time;
    }

    public MessageType getType() {
        return type;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getText() {
        return text;
    }

    public String getTime() {
        return time;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }
    
    // ================================================================
    // Sérialisation JSON pour persistance
    // ================================================================
    
    /**
     * Convertir le message en JsonObject pour la sauvegarde
     */
    public com.google.gson.JsonObject toJson() {
        com.google.gson.JsonObject json = new com.google.gson.JsonObject();
        json.addProperty("type", type.name());
        json.addProperty("sender", sender);
        json.addProperty("text", text);
        json.addProperty("time", time);
        json.addProperty("senderId", senderId);
        return json;
    }
    
    /**
     * Créer un ChatMessage depuis un JsonObject
     */
    public static ChatMessage fromJson(com.google.gson.JsonObject json) {
        MessageType type = MessageType.valueOf(json.get("type").getAsString());
        String sender = json.has("sender") && !json.get("sender").isJsonNull() ? 
                        json.get("sender").getAsString() : null;
        String text = json.get("text").getAsString();
        String time = json.get("time").getAsString();
        String senderId = json.has("senderId") && !json.get("senderId").isJsonNull() ? 
                          json.get("senderId").getAsString() : null;
        
        ChatMessage message = new ChatMessage(type, sender, text, time);
        message.setSenderId(senderId);
        return message;
    }
}
