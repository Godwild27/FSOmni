package com.fso.fsoomni.view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class WaveformView extends View {

    private static final int BAR_COUNT = 20;
    private float[] barHeights = new float[BAR_COUNT];
    private Paint barPaint;
    private boolean animating = false;
    private float density;

    public WaveformView(Context context) {
        super(context);
        init();
    }

    public WaveformView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public WaveformView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs);
        init();
    }

    private void init() {
        density = getResources().getDisplayMetrics().density;
        barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        barPaint.setColor(Color.parseColor("#BA1A1A"));
        barPaint.setAlpha(102); // 0.4 opacity

        for (int i = 0; i < BAR_COUNT; i++) {
            barHeights[i] = 4f * density;
        }
    }

    public void startAnimation() {
        animating = true;
        startBarAnimation();
    }

    public void stopAnimation() {
        animating = false;
        for (int i = 0; i < BAR_COUNT; i++) {
            barHeights[i] = 4f * density;
        }
        invalidate();
    }

    private void startBarAnimation() {
        if (!animating) return;

        for (int i = 0; i < BAR_COUNT; i++) {
            final int idx = i;
            ValueAnimator anim = ValueAnimator.ofFloat(4f * density, 20f * density, 8f * density);
            anim.setDuration(600);
            anim.setStartDelay(i * 50L);
            anim.setRepeatMode(ValueAnimator.REVERSE);
            anim.setRepeatCount(ValueAnimator.INFINITE);
            anim.addUpdateListener(animation -> {
                barHeights[idx] = (float) animation.getAnimatedValue();
                if (idx == BAR_COUNT - 1) {
                    invalidate();
                }
            });
            anim.start();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float w = getWidth();
        float h = getHeight();
        float barWidth = 3f * density;
        float gap = 2f * density;
        float totalWidth = BAR_COUNT * barWidth + (BAR_COUNT - 1) * gap;
        float startX = (w - totalWidth) / 2f;

        for (int i = 0; i < BAR_COUNT; i++) {
            float x = startX + i * (barWidth + gap);
            float barH = barHeights[i];
            float y = (h - barH) / 2f;
            canvas.drawRect(x, y, x + barWidth, y + barH, barPaint);
        }
    }
}
