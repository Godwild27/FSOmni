# Add project specific ProGuard rules here.
-keepattributes *Annotation*
-keep class com.fso.fsoomni.model.** { *; }
-keep class org.java_websocket.** { *; }
