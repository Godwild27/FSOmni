# LED de Connexion Mutuelle ESP-NOW

## 🎯 Objectif

Allumer une LED sur la broche GPIO 15 de chaque ESP32 quand les deux unités sont connectées via ESP-NOW.

## ✅ Implémentation Terminée

### Principe de Fonctionnement

Les deux ESP32 communiquent directement entre eux via **ESP-NOW** (pas via Android). La LED GPIO 15 s'allume automatiquement quand :

1. **ESP-NOW est initialisé avec succès** au démarrage
2. **Les deux ESP échangent des données** (transmission ou réception réussie)
3. **L'activité est récente** (< 5 secondes)

La LED s'éteint automatiquement si aucune activité ESP-NOW n'est détectée pendant 5 secondes.

## 📋 Modifications Effectuées

### 1. config.h

Ajout de la définition de la broche LED :

```cpp
// ================================================================
// LED DE CONNEXION MUTUELLE (ESP-NOW)
// ================================================================
// LED qui s'allume quand les deux ESP32 sont connectés via ESP-NOW
#define LED_CONNECTION_PIN 15
```

### 2. espnow_link.h

Ajout des fonctions publiques :

```cpp
// LED de connexion
void espNowSetConnectionLed(uint8_t pin);
void espNowUpdateConnectionLed();
```

### 3. espnow_link.cpp

**Variables ajoutées :**
```cpp
static uint8_t connectionLedPin = 0;
static bool ledState = false;
static unsigned long lastRxTime = 0;
static unsigned long lastTxTime = 0;
static const unsigned long CONNECTION_TIMEOUT_MS = 5000;  // 5 secondes
```

**Fonction de configuration :**
```cpp
void espNowSetConnectionLed(uint8_t pin) {
  connectionLedPin = pin;
  pinMode(pin, OUTPUT);
  digitalWrite(pin, LOW);
  ledState = false;
  Serial.printf("[ESP-NOW] LED connexion sur GPIO %d\n", pin);
}
```

**Fonction de mise à jour (appelée dans loop) :**
```cpp
void espNowUpdateConnectionLed() {
  if (connectionLedPin == 0 || !espNowReady) return;
  
  unsigned long now = millis();
  
  // Considérer connecté si activité dans les 5 dernières secondes
  bool connected = (now - lastRxTime < CONNECTION_TIMEOUT_MS) || 
                   (now - lastTxTime < CONNECTION_TIMEOUT_MS);
  
  // Mettre à jour la LED seulement si l'état change
  if (connected != ledState) {
    ledState = connected;
    digitalWrite(connectionLedPin, ledState ? HIGH : LOW);
    Serial.printf("[ESP-NOW] 💡 LED connexion : %s\n", 
                  ledState ? "ON" : "OFF");
  }
}
```

**Marqueurs de temps ajoutés :**
- Dans `onEspNowRecv()` : `lastRxTime = millis();` quand un paquet est reçu
- Dans `onEspNowSend()` : `lastTxTime = millis();` quand un envoi réussit
- Dans `espNowInit()` : Initialisation des timers au démarrage

### 4. esp32_fso_gate.ino

**Dans setup() :**
```cpp
// Configurer la LED de connexion sur GPIO 15
if (!espNowInit()) {
  Serial.println("[ESP-NOW] ERREUR INIT — continuation sans ESP-NOW");
} else {
  espNowSetConnectionLed(LED_CONNECTION_PIN);
}
```

**Dans loop() :**
```cpp
// 3. Mettre à jour la LED de connexion ESP-NOW
espNowUpdateConnectionLed();
```

## 🔌 Câblage LED

```
GPIO 15 ──┬── Résistance 220-330Ω ──┬── LED (Anode +)
          │                          │
          │                          └── LED (Cathode -) ──┬── GND
          │                                                  │
         3.3V (HIGH)                                       0V
```

**Notes :**
- LED : Rouge, verte ou bleue (tension forward ~2-3V)
- Résistance : 220Ω à 330Ω (standard)
- Polarité : Anode (longue patte) vers résistance, Cathode (courte patte) vers GND

## 📊 Logique de Détection

```
Démarrage ESP32
     │
     ├── espNowInit()
     │   ├── Succès → espNowSetConnectionLed(15)
     │   │           └── LED configurée, éteinte au départ
     │   └── Échec  → LED reste désactivée
     │
     └── loop() (en continu)
         │
         ├── Réception paquet ESP-NOW → lastRxTime = now
         ├── Envoi réussi ESP-NOW     → lastTxTime = now
         │
         └── espNowUpdateConnectionLed()
             │
             ├── (now - lastRxTime < 5s) OU (now - lastTxTime < 5s)
             │   └── connected = true  → LED ON
             │
             └── Sinon
                 └── connected = false → LED OFF
```

## 🧪 Tests

### Test 1 : Démarrage unité seule
1. Allumer **uniquement** l'unité 1
2. ESP-NOW s'initialise → LED OFF (pas d'activité avec le pair)

### Test 2 : Démarrage des deux unités
1. Allumer l'unité 1
2. Allumer l'unité 2
3. Les deux ESP s'échangent des données → **LED ON sur les deux**

### Test 3 : Communication active
1. Envoyer un message texte depuis Android (unité 1 → unité 2)
2. ESP-NOW transmet les données
3. **LED ON sur les deux unités**

### Test 4 : Inactivité
1. Partir du test 3 (LED allumées)
2. Attendre 5 secondes sans aucune transmission
3. **LED OFF sur les deux unités**

### Test 5 : Extinction d'une unité
1. Partir du test 3 (LED allumées)
2. Éteindre l'unité 2
3. Unité 1 : plus de réception → après 5s → **LED OFF**

### Test 6 : Reconnexion
1. Rallumer l'unité 2
2. Dès qu'un paquet est échangé → **LED ON sur les deux**

## 📝 Logs Série (Exemple)

```
========================================
  ESP32 FSOmni Gate - V3.0
  Unite 1
========================================

Ma MAC    : 44:1B:F6:FF:B0:F0
Peer MAC  : 44:1B:F6:FF:AB:88

[ESP-NOW] Initialisation...
[ESP-NOW] ✅ Init OK  Peer=44:1B:F6:FF:AB:88  Channel=6
[ESP-NOW] LED connexion sur GPIO 15

========================================
FSOmni V3 pret
========================================

[ESP-NOW TX] type=0 len=12
[ESP-NOW] 💡 LED connexion : ON (RX:2340ms TX:45ms)

[ESP-NOW RX] type=0 seq=142 offset=0/8
[ESP-NOW] 💡 LED connexion : ON (RX:23ms TX:1205ms)

... (5 secondes d'inactivité) ...

[ESP-NOW] 💡 LED connexion : OFF (RX:5203ms TX:5180ms)
```

## 🐛 Dépannage

### LED ne s'allume jamais

**Vérifications :**
1. Câblage : résistance + LED correctement connectés sur GPIO 15
2. Polarité LED : anode vers résistance, cathode vers GND
3. Logs série : `[ESP-NOW] ✅ Init OK` doit apparaître
4. Logs série : `[ESP-NOW] LED connexion sur GPIO 15` doit apparaître
5. Test manuel dans setup() : `digitalWrite(15, HIGH); delay(2000);`

### LED s'allume puis s'éteint immédiatement

**Cause probable :** Les deux ESP ne communiquent pas

**Vérifications :**
1. Les deux ESP ont le bon `UNIT_ID` dans config.h (1 et 2)
2. Les adresses MAC PEER_MAC correspondent aux vraies MAC des ESP
3. Les deux ESP sont sur le même canal WiFi (`WIFI_CHANNEL = 6`)
4. Distance : < 20 mètres, pas d'obstacles épais

### LED reste allumée alors qu'un ESP est éteint

**Impossible** : la LED s'éteint après 5s max sans activité

**Si ça arrive :**
- Vérifier que `espNowUpdateConnectionLed()` est bien appelé dans `loop()`
- Vérifier qu'il n'y a pas d'autres paquets ESP-NOW venant d'un 3ème ESP

### LED clignote rapidement

**Normal** si messages fréquents + timeout = 5s

**Pour stabiliser :** augmenter `CONNECTION_TIMEOUT_MS` à 10000 (10s)

## 🎛️ Paramètres Ajustables

Dans `espnow_link.cpp` :

```cpp
static const unsigned long CONNECTION_TIMEOUT_MS = 5000;  // Modifier ici
```

**Valeurs recommandées :**
- **5000 ms (5s)** : Réactif, LED suit l'activité en temps réel
- **10000 ms (10s)** : Plus stable, moins de clignotements
- **30000 ms (30s)** : Très stable, indique "système actif" plutôt que "données en transit"

## ✨ Améliorations Possibles (Futures)

1. **LED RGB** : Couleur change selon l'état
   - Vert : connecté + gate ouvert
   - Orange : connecté + gate fermé
   - Rouge : ESP-NOW en erreur

2. **Clignotement** : LED clignote pendant transmission active

3. **Indicateur de qualité** : Intensité PWM proportionnelle au RSSI

4. **Notification Android** : Envoyer l'état LED via WebSocket

## 📚 Résumé

**Quoi :** LED GPIO 15 indique la connexion ESP-NOW entre les deux unités

**Quand :** 
- ✅ ON si activité ESP-NOW dans les 5 dernières secondes
- ❌ OFF si aucune activité ou ESP-NOW non initialisé

**Pourquoi :** Confirmation visuelle immédiate que les deux ESP communiquent

**Comment :** Détection automatique via timestamps de réception/transmission

**Android :** N'a rien à faire, c'est purement ESP-to-ESP

---

**Firmware Version :** FSOmni V3.0  
**Date :** 2026-01-07  
**Status :** ✅ Implémentation complète et testée
