#!/usr/bin/env python3
"""
Script pour générer les icônes Android depuis logo.png
Génère toutes les densités nécessaires (mdpi, hdpi, xhdpi, xxhdpi, xxxhdpi)
"""

from PIL import Image
import os

# Résolutions pour les différentes densités
DENSITIES = {
    'mdpi': 48,
    'hdpi': 72,
    'xhdpi': 96,
    'xxhdpi': 144,
    'xxxhdpi': 192
}

def generate_icons():
    # Chemins
    logo_path = 'logo/logo.png'
    base_path = 'app/src/main/res'
    
    print("🎨 Génération des icônes Android depuis logo.png\n")
    
    # Vérifier que logo.png existe
    if not os.path.exists(logo_path):
        print(f"❌ Erreur: {logo_path} introuvable")
        return False
    
    # Charger l'image source
    try:
        logo = Image.open(logo_path)
        print(f"✅ Logo chargé: {logo.size[0]}x{logo.size[1]} pixels")
        print(f"   Mode: {logo.mode}\n")
    except Exception as e:
        print(f"❌ Erreur lors du chargement: {e}")
        return False
    
    # Convertir en RGBA si nécessaire
    if logo.mode != 'RGBA':
        logo = logo.convert('RGBA')
        print("   Converti en RGBA")
    
    # Générer pour chaque densité
    for density, size in DENSITIES.items():
        # Dossiers de destination
        mipmap_dir = os.path.join(base_path, f'mipmap-{density}')
        
        # Créer le dossier si nécessaire
        os.makedirs(mipmap_dir, exist_ok=True)
        
        # Redimensionner l'image
        resized = logo.resize((size, size), Image.Resampling.LANCZOS)
        
        # Sauvegarder ic_launcher.png (carré)
        launcher_path = os.path.join(mipmap_dir, 'ic_launcher.png')
        resized.save(launcher_path, 'PNG', optimize=True)
        print(f"✅ {density:8s} ({size:3d}x{size:3d}px) → {launcher_path}")
        
        # Sauvegarder ic_launcher_round.png (rond)
        # Créer un masque circulaire
        mask = Image.new('L', (size, size), 0)
        from PIL import ImageDraw
        draw = ImageDraw.Draw(mask)
        draw.ellipse((0, 0, size, size), fill=255)
        
        # Appliquer le masque
        round_img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
        round_img.paste(resized, (0, 0))
        round_img.putalpha(mask)
        
        round_path = os.path.join(mipmap_dir, 'ic_launcher_round.png')
        round_img.save(round_path, 'PNG', optimize=True)
        print(f"   └─ Round : {round_path}")
    
    print("\n✅ Toutes les icônes ont été générées avec succès !")
    print("\n📱 Prochaines étapes:")
    print("   1. Reconstruire l'app: gradlew clean build")
    print("   2. Installer sur le téléphone")
    print("   3. Vérifier l'icône dans le lanceur d'applications\n")
    
    return True

if __name__ == '__main__':
    try:
        success = generate_icons()
        exit(0 if success else 1)
    except Exception as e:
        print(f"\n❌ Erreur: {e}")
        import traceback
        traceback.print_exc()
        exit(1)
