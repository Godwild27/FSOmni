# Fix BER et Intensité Lumineuse - Page Alignement

## 🔧 Problème Identifié

Sur la page **Alignement**, les valeurs de **BER** et **Intensité Lumineuse** n'étaient pas synchronisées avec le reste de l'application :

1. **BER** : Devrait être identique au Dashboard
2. **Intensité Lumineuse** : Devrait afficher la luminosité réelle du capteur (LDR/BH1750)

## ✅ Solution Implémentée

### 1. BER - Synchronisation avec Dashboard

**Avant** :
- Utilisait `AppState.lastBer` ✓ (déjà correct)

**Après** :
- Toujours `AppState.lastBer` 
- Même valeur que le Dashboard
- Format : "10⁻⁹" (notation scientifique avec exposant)

**Listener** :
```java
case "ber":
    double ber = (Double) value;
    alignBerValue.setText(String.format("%.0e", ber).replace("e-0", "⁻"));
    break;
```

### 2. Intensité Lumineuse - Capteur Réel

**Avant** :
- Utilisait `AppState.lightIntensity` (valeur fictive en dBm)
- Format : "-18.4 dBm"
- Calcul de la barre : `(intensity + 50) / 50 × 100`

**Après** :
- Utilise `AppState.lastLuminosity` (valeur réelle du capteur)
- Format : "5000 lux" (sans décimales)
- Calcul de la barre : `lux / 30000 × 100`
  - 0 lux → 0%
  - 30000+ lux → 100%

**Listener modifié** :
```java
case "luminosity":  // Changé de "lightIntensity" → "luminosity"
    double lux = (Double) value;
    lightIntensityValue.setText(String.format("%.0f lux", lux));
    int progress = (int) Math.max(0, Math.min(100, (lux / 30000.0) * 100));
    // Mise à jour de la barre de progression...
    break;
```

## 📊 Source des Données

### BER
```
Arduino → ESP32 → WebSocket → AppState.lastLuminosity
                                      ↓
                            recalculateBER() (basé sur luminosité)
                                      ↓
                            AppState.lastBer
                                      ↓
                    ┌──────────────────┴──────────────────┐
                    ↓                                     ↓
            DashboardFragment                    AlignmentFragment
            berValue.setText()                   alignBerValue.setText()
```

### Intensité Lumineuse (Luminosité)
```
Arduino (LDR/BH1750) → ESP32 → WebSocket → AppState.lastLuminosity
                                                      ↓
                                  ┌───────────────────┴───────────────────┐
                                  ↓                                       ↓
                         DashboardFragment                       AlignmentFragment
                     weatherLuminosity.setText()            lightIntensityValue.setText()
                          "5000 lux"                              "5000 lux"
```

## 🎯 Résultat

### Dashboard
```
┌─────────────────────────────────────┐
│ Météo & Environnement               │
│                                     │
│ Luminosité     5000 lux             │
│ BER            10⁻⁹                 │
└─────────────────────────────────────┘
```

### Alignement
```
┌─────────────────────────────────────┐
│ BER              INTENSITÉ LUMINEUSE│
│ 10⁻⁹             5000 lux           │
│ ████░░░░         ██████░░░░         │
└─────────────────────────────────────┘
```

**Les valeurs sont identiques !** ✓

## 🧪 Test de Vérification

### Scénario 1 : Luminosité Change
1. Couvrir le capteur LDR/BH1750 (luminosité descend)
2. Observer **Dashboard** : "100 lux"
3. Aller sur **Alignement** : "100 lux" ✓ (même valeur)

### Scénario 2 : BER Change
1. Faible luminosité → BER élevé (ex: 1e-5)
2. Observer **Dashboard** : BER = "10⁻⁵"
3. Aller sur **Alignement** : BER = "10⁻⁵" ✓ (même valeur)

### Scénario 3 : Forte Luminosité
1. Forte lumière sur le capteur (ex: 25000 lux)
2. Observer **Dashboard** : "25000 lux"
3. Aller sur **Alignement** : "25000 lux" ✓ (même valeur)
4. Barre de progression Alignement : ~83% (25000/30000)

## 📝 Notes Techniques

### BER (Bit Error Rate)
- Calculé côté Android à partir de la luminosité
- Voir `AppState.recalculateBER()` pour la formule
- Plage : 1e-9 (excellent) à 1e-5 (mauvais)

### Luminosité
- Provient directement du capteur Arduino
- **Unit 1** : BH1750 (I2C) → plage 0-65535 lux
- **Unit 2** : LDR (Analog A0) → plage 0-65000 lux (mappé)
- Pas de transformation, valeur brute affichée

### Barre de Progression
- **Dashboard** : Pas de barre pour la luminosité (juste la valeur)
- **Alignement** : Barre de 0% (0 lux) à 100% (30000+ lux)
- Formule : `min(100, (lux / 30000) × 100)`

### Ancien vs Nouveau

| Métrique | Ancien (Alignement) | Nouveau (Alignement) |
|----------|---------------------|----------------------|
| BER | `AppState.lastBer` ✓ | `AppState.lastBer` ✓ |
| Intensité | `AppState.lightIntensity` (fictif, dBm) | `AppState.lastLuminosity` (réel, lux) |
| Listener | `"lightIntensity"` | `"luminosity"` |
| Format | "-18.4 dBm" | "5000 lux" |

## 🔄 Synchronisation Garantie

Les deux pages utilisent maintenant **exactement les mêmes sources de données** :

- `AppState.lastBer` → BER
- `AppState.lastLuminosity` → Intensité lumineuse

Toute modification de ces valeurs est **immédiatement propagée** aux deux fragments via le listener `OnStateChangeListener`.
