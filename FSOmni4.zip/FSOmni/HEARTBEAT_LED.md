# LED Permanente avec Heartbeat ESP-NOW

## 🔄 Modification : LED Toujours Allumée

### Problème Initial
La LED s'éteignait après 5 secondes d'inactivité, même si les deux ESP étaient allumés et fonctionnels.

### Solution : Heartbeat Automatique
Les deux ESP s'envoient mutuellement un petit paquet "heartbeat" toutes les **2 secondes** pour maintenir la connexion active et garder la LED allumée.

---

## ⚙️ Fonctionnement

```
T=0s    ESP1 et ESP2 démarrent
        ├─ ESP-NOW init OK
        └─ LED OFF (pas encore d'échange)

T=2s    ESP1 → Heartbeat → ESP2
        ├─ lastTxTime (ESP1) = 2s
        ├─ lastRxTime (ESP2) = 2s
        └─ 💡 LED ON (les deux)

T=4s    ESP2 → Heartbeat → ESP1
        ├─ lastTxTime (ESP2) = 4s
        ├─ lastRxTime (ESP1) = 4s
        └─ 💡 LED ON (les deux)

T=6s    ESP1 → Heartbeat → ESP2
        └─ 💡 LED ON (les deux)

...     (Heartbeat continue toutes les 2s)
        └─ 💡 LED RESTE ON en permanence
```

---

## 📋 Modifications Apportées

### 1. espnow_link.h

**Ajout du type de message :**
```cpp
enum EspNowMsgType : uint8_t {
  // ... types existants ...
  ESPNOW_MSG_HEARTBEAT = 7   // ← NOUVEAU
};
```

**Ajout de la fonction :**
```cpp
void espNowSendHeartbeat();
```

### 2. espnow_link.cpp

**Variables ajoutées :**
```cpp
static const unsigned long HEARTBEAT_INTERVAL_MS = 2000;  // Heartbeat toutes les 2s
static unsigned long lastHeartbeatTime = 0;
```

**Fonction heartbeat :**
```cpp
void espNowSendHeartbeat() {
  if (!espNowReady) return;
  
  // Envoyer un paquet vide de type HEARTBEAT
  EspNowPacket pkt;
  memset(&pkt, 0, sizeof(pkt));
  pkt.type = ESPNOW_MSG_HEARTBEAT;
  pkt.seq = nextSeq++;
  pkt.total_len = 0;
  
  espNowSendPacket(&pkt);
}
```

**Mise à jour de espNowUpdateConnectionLed() :**
```cpp
void espNowUpdateConnectionLed() {
  // ...
  
  // Envoyer heartbeat automatiquement toutes les 2 secondes
  if (now - lastHeartbeatTime >= HEARTBEAT_INTERVAL_MS) {
    espNowSendHeartbeat();
    lastHeartbeatTime = now;
  }
  
  // ... reste du code ...
}
```

### 3. esp32_fso_gate.ino

**Gestion du heartbeat en réception :**
```cpp
void onEspNowRx(const EspNowPacket* pkt) {
  // Heartbeat : pas de log pour ne pas polluer
  if (pkt->type == ESPNOW_MSG_HEARTBEAT) {
    return;  // Juste maintenir la connexion
  }
  
  // ... traitement des autres messages ...
}
```

---

## 🎯 Comportement Final

| Situation | LED | Heartbeat |
|-----------|-----|-----------|
| Démarrage ESP1 seul | OFF | Envoi toutes les 2s (mais pas de peer) |
| Démarrage ESP2 | **ON** | Les deux s'envoient des heartbeats |
| Les deux allumés | **ON permanent** | Échange continu toutes les 2s |
| Message utilisateur | **ON** | Heartbeat continue |
| Extinction ESP2 | OFF après 5s | ESP1 ne reçoit plus rien |
| Reconnexion ESP2 | **ON** immédiatement | Heartbeat reprend |

---

## 📊 Timing Détaillé

```
Unité 1                          Unité 2
   │                                │
   ├─ t=2.0s: Send Heartbeat ──────►│ Rx → LED ON
   │                                │
   │◄──────── Send Heartbeat ───────┤ t=2.1s
   │ Rx → LED ON                    │
   │                                │
   ├─ t=4.0s: Send Heartbeat ──────►│ Rx → LED reste ON
   │                                │
   │◄──────── Send Heartbeat ───────┤ t=4.1s
   │ Rx → LED reste ON              │
   │                                │
   │         ... (continue)         │
   │                                │
   │                                ✖ ÉTEINT
   │                                │
   ├─ t=6.0s: Send Heartbeat ──────►✖ Pas de réponse
   │                                │
   ├─ t=8.0s: Send Heartbeat ──────►✖ Pas de réponse
   │                                │
   ├─ t=10.0s: Timeout détecté      │
   │    (10s - 4s = 6s > 5s)        │
   │    LED OFF                      │
```

---

## ⚡ Performance

### Consommation Réseau
- **Taille paquet heartbeat :** 18 octets (header ESP-NOW minimal)
- **Fréquence :** Toutes les 2 secondes
- **Débit :** 18 bytes × 0.5 Hz = **9 bytes/seconde = 72 bits/seconde**
- **Impact :** Négligeable (ESP-NOW supporte 1 Mbps)

### Consommation CPU
- **Coût :** ~1 ms toutes les 2 secondes
- **Impact :** < 0.05% du CPU

### Consommation Énergie
- **TX ESP-NOW :** ~120 mA pendant 2-3 ms
- **Fréquence :** 0.5 Hz
- **Impact moyen :** < 0.2 mA supplémentaire

**Conclusion :** L'impact du heartbeat est **totalement négligeable**.

---

## 🔧 Paramètres Ajustables

### Fréquence du Heartbeat

Dans `espnow_link.cpp` :

```cpp
static const unsigned long HEARTBEAT_INTERVAL_MS = 2000;  // ← Modifier ici
```

**Valeurs recommandées :**
- **1000 ms (1s)** : LED très réactive, mais plus de paquets
- **2000 ms (2s)** : Bon compromis (recommandé)
- **5000 ms (5s)** : Économie réseau, mais LED s'éteint brièvement
- **10000 ms (10s)** : Trop long, LED instable

### Timeout de Déconnexion

```cpp
static const unsigned long CONNECTION_TIMEOUT_MS = 5000;  // ← Modifier ici
```

**Règle :** `CONNECTION_TIMEOUT_MS` doit être **> 2 × HEARTBEAT_INTERVAL_MS**

Exemples :
- Heartbeat 2s → Timeout ≥ 5s ✅
- Heartbeat 1s → Timeout ≥ 3s ✅
- Heartbeat 5s → Timeout ≥ 12s ✅

---

## 🧪 Tests

### Test 1 : LED Permanente
1. Allumer ESP1 et ESP2
2. Attendre 10 secondes
3. **Résultat attendu :** LED reste ON sur les deux

### Test 2 : Extinction Unité
1. Partir du test 1 (LED ON)
2. Éteindre ESP2
3. Attendre 6 secondes
4. **Résultat attendu :** LED ESP1 s'éteint

### Test 3 : Reconnexion
1. Rallumer ESP2
2. **Résultat attendu :** LED se rallume immédiatement sur les deux

### Test 4 : Logs Série
```
[ESP-NOW] ✅ Init OK  Peer=44:1B:F6:FF:AB:88  Channel=6
[ESP-NOW] LED connexion sur GPIO 15
[ESP-NOW] 💡 LED connexion : ON (RX:2040ms TX:45ms)

... (pas de logs heartbeat pour ne pas polluer) ...

(Si déconnexion)
[ESP-NOW] 💡 LED connexion : OFF (RX:5230ms TX:5010ms)
```

---

## 📝 Notes Importantes

### ✅ Avantages du Heartbeat
- LED reste allumée en permanence
- Détection rapide de déconnexion (5s max)
- Coût réseau/énergie négligeable
- Implémentation simple et robuste

### ⚠️ Limitations
- Si les deux ESP sont hors de portée, le heartbeat échoue → LED OFF
- Le heartbeat ne remplace pas le gate laser (vérification ligne de vue)
- Logs heartbeat désactivés pour ne pas polluer la console

### 🔒 Sécurité
- Le heartbeat vérifie toujours l'adresse MAC du peer
- Pas de risque de réception de heartbeat d'un tiers
- Même sécurité que les messages normaux

---

## 🎓 Différence avec V1

| Version | Comportement LED | Heartbeat | Déconnexion |
|---------|------------------|-----------|-------------|
| **V1** | S'éteint après 5s d'inactivité | ❌ Non | Immédiate |
| **V2** (actuelle) | **Reste ON en permanence** | ✅ Oui (2s) | Détectée en 5s |

---

## 🚀 Prochaines Étapes

1. ✅ Code modifié
2. ⏳ Reflasher les deux ESP32
3. ⏳ Tester LED permanente
4. ⏳ Vérifier logs série

---

**Version :** FSOmni V3.1 (Heartbeat)  
**Date :** 2026-01-07  
**Status :** ✅ Prêt à flasher
