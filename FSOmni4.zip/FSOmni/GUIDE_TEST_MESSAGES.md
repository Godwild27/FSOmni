# 🧪 Guide de Test - Messages Texte FSO

## 📋 PRÉ-REQUIS

### Matériel
- [ ] 2x ESP32-S3 N16R8 flashés (un avec UNIT_ID=1, un avec UNIT_ID=2)
- [ ] 2x Arduino Uno avec capteurs (optionnel pour les messages)
- [ ] 2x Smartphones Android avec l'app FSOmni installée
- [ ] Lasers et photodiodes correctement câblés

### Logiciel
- [ ] Firmware ESP32 V3.0 flashé sur les deux unités
- [ ] App Android installée sur les deux téléphones
- [ ] Les deux ESP32 accessibles (Serial Monitor pour debug)

---

## 🚀 PROCÉDURE DE TEST COMPLÈTE

### ÉTAPE 1 : Vérification Matérielle

#### 1.1 Alimentation des ESP32
```bash
# Brancher les 2 ESP32 via USB
# Ouvrir 2 Serial Monitors (115200 bauds)

# UNITÉ 1 doit afficher:
========================================
  ESP32 FSOmni Gate - V3.0
  Unite 1
  FSOmni V3.0 (ESP-NOW + Laser Gate)
========================================

Ma MAC    : 44:1B:F6:FF:B0:F0
Peer MAC  : 44:1B:F6:FF:AB:88
WiFi AP   : FSOmni_1 (canal 6)
...
[ESP-NOW] ✅ Init OK  Peer=44:1B:F6:FF:AB:88  Channel=6

# UNITÉ 2 doit afficher:
========================================
  ESP32 FSOmni Gate - V3.0
  Unite 2
  FSOmni V3.0 (ESP-NOW + Laser Gate)
========================================

Ma MAC    : 44:1B:F6:FF:AB:88
Peer MAC  : 44:1B:F6:FF:B0:F0
WiFi AP   : FSOmni_2 (canal 6)
...
[ESP-NOW] ✅ Init OK  Peer=44:1B:F6:FF:B0:F0  Channel=6
```

**✅ Vérifier**: Les deux ESP32 démarrent sans erreur ESP-NOW

#### 1.2 LED de Connexion (GPIO 15)

**Observation**: La LED sur GPIO 15 doit **s'allumer** sur les deux unités après ~2 secondes

**Explication**: Les heartbeats ESP-NOW maintiennent la LED allumée

**❌ Si LED éteinte**:
- Vérifier que les deux ESP32 sont sur le même canal (6)
- Vérifier les adresses MAC dans config.h
- Regarder les logs Serial Monitor pour erreurs ESP-NOW

---

### ÉTAPE 2 : Connexion Android (Unité 1)

#### 2.1 Premier téléphone (Unité 1)

1. **Ouvrir l'app FSOmni** sur le téléphone 1
2. **Page Config** s'affiche
3. **Scanner le WiFi** → Voir "FSOmni_1" disponible
4. **Se connecter** au WiFi "FSOmni_1" (mot de passe: `fsomni2026`)
5. **Revenir dans l'app**
6. **Entrer IP**: `192.168.4.1` (déjà pré-rempli)
7. **Cliquer "Se Connecter"**

**✅ Résultat attendu**:
```
Connexion établie ✅
WebSocket connecté
```

**Logs ESP32 Unité 1**:
```
[WS] Client connecte [ID:1] 192.168.4.2
```

#### 2.2 Naviguer vers la page Transfer

1. Cliquer sur l'icône **Transfert** (3ème icône en bas)
2. **Vérifier l'affichage**:
   - "Liaison Laser : Établie" avec **point vert** 🟢
   - Badge "AES-128 Actif"
   - Champ de saisie actif
   - Aucun message dans l'historique

---

### ÉTAPE 3 : Connexion Android (Unité 2)

#### 3.1 Deuxième téléphone (Unité 2)

1. **Ouvrir l'app FSOmni** sur le téléphone 2
2. **Scanner le WiFi** → Voir "FSOmni_2" disponible
3. **Se connecter** au WiFi "FSOmni_2" (mot de passe: `fsomni2026`)
4. **Revenir dans l'app**
5. **Entrer IP**: `192.168.4.1`
6. **Cliquer "Se Connecter"**
7. **Naviguer vers Transfer**

**✅ Résultat attendu**:
- Connexion établie
- "Liaison Laser : Établie" 🟢
- Prêt à recevoir/envoyer

---

### ÉTAPE 4 : Test Basique d'Envoi

#### 4.1 Envoyer de Unité 1 → Unité 2

**Sur téléphone 1 (connecté à FSOmni_1)**:

1. Dans la page **Transfer**
2. Taper dans le champ texte: `Bonjour depuis Unité 1`
3. Appuyer sur le bouton **Envoyer** 📤

**✅ Observation téléphone 1**:
- Message apparaît immédiatement dans le chat
- Bulle bleue à droite
- Texte: `[Unité 1] 16:23`
- Contenu: `Bonjour depuis Unité 1`

**✅ Logs Serial Monitor Unité 1**:
```
[WS] msg [ID:1]: {"type":2,"text":"Bonjour depuis Unité 1","unit_id":1,"length":23}
[WS] -> ESP-NOW TX de Unité 1: "Bonjour depuis Unité 1"
[ESP-NOW] 📤 Message texte laser envoyé
💡💡💡 LASERS CLIGNOTENT (visibles à l'œil)
[ESP-NOW] ✅ 23 octets envoyés
```

**✅ Logs Serial Monitor Unité 2**:
```
[ESP-NOW RX] type=0 seq=... offset=0/23
[ESP-NOW RX] Texte de Unité 1: "Bonjour depuis Unité 1"
[Gate] OUVERT (ligne de vue OK)
[WS] RX broadcasted
```

**✅ Observation téléphone 2**:
- Message apparaît dans le chat (notification sonore si implémentée)
- Bulle grise à gauche
- Texte: `[Unité 1] 16:23`
- Contenu: `Bonjour depuis Unité 1`

#### 4.2 Répondre de Unité 2 → Unité 1

**Sur téléphone 2 (connecté à FSOmni_2)**:

1. Taper: `Salut Unité 1, bien reçu!`
2. Appuyer sur **Envoyer** 📤

**✅ Observation**:
- Message apparaît sur téléphone 2 (bulle bleue droite)
- Message apparaît sur téléphone 1 (bulle grise gauche)
- Sender affiché: `[Unité 2]`

---

### ÉTAPE 5 : Test de Persistance

#### 5.1 Envoyer plusieurs messages

**De chaque unité**, envoyer 3-4 messages pour créer un historique

Exemple:
```
[Unité 1] Bonjour
[Unité 2] Salut
[Unité 1] Comment ça va?
[Unité 2] Très bien merci!
```

#### 5.2 Fermer et rouvrir l'app

**Sur téléphone 1**:
1. **Fermer l'app** complètement (swipe depuis les apps récentes)
2. **Rouvrir l'app**
3. **Se reconnecter** au WiFi "FSOmni_1"
4. **Se reconnecter** via WebSocket
5. **Aller sur Transfer**

**✅ Résultat attendu**:
- **TOUS les messages précédents sont toujours là**
- L'ordre est préservé
- Les timestamps sont corrects
- Les noms d'unités sont corrects

#### 5.3 Effacer l'historique

1. Cliquer sur **"Effacer l'historique des messages"**
2. Confirmer dans la popup
3. **✅ Résultat**: Tous les messages disparaissent
4. Toast affiché: "Historique des messages effacé"

---

### ÉTAPE 6 : Test de Gate Laser

#### 6.1 Bloquer la ligne de vue

**Configuration**:
- Placer les deux unités face à face (lasers vers photodiodes)
- Laisser la ligne de vue dégagée
- Les deux ESP32 connectés en ESP-NOW

**Test**:
1. **Bloquer** physiquement la ligne de vue avec la main ou un objet opaque
2. **Attendre 2 secondes** (le gate passe à FERMÉ)
3. **Sur téléphone 1**, envoyer: `Message bloqué`

**✅ Observation Logs ESP32 Unité 2**:
```
[Gate] FERME (ligne de vue perdue)
[ESP-NOW RX] type=0 seq=... offset=0/15
[ESP-NOW RX] ⚠️ Gate FERME → paquet ignore
```

**✅ Observation téléphone 2**:
- **RIEN** ne s'affiche (message ignoré)

#### 6.2 Débloquer la ligne de vue

1. **Retirer** l'obstacle
2. **Attendre 1 seconde** (le gate passe à OUVERT)
3. **Sur téléphone 1**, renvoyer: `Message passé`

**✅ Observation Logs ESP32 Unité 2**:
```
[Gate] OUVERT (ligne de vue OK)
[ESP-NOW RX] type=0 seq=... offset=0/14
[ESP-NOW RX] Texte de Unité 1: "Message passé"
[WS] RX broadcasted
```

**✅ Observation téléphone 2**:
- Message **s'affiche correctement** dans le chat

---

### ÉTAPE 7 : Test de Service d'Arrière-Plan

#### 7.1 Mettre l'app en arrière-plan

**Sur téléphone 1**:
1. App connectée sur page Transfer
2. Appuyer sur le bouton **Home** (ne pas fermer l'app)
3. **Observation**: Notification persistante affichée
   ```
   FSOmni connecté
   Liaison laser active - Transfert en cours
   [Déconnecter]
   ```

#### 7.2 Recevoir un message en arrière-plan

**Sur téléphone 2**:
1. Envoyer: `Test arrière-plan`

**✅ Observation téléphone 1**:
- **Notification Android** (si implémentée dans version future)
- Message arrive quand on rouvre l'app
- WebSocket n'a **PAS été déconnecté**

#### 7.3 Déconnecter depuis la notification

**Sur téléphone 1**:
1. Dans la notification, cliquer **"Déconnecter"**

**✅ Résultat attendu**:
- Notification disparaît
- Service arrêté
- WebSocket déconnecté
- Si on rouvre l'app → page Config affichée (déconnecté)

---

### ÉTAPE 8 : Test de Robustesse

#### 8.1 Messages longs

**Test**: Envoyer un message de 1000 caractères

**✅ Résultat attendu**:
- Message envoyé sans erreur
- Message reçu complet
- Temps de transmission : < 1 seconde

#### 8.2 Messages rapides

**Test**: Envoyer 5 messages très rapidement (spam)

**✅ Résultat attendu**:
- Tous les messages envoyés
- Tous les messages reçus
- Ordre préservé
- Pas de perte

#### 8.3 Déconnexion/Reconnexion

**Test**:
1. Déconnecter le téléphone 1
2. Téléphone 2 envoie un message → **ne sera pas reçu**
3. Reconnecter le téléphone 1
4. Téléphone 2 envoie un nouveau message → **doit être reçu**

**✅ Résultat attendu**:
- Messages envoyés pendant la déconnexion sont **perdus** (normal)
- Messages envoyés après reconnexion sont **reçus**

---

## 📊 RÉSULTATS ATTENDUS

### ✅ Tests Réussis

- [x] Les deux ESP32 démarrent sans erreur
- [x] LED de connexion GPIO 15 allumée sur les deux unités
- [x] Connexion WiFi + WebSocket fonctionnelle
- [x] Messages envoyés depuis Unité 1 → reçus par Unité 2
- [x] Messages envoyés depuis Unité 2 → reçus par Unité 1
- [x] Noms d'unités corrects ("Unité 1", "Unité 2")
- [x] Lasers clignotent pendant l'envoi (visible à l'œil)
- [x] Gate laser bloque les messages quand ligne de vue obstruée
- [x] Persistance des messages (fermer/rouvrir app)
- [x] Effacement d'historique fonctionne
- [x] Service d'arrière-plan maintient la connexion
- [x] Notification persistante affichée
- [x] Déconnexion depuis notification fonctionne

---

## ❌ DÉPANNAGE

### Problème : LED GPIO 15 éteinte

**Causes possibles**:
- ESP-NOW pas initialisé correctement
- Canal WiFi différent entre les deux unités
- Adresses MAC incorrectes

**Solution**:
1. Vérifier les logs Serial Monitor pour erreurs ESP-NOW
2. Vérifier `config.h` : `WIFI_CHANNEL` identique (6)
3. Vérifier `config.h` : `UNIT_ID` différent (1 et 2)
4. Re-flasher les ESP32 si nécessaire

---

### Problème : Messages pas reçus

**Symptômes**: 
- Message envoyé depuis Unité 1
- Rien ne s'affiche sur Unité 2

**Vérifications**:
1. **Serial Monitor Unité 1**: Voir "ESP-NOW TX" ?
   - ❌ Non → Problème d'envoi Android → ESP32
   - ✅ Oui → Continuer

2. **Serial Monitor Unité 2**: Voir "ESP-NOW RX" ?
   - ❌ Non → Problème ESP-NOW (canal, MAC, distance)
   - ✅ Oui → Continuer

3. **Serial Monitor Unité 2**: Voir "Gate FERME" ?
   - ✅ Oui → **Ligne de vue bloquée** (débloquer lasers)
   - ❌ Non → Problème WebSocket ESP32 → Android

4. **Téléphone 2**: WebSocket connecté ?
   - ❌ Non → Reconnecter
   - ✅ Oui → Vérifier logs dans Android Studio

---

### Problème : Lasers ne clignotent pas

**Vérification**:
- Regarder les lasers pendant l'envoi (pièce sombre aide)
- Durée de clignotement : ~0.1 seconde (court message)
- Fréquence : 10 Hz (visible à l'œil comme un "flash")

**Si toujours pas visible**:
- Vérifier câblage GPIO 4, 5, 6
- Vérifier alimentation des lasers (transistors)
- Tester avec un multimètre sur les GPIO pendant envoi

---

### Problème : Messages perdus après fermeture app

**Symptômes**:
- Messages présents avant fermeture
- Disparaissent après fermeture/réouverture

**Vérification**:
1. Regarder les logs Android Studio
2. Vérifier SharedPreferences
3. S'assurer que `chatAdapter.setSaveCallback()` est appelé

**Solution temporaire**:
- Exporter les messages avant de fermer (feature future)

---

## 📝 NOTES IMPORTANTES

### ⏱️ Temps de Transmission

- **Message court (< 10 chars)** : < 100ms
- **Message moyen (100 chars)** : < 200ms  
- **Message long (1000 chars)** : < 500ms
- **Limite maximale** : 4000 caractères

### 🔋 Consommation LED

La LED GPIO 15 consomme ~20mA quand allumée. Si économie d'énergie nécessaire:
- Réduire `HEARTBEAT_INTERVAL_MS` dans `espnow_link.cpp`
- Ou désactiver la LED (commenter `espNowSetConnectionLed()`)

### 📡 Portée ESP-NOW

- **Intérieur** : 50-100 mètres
- **Extérieur (ligne de vue)** : 200-300 mètres
- **Obstacles** : Réduit fortement la portée

### 💡 Lasers

- **Puissance** : KY-008 (5mW, classe 2)
- **Sécurité** : Ne pas pointer vers les yeux
- **Portée** : 100-500 mètres selon conditions

---

## ✅ VALIDATION FINALE

**Le système est fonctionnel si TOUS ces tests passent**:

- [x] Messages bidirectionnels OK
- [x] Noms d'unités corrects
- [x] Lasers clignotent
- [x] Gate laser bloque si obstrué
- [x] Persistance fonctionne
- [x] Service arrière-plan OK
- [x] Pas de crash ni erreur

**🎉 FÉLICITATIONS ! Le système de messagerie FSO est opérationnel !**

---

*Guide de test généré le 2026-07-08*  
*FSOmni V3.0 - ESP-NOW + Laser Gate*
