# Résumé des Implémentations - Android FSOmni

## ✅ Fonctionnalités Implémentées

### 1. **BER (Bit Error Rate) - Variation avec la Luminosité**
- **Localisation** : `AppState.java` → `recalculateBER()`
- **Logique** :
  - Luminosité < 100 lux → BER entre 1e-5 et 1e-6 (très mauvais)
  - Luminosité 100-1000 lux → BER entre 1e-6 et 1e-7 (mauvais)
  - Luminosité 1000-10000 lux → BER entre 1e-7 et 1e-8 (moyen)
  - Luminosité > 10000 lux → BER entre 1e-8 et 1e-9 (excellent)
- **Déclenchement** : Appelé automatiquement dans `FSOWebSocketClient.java` quand les données de luminosité arrivent

### 2. **Atténuation - Variation avec la Luminosité**
- **Localisation** : `AppState.java` → `recalculateAttenuation()`
- **Logique** :
  - Luminosité < 100 lux → Atténuation 3-5 dB/km (brouillard épais)
  - Luminosité 100-1000 lux → Atténuation 1-3 dB/km (brouillard léger)
  - Luminosité 1000-10000 lux → Atténuation 0.3-1 dB/km (air moyen)
  - Luminosité > 10000 lux → Atténuation 0.1-0.3 dB/km (air clair)
- **Déclenchement** : Appelé automatiquement dans `FSOWebSocketClient.java` quand les données de luminosité arrivent

### 3. **RSSI - Variation avec les Paramètres TinyML**
- **Localisation** : `AppState.java` → `recalculateRSSI()`
- **Logique** :
  - **TinyML désactivé** : RSSI fixe à -50 dBm
  - **TinyML activé** : RSSI calculé selon formule
    - Sensibilité Signal (0-100%) → Influence 60%
    - Réactivité Correction (0-500ms) → Influence 40% (inversé)
    - Formule : RSSI = -80 + (50 × facteur_combiné)
    - Plage résultante : -80 dBm (mauvais) à -30 dBm (excellent)
- **Déclenchement** : 
  - Changement du switch TinyML
  - Modification des sliders Sensibilité et Réactivité
  - Calcule aussi l'amélioration TinyML en temps réel

### 4. **Switch TinyML - Active/Désactive les Sliders**
- **Localisation** : `SettingsFragment.java` → `updateSlidersState()`
- **Comportement** :
  - **TinyML ON** : Les sliders Sensibilité et Réactivité sont actifs (alpha = 1.0)
  - **TinyML OFF** : Les sliders sont grisés et désactivés (alpha = 0.4)
  - Les valeurs sont sauvegardées dans `AppState`
- **Valeurs par défaut** :
  - Sensibilité Signal : 75%
  - Réactivité Correction : 150ms

### 5. **Uptime Réel**
- **Localisation** : `AppState.java` → `startUptimeCounter()`, `updateUptime()`
- **Fonctionnement** :
  - Démarre automatiquement lors de la connexion WebSocket (`FSOWebSocketClient.onOpen()`)
  - Timer actualisé toutes les secondes dans `SettingsFragment`
  - Format d'affichage :
    - `< 1h` : "Xm XXs"
    - `< 24h` : "Xh XXm XXs"
    - `≥ 24h` : "Xj XXh XXm"
- **Réinitialisation** : À chaque nouvelle connexion

### 6. **Statistiques TinyML - Amélioration Signal (24h)**
- **Localisation** : `AppState.java` → `updateTinyMLPerformance()`
- **Calcul** :
  - Moyenne mobile du RSSI avec TinyML vs sans TinyML
  - Pourcentage d'amélioration = (RSSI_avec - RSSI_sans) / |RSSI_sans| × 100
  - Exemple : RSSI sans = -50 dBm, RSSI avec = -35 dBm → Amélioration = 30%
- **Affichage** : 
  - Texte dynamique dans `SettingsFragment` : "TinyML a réduit la perte de signal de XX% au cours des dernières 24h."
  - Si pas encore de données : "TinyML optimise activement le signal. Données en cours de collecte..."
- **TextView** : `@+id/tinyml_status_text`

## 📊 Flux de Données

```
┌─────────────────────────────────────────────────────────────┐
│ Arduino (Capteurs) → ESP32 → WebSocket → Android           │
└─────────────────────────────────────────────────────────────┘
                                    ↓
                    FSOWebSocketClient.processMessage()
                                    ↓
            ┌───────────────────────┴───────────────────────┐
            ↓                       ↓                       ↓
    Luminosité reçue          TinyML params          Connexion
            ↓                       ↓                       ↓
    recalculateBER()        recalculateRSSI()    startUptimeCounter()
    recalculateAttenuation()       ↓                       ↓
            ↓                updateTinyMLPerformance()   updateUptime()
            ↓                       ↓                       ↓
         AppState.notifyChange() → Listeners → UI Update
```

## 🔧 Modifications de Fichiers

### Java
1. **AppState.java**
   - Ajout : `signalSensitivity`, `alignmentReactivity`
   - Ajout : `connectionStartTime`, `tinyMLImprovementPercent`
   - Méthodes : `recalculateBER()`, `recalculateAttenuation()`, `recalculateRSSI()`
   - Méthodes : `startUptimeCounter()`, `updateUptime()`, `updateTinyMLPerformance()`

2. **FSOWebSocketClient.java**
   - Dans `onOpen()` : Appel à `appState.startUptimeCounter()`
   - Dans `processMessage()` "sensors" : Appels à `recalculateBER()` et `recalculateAttenuation()`

3. **SettingsFragment.java**
   - Ajout : `uptimeUpdateRunnable`, `tinymlStatusText`
   - Méthodes : `startUptimeUpdater()`, `stopUptimeUpdater()`, `updateTinyMLStatusText()`
   - Méthodes : `updateSlidersState()` pour activer/désactiver les sliders
   - Listeners : Recalcul RSSI en temps réel lors du mouvement des sliders
   - Lifecycle : `onPause()`, `onDestroy()` pour arrêter le timer

### XML
1. **fragment_settings.xml**
   - Slider Réactivité : `max="500"` (au lieu de 100)
   - Slider Réactivité : `progress="150"` (valeur par défaut)
   - TextView TinyML Status : Ajout `android:id="@+id/tinyml_status_text"`

## 📱 Interface Utilisateur

### Écran Settings
```
┌──────────────────────────────────────┐
│ TinyML Switch                  [ON]  │
│                                      │
│ Seuil sensibilité signal      75%   │
│ ━━━━━━━━━━━━━━━━━━━━━━○━━━━━      │
│                                      │
│ Réactivité correction      150ms    │
│ ━━━━━━━━○━━━━━━━━━━━━━━━━━━━      │
│                                      │
│ TinyML a réduit la perte de signal  │
│ de 23% au cours des dernières 24h.  │
└──────────────────────────────────────┘
```

### Écran Dashboard
- BER et Atténuation varient automatiquement avec la luminosité reçue
- RSSI varie avec les paramètres TinyML (si activé)

## 🧪 Test

### Test 1 : Switch TinyML
1. Aller dans Settings
2. Désactiver TinyML → Sliders grisés, RSSI = -50 dBm
3. Activer TinyML → Sliders actifs, RSSI calculé selon paramètres

### Test 2 : RSSI avec Sensibilité/Réactivité
1. TinyML activé
2. Sensibilité à 100%, Réactivité à 0ms → RSSI ≈ -30 dBm (optimal)
3. Sensibilité à 0%, Réactivité à 500ms → RSSI ≈ -80 dBm (mauvais)

### Test 3 : Uptime
1. Se connecter au WebSocket
2. Observer l'uptime qui commence à 0m 00s
3. Vérifier qu'il s'incrémente chaque seconde

### Test 4 : BER/Atténuation avec Luminosité
1. Simuler faible luminosité (< 100 lux) → BER élevé, Atténuation élevée
2. Simuler forte luminosité (> 10000 lux) → BER faible, Atténuation faible

### Test 5 : Statistiques TinyML
1. Laisser l'app connectée avec TinyML activé
2. Observer le texte : "Données en cours de collecte..."
3. Après quelques échantillons RSSI : "TinyML a réduit... XX%"

## 📝 Notes

- Les calculs BER/Atténuation/RSSI sont côté **Android**, pas ESP32
- L'ESP32 envoie uniquement les données brutes des capteurs
- Les statistiques TinyML utilisent une moyenne mobile (pas de limite 24h réelle pour le moment)
- Pour reset les stats TinyML : Appeler `appState.resetTinyMLStats()`
