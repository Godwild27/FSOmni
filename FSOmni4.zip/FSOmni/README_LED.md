# LED de Connexion ESP-NOW - Guide Rapide

## 🎯 En Bref

**Quoi ?** Une LED sur GPIO 15 de chaque ESP32 qui s'allume quand les deux unités sont connectées via ESP-NOW.

**Comment ?** Détection automatique de l'activité ESP-NOW (envoi/réception de paquets).

**Quand ?** LED ON si activité dans les 5 dernières secondes, sinon LED OFF.

---

## ⚡ Démarrage Rapide

### 1. Câblage (sur chaque ESP32)

```
GPIO 15 → Résistance 220Ω → LED (Anode +)
LED (Cathode -) → GND
```

### 2. Flashage

**Unité 1 :**
```cpp
// Dans config.h
#define UNIT_ID 1
```
Flasher avec Arduino IDE

**Unité 2 :**
```cpp
// Dans config.h
#define UNIT_ID 2
```
Flasher avec Arduino IDE

### 3. Test

1. Allumer les deux ESP32
2. Les LED s'allument automatiquement 💡💡
3. Attendre 6 secondes sans envoyer de message
4. Les LED s'éteignent
5. Envoyer un message depuis Android
6. Les LED se rallument

---

## 📚 Documentation Complète

| Document | Contenu |
|----------|---------|
| **LED_CONNEXION_ESP_NOW.md** | Guide technique complet |
| **FLASH_GUIDE.md** | Procédure de flashage détaillée |
| **SCHEMA_LED_CONNEXION.txt** | Diagrammes et schémas |
| **CHANGELOG_LED.md** | Historique des modifications |

---

## 🔧 Fichiers Modifiés

- `fso_firmware/esp32_fso_gate/config.h` → Ajout `LED_CONNECTION_PIN`
- `fso_firmware/esp32_fso_gate/espnow_link.h` → Ajout fonctions LED
- `fso_firmware/esp32_fso_gate/espnow_link.cpp` → Implémentation LED
- `fso_firmware/esp32_fso_gate/esp32_fso_gate.ino` → Activation LED

---

## ✅ Comportement Normal

| Situation | LED Résultat |
|-----------|--------------|
| Boot unité seule | ⚫ OFF |
| Boot des deux unités | 💡 ON (les deux) |
| Message Android | 💡 ON |
| Inactivité 5s+ | ⚫ OFF |
| Reconnexion | 💡 ON |

---

## 🐛 Dépannage Express

**LED ne s'allume pas ?**
1. Vérifier le câblage (GPIO 15 + résistance + LED)
2. Vérifier la polarité LED (longue patte = anode)
3. Vérifier les logs : `[ESP-NOW] LED connexion sur GPIO 15`
4. Tester manuellement : `digitalWrite(15, HIGH);`

**Les deux LED ne s'allument pas mutuellement ?**
1. Vérifier `UNIT_ID` différent (1 et 2)
2. Vérifier les adresses MAC dans config.h
3. Vérifier distance < 20 mètres
4. Vérifier Serial Monitor pour packets TX/RX

---

## 📞 Support

Consultez la documentation complète dans `LED_CONNEXION_ESP_NOW.md` pour :
- Explication technique détaillée
- Guide de dépannage complet
- Paramètres ajustables
- Améliorations possibles

---

**Version :** FSOmni V3.0  
**Date :** 2026-01-07  
**Status :** ✅ Prêt à flasher
