package com.fso.fsoomni.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.fso.fsoomni.R;
import com.fso.fsoomni.model.AppState;
import com.fso.fsoomni.view.ToggleSwitchView;
import com.fso.fsoomni.websocket.FSOWebSocketClient;

public class SettingsFragment extends Fragment {

    private AppState appState;
    private FSOWebSocketClient wsClient;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable uptimeUpdateRunnable;

    // ÉTAPE 2 : Numéro d'unité
    private android.widget.EditText unitIdInput;
    private TextView unitIdWarning;
    private com.google.android.material.button.MaterialButton btnSaveUnitId;

    private ToggleSwitchView toggleTinyml;
    private SeekBar sliderSensitivity;
    private SeekBar sliderReactivity;
    private TextView sensitivityVal;
    private TextView reactivityVal;
    private TextView espTempValue;
    private TextView espEtatValue;
    private View espTempProgress;
    private View espEtatProgress;
    private TextView uptimeValue;
    private TextView tinymlStatusText;
    private android.widget.LinearLayout logContainer;
    private Runnable espStateUpdateRunnable;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() != null) {
            appState = ((com.fso.fsoomni.activity.MainActivity) getActivity()).getAppState();
            wsClient = ((com.fso.fsoomni.activity.MainActivity) getActivity()).getWsClient();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        // ÉTAPE 2 : Initialiser les vues du numéro d'unité
        unitIdInput = view.findViewById(R.id.unit_id_input);
        unitIdWarning = view.findViewById(R.id.unit_id_warning);
        btnSaveUnitId = view.findViewById(R.id.btn_save_unit_id);

        toggleTinyml = view.findViewById(R.id.toggle_tinyml);
        sliderSensitivity = view.findViewById(R.id.slider_sensitivity);
        sliderReactivity = view.findViewById(R.id.slider_reactivity);
        sensitivityVal = view.findViewById(R.id.sensitivity_val);
        reactivityVal = view.findViewById(R.id.reactivity_val);
        espTempValue = view.findViewById(R.id.esp_temp_value);
        espEtatValue = view.findViewById(R.id.esp_etat_value);
        espTempProgress = view.findViewById(R.id.esp_temp_progress);
        espEtatProgress = view.findViewById(R.id.esp_etat_progress);
        uptimeValue = view.findViewById(R.id.uptime_value);
        tinymlStatusText = view.findViewById(R.id.tinyml_status_text);
        logContainer = view.findViewById(R.id.log_container);

        // ================================================================
        // ÉTAPE 2 : Configuration du numéro d'unité
        // ================================================================
        
        // Charger le numéro actuel depuis AppState
        if (appState != null) {
            int currentUnitId = appState.getMyUnitId();
            if (currentUnitId > 0) {
                unitIdInput.setText(String.valueOf(currentUnitId));
            }
        }
        
        // Validation en temps réel
        unitIdInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String input = s.toString();
                
                // Vérifier si c'est uniquement des chiffres
                if (!input.isEmpty() && !input.matches("\\d+")) {
                    // Contient des caractères non numériques
                    unitIdWarning.setVisibility(View.VISIBLE);
                } else {
                    unitIdWarning.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {}
        });
        
        // Bouton enregistrer
        btnSaveUnitId.setOnClickListener(v -> {
            String input = unitIdInput.getText().toString().trim();
            
            if (input.isEmpty()) {
                // L'utilisateur a vidé le champ → on met 0 (non configuré)
                if (appState != null) {
                    appState.setMyUnitId(0);
                }
                saveUnitIdToPrefs(0);
                android.widget.Toast.makeText(getContext(), 
                    "Numéro d'unité effacé", 
                    android.widget.Toast.LENGTH_SHORT).show();
            }
            else if (!input.matches("\\d+")) {
                // Contient des caractères non numériques → REFUSER
                unitIdWarning.setVisibility(View.VISIBLE);
                android.widget.Toast.makeText(getContext(), 
                    "⚠️ Uniquement des chiffres autorisés", 
                    android.widget.Toast.LENGTH_SHORT).show();
            }
            else {
                // Valide : uniquement des chiffres
                int unitId = Integer.parseInt(input);
                if (appState != null) {
                    appState.setMyUnitId(unitId);
                }
                saveUnitIdToPrefs(unitId);
                android.widget.Toast.makeText(getContext(), 
                    "✅ Unité " + unitId + " enregistrée", 
                    android.widget.Toast.LENGTH_SHORT).show();
            }
        });

        // Initialize toggle
        if (appState != null) {
            toggleTinyml.setChecked(appState.isTinymlEnabled());
            sliderSensitivity.setProgress(appState.getSignalSensitivity());
            sliderReactivity.setProgress(appState.getAlignmentReactivity());
            sensitivityVal.setText(appState.getSignalSensitivity() + "%");
            reactivityVal.setText(appState.getAlignmentReactivity() + "ms");
            
            // Activer/désactiver les sliders selon l'état TinyML
            updateSlidersState(appState.isTinymlEnabled());
        }

        // TinyML toggle
        toggleTinyml.setOnCheckedChangeListener(isChecked -> {
            if (appState != null) {
                appState.setTinymlEnabled(isChecked);
                // Recalculer le RSSI en fonction du nouvel état
                appState.recalculateRSSI();
                // Activer/désactiver les sliders
                updateSlidersState(isChecked);
            }
            if (wsClient != null) {
                wsClient.sendTinymlCommand(isChecked,
                        sliderSensitivity.getProgress(),
                        sliderReactivity.getProgress());
            }
        });

        // Sensitivity slider
        sliderSensitivity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                sensitivityVal.setText(progress + "%");
                if (fromUser && appState != null) {
                    appState.setSignalSensitivity(progress);
                    // Recalculer le RSSI en temps réel
                    appState.recalculateRSSI();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (wsClient != null) {
                    wsClient.sendTinymlCommand(
                            toggleTinyml.isChecked(),
                            sliderSensitivity.getProgress(),
                            sliderReactivity.getProgress());
                }
            }
        });

        // Reactivity slider
        sliderReactivity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                reactivityVal.setText(progress + "ms");
                if (fromUser && appState != null) {
                    appState.setAlignmentReactivity(progress);
                    // Recalculer le RSSI en temps réel
                    appState.recalculateRSSI();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (wsClient != null) {
                    wsClient.sendTinymlCommand(
                            toggleTinyml.isChecked(),
                            sliderSensitivity.getProgress(),
                            sliderReactivity.getProgress());
                }
            }
        });

        // Connection button -> go to config
        view.findViewById(R.id.btn_connect_system).setOnClickListener(v -> {
            if (getActivity() != null) {
                ((com.fso.fsoomni.activity.MainActivity) getActivity()).navigateTo(0);
            }
        });
        
        // Bouton "Voir tous les logs"
        view.findViewById(R.id.btn_view_logs).setOnClickListener(v -> {
            showAllLogsDialog();
        });
        
        // Charger les logs initiaux
        updateLogDisplay();

        // State listener
        if (appState != null) {
            appState.addOnStateChangeListener((key, value) -> handler.post(() -> {
                switch (key) {
                    case "espTemp": {
                        espTempValue.setText(String.format("%.0f°C", (Double) value));
                        int tempPercent = (int) Math.min(100, (Double) value);
                        View tempParent = (View) espTempProgress.getParent();
                        if (tempParent.getWidth() > 0) {
                            FrameLayout.LayoutParams tempParams = (FrameLayout.LayoutParams) espTempProgress.getLayoutParams();
                            tempParams.width = (int) (tempPercent / 100f * tempParent.getWidth());
                            espTempProgress.setLayoutParams(tempParams);
                        }
                        break;
                    }
                    case "espEtat": {
                        espEtatValue.setText(String.format("%.0f%%", (Double) value));
                        int etatPercent = ((Double) value).intValue();
                        View etatParent = (View) espEtatProgress.getParent();
                        if (etatParent.getWidth() > 0) {
                            FrameLayout.LayoutParams etatParams = (FrameLayout.LayoutParams) espEtatProgress.getLayoutParams();
                            etatParams.width = (int) (etatPercent / 100f * etatParent.getWidth());
                            espEtatProgress.setLayoutParams(etatParams);
                        }
                        break;
                    }
                    case "espUptime":
                        uptimeValue.setText((String) value);
                        break;
                    case "tinyMLImprovement":
                        updateTinyMLStatusText();
                        break;
                    case "newLog":
                        updateLogDisplay();
                        break;
                }
            }));
        }
        
        // Démarrer la mise à jour périodique de l'uptime
        startUptimeUpdater();
        
        // Démarrer la mise à jour périodique de l'état ESP
        startEspStateUpdater();

        return view;
    }
    
    /**
     * Démarrer la mise à jour automatique de l'uptime toutes les secondes
     */
    private void startUptimeUpdater() {
        uptimeUpdateRunnable = new Runnable() {
            @Override
            public void run() {
                if (appState != null) {
                    appState.updateUptime();
                }
                handler.postDelayed(this, 1000); // Mise à jour toutes les secondes
            }
        };
        handler.post(uptimeUpdateRunnable);
    }
    
    /**
     * Arrêter la mise à jour de l'uptime
     */
    private void stopUptimeUpdater() {
        if (uptimeUpdateRunnable != null) {
            handler.removeCallbacks(uptimeUpdateRunnable);
        }
    }
    
    /**
     * Démarrer la mise à jour périodique de l'état ESP32
     */
    private void startEspStateUpdater() {
        espStateUpdateRunnable = new Runnable() {
            @Override
            public void run() {
                if (appState != null) {
                    appState.updateEspEtat();
                    // Recalculer aussi la température ESP (légère variation)
                    appState.calculateEspTemperature();
                }
                handler.postDelayed(this, 1000); // Mise à jour toutes les secondes
            }
        };
        handler.post(espStateUpdateRunnable);
    }
    
    /**
     * Arrêter la mise à jour de l'état ESP
     */
    private void stopEspStateUpdater() {
        if (espStateUpdateRunnable != null) {
            handler.removeCallbacks(espStateUpdateRunnable);
        }
    }
    
    /**
     * Mettre à jour le texte de statut TinyML avec le pourcentage réel
     */
    private void updateTinyMLStatusText() {
        if (tinymlStatusText == null || appState == null) return;
        
        double improvement = appState.getTinyMLImprovementPercent();
        if (improvement > 0) {
            tinymlStatusText.setText(String.format(
                "TinyML a réduit la perte de signal de %.0f%% au cours des dernières 24h.",
                improvement
            ));
        } else {
            tinymlStatusText.setText(
                "TinyML optimise activement le signal. Données en cours de collecte..."
            );
        }
    }
    
    /**
     * Mettre à jour l'affichage des logs (les 4 derniers)
     */
    private void updateLogDisplay() {
        if (logContainer == null || appState == null || getContext() == null) return;
        
        logContainer.removeAllViews();
        java.util.List<com.fso.fsoomni.model.AppState.LogEvent> recentLogs = appState.getRecentLogs(4);
        
        if (recentLogs.isEmpty()) {
            // Message par défaut si aucun log
            TextView emptyView = new TextView(getContext());
            emptyView.setText("Aucun événement récent");
            emptyView.setTextSize(12);
            emptyView.setTextColor(getResources().getColor(R.color.on_surface_variant, getContext().getTheme()));
            emptyView.setAlpha(0.5f);
            emptyView.setPadding(0, 16, 0, 16);
            logContainer.addView(emptyView);
            return;
        }
        
        for (com.fso.fsoomni.model.AppState.LogEvent log : recentLogs) {
            TextView logView = new TextView(getContext());
            logView.setText(log.timestamp + "  " + log.message);
            logView.setTextSize(12);
            logView.setTextColor(getResources().getColor(R.color.on_surface, getContext().getTheme()));
            logView.setTypeface(android.graphics.Typeface.MONOSPACE);
            logView.setPadding(0, 8, 0, 8);
            logView.setAlpha(0.7f);
            
            // Couleur selon le niveau
            switch (log.level) {
                case SUCCESS:
                    logView.setTextColor(getResources().getColor(R.color.tertiary, getContext().getTheme()));
                    break;
                case WARNING:
                    logView.setTextColor(getResources().getColor(R.color.primary, getContext().getTheme()));
                    break;
                case ERROR:
                    logView.setTextColor(getResources().getColor(R.color.error, getContext().getTheme()));
                    break;
            }
            
            logContainer.addView(logView);
        }
    }
    
    /**
     * Afficher le dialogue avec tous les logs
     */
    private void showAllLogsDialog() {
        if (appState == null || getContext() == null) return;
        
        java.util.List<com.fso.fsoomni.model.AppState.LogEvent> allLogs = appState.getAllLogs();
        
        if (allLogs.isEmpty()) {
            android.widget.Toast.makeText(getContext(), "Aucun log disponible", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Créer un ScrollView avec tous les logs
        ScrollView scrollView = new ScrollView(getContext());
        LinearLayout logLayout = new LinearLayout(getContext());
        logLayout.setOrientation(LinearLayout.VERTICAL);
        logLayout.setPadding(32, 16, 32, 16);
        
        for (com.fso.fsoomni.model.AppState.LogEvent log : allLogs) {
            TextView logView = new TextView(getContext());
            logView.setText(log.timestamp + "  " + log.message);
            logView.setTextSize(12);
            logView.setTextColor(getResources().getColor(R.color.on_surface, getContext().getTheme()));
            logView.setTypeface(android.graphics.Typeface.MONOSPACE);
            logView.setPadding(0, 8, 0, 8);
            
            // Couleur selon le niveau
            switch (log.level) {
                case SUCCESS:
                    logView.setTextColor(getResources().getColor(R.color.tertiary, getContext().getTheme()));
                    break;
                case WARNING:
                    logView.setTextColor(getResources().getColor(R.color.primary, getContext().getTheme()));
                    break;
                case ERROR:
                    logView.setTextColor(getResources().getColor(R.color.error, getContext().getTheme()));
                    break;
            }
            
            logLayout.addView(logView);
        }
        
        scrollView.addView(logLayout);
        
        // Créer le dialogue
        new androidx.appcompat.app.AlertDialog.Builder(getContext())
            .setTitle("Tous les journaux (" + allLogs.size() + " événements)")
            .setView(scrollView)
            .setPositiveButton("Fermer", null)
            .setNeutralButton("Effacer tous", (dialog, which) -> {
                appState.clearLogs();
                updateLogDisplay();
                android.widget.Toast.makeText(getContext(), "Logs effacés", android.widget.Toast.LENGTH_SHORT).show();
            })
            .show();
    }

    /**
     * Active ou désactive les sliders en fonction de l'état TinyML
     */
    private void updateSlidersState(boolean tinymlEnabled) {
        sliderSensitivity.setEnabled(tinymlEnabled);
        sliderReactivity.setEnabled(tinymlEnabled);
        
        // Changer l'opacité visuelle pour indiquer l'état
        float alpha = tinymlEnabled ? 1.0f : 0.4f;
        sliderSensitivity.setAlpha(alpha);
        sliderReactivity.setAlpha(alpha);
        sensitivityVal.setAlpha(alpha);
        reactivityVal.setAlpha(alpha);
    }

    /**
     * ÉTAPE 2 : Sauvegarder le numéro d'unité dans SharedPreferences
     */
    private void saveUnitIdToPrefs(int unitId) {
        if (getActivity() != null) {
            getActivity().getSharedPreferences(com.fso.fsoomni.FSOmniApp.PREFS_NAME, android.content.Context.MODE_PRIVATE)
                .edit()
                .putInt("my_unit_id", unitId)
                .apply();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (appState != null) {
            espTempValue.setText(String.format("%.0f°C", appState.getEspTemp()));
            espEtatValue.setText(String.format("%.0f%%", appState.getEspEtat()));
            uptimeValue.setText(appState.getEspUptime());
            updateTinyMLStatusText();
            updateLogDisplay();
        }
    }
    
    @Override
    public void onPause() {
        super.onPause();
        stopUptimeUpdater();
        stopEspStateUpdater();
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        stopUptimeUpdater();
        stopEspStateUpdater();
    }
}
