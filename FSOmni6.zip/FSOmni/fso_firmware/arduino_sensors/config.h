// ================================================================
// config.h — Configuration Arduino Sensors V2
// ================================================================
// Arduino Uno lit les capteurs I2C à 20 Hz et envoie le résultat
// sur UART (Serial) à l'ESP32 au format JSON.
// ================================================================

#ifndef CONFIG_H
#define CONFIG_H

// ================================================================
// I2C (Arduino Uno : SDA=A4, SCL=A5 — fixé hardware, non modifiable)
// ================================================================
#define I2C_SDA A4
#define I2C_SCL A5
#define I2C_FREQ 100000  // 100 kHz

// ================================================================
// UART
// ================================================================
#define SERIAL_BAUD 115200

// ================================================================
// FRÉQUENCE LECTURE CAPTEURS
// ================================================================
#define SENSOR_READ_INTERVAL_MS 200  // 200 ms = 5 Hz (réduit pour stabilité UART)

// ================================================================
// SERVO MOTEUR (Alignement horizontal)
// ================================================================
#define SERVO_PIN 9           // Pin PWM pour le servo
#define SERVO_MIN_ANGLE -45   // Angle minimal (degrés)
#define SERVO_MAX_ANGLE 45    // Angle maximal (degrés)
#define SERVO_DEFAULT_ANGLE 0 // Position par défaut au démarrage

// ================================================================
// VERSION (pour message "ready" au boot)
// ================================================================
#define FIRMWARE_VERSION "Arduino Sensors V2.1 + Servo"

#endif
