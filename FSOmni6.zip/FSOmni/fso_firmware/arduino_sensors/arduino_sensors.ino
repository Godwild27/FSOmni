// ================================================================
// arduino_sensors.ino — Mode SILENCIEUX + Servo Control
// ================================================================
// L'Arduino envoie les données à l'ESP32 mais N'AFFICHE RIEN
// sur le Serial Monitor pour garder l'affichage propre.
// Contrôle un servo moteur pour l'alignement horizontal.
// ================================================================

#include "config.h"
#include "sensors.h"
#include <ArduinoJson.h>
#include <Servo.h>

unsigned long lastSensorReadTime = 0;

// ================================================================
// SERVO MOTEUR
// ================================================================
Servo alignmentServo;
float currentServoAngle = SERVO_DEFAULT_ANGLE;  // Position actuelle en degrés

// ================================================================
// INITIALISATION SERVO
// ================================================================
void initServo() {
  alignmentServo.attach(SERVO_PIN);
  setServoAngle(SERVO_DEFAULT_ANGLE);  // Position centrale au démarrage
}

// ================================================================
// DÉFINIR ANGLE SERVO
// ================================================================
void setServoAngle(float angle) {
  // Limiter l'angle entre MIN et MAX
  angle = constrain(angle, SERVO_MIN_ANGLE, SERVO_MAX_ANGLE);
  currentServoAngle = angle;
  
  // Convertir angle (-45° à +45°) en valeur servo (0° à 180°)
  // -45° → 0°, 0° → 90°, +45° → 180°
  int servoValue = map((int)(angle * 10), 
                       SERVO_MIN_ANGLE * 10, 
                       SERVO_MAX_ANGLE * 10, 
                       0, 
                       180);
  
  alignmentServo.write(servoValue);
}

// ================================================================
// ENVOI CAPTEURS (vers ESP32 uniquement, pas d'affichage)
// ================================================================
void sendSensorsEvent() {
  StaticJsonDocument<256> doc;
  doc[F("evt")] = F("sensors");
  doc[F("temp")] = currentSensorData.temperature;
  doc[F("pres")] = currentSensorData.pressure;
  doc[F("alt")] = currentSensorData.altitude;
  doc[F("lux")] = currentSensorData.luminosity;
  doc[F("ax")] = currentSensorData.accelX;
  doc[F("ay")] = currentSensorData.accelY;
  doc[F("az")] = currentSensorData.accelZ;
  doc[F("gx")] = currentSensorData.gyroX;
  doc[F("gy")] = currentSensorData.gyroY;
  doc[F("gz")] = currentSensorData.gyroZ;
  doc[F("vib")] = currentSensorData.vibration;
  doc[F("att")] = currentSensorData.attenuation;
  serializeJson(doc, Serial);
  Serial.println();
}

// ================================================================
// ENVOI PONG
// ================================================================
void sendPong() {
  Serial.println(F("{\"evt\":\"pong\"}"));
}

// ================================================================
// TRAITEMENT COMMANDES
// ================================================================
void handleSerialCommands() {
  if (!Serial.available()) return;
  String line = Serial.readStringUntil('\n');
  line.trim();
  if (line.length() == 0) return;
  
  StaticJsonDocument<128> doc;
  if (deserializeJson(doc, line)) return;
  
  const char* cmd = doc["cmd"];
  
  // Commande PING
  if (cmd && strcmp(cmd, "ping") == 0) {
    sendPong();
  }
  // Commande SERVO
  else if (cmd && strcmp(cmd, "servo") == 0) {
    if (doc.containsKey("angle")) {
      float angle = doc["angle"];
      setServoAngle(angle);
      
      // Envoyer confirmation
      StaticJsonDocument<64> response;
      response["evt"] = "servo_ack";
      response["angle"] = currentServoAngle;
      serializeJson(response, Serial);
      Serial.println();
    }
  }
}

// ================================================================
// SETUP
// ================================================================
void setup() {
  Serial.begin(SERIAL_BAUD);
  delay(500);
  initSensors();
  initServo();  // Initialiser le servo
  readSensors();
}

// ================================================================
// LOOP
// ================================================================
void loop() {
  handleSerialCommands();
  
  if (millis() - lastSensorReadTime >= SENSOR_READ_INTERVAL_MS) {
    readSensors();
    sendSensorsEvent();
    lastSensorReadTime = millis();
  }
}
