// ================================================================
// websocket_handler.cpp — Implémentation WebSocket (V3)
// ================================================================
// V3 : 
//   - Quand Android envoie {"type":2,"text":"..."}, on appelle 
//     espNowSend() au lieu de LaserEngine.send()
//   - Le laser (laserGateTxStart/Stop) clignote en parallèle 
//     pendant l'envoi ESP-NOW (preuve optique)
//   - Format des messages vers Android INCHANGÉ
// ================================================================

#include "websocket_handler.h"
#include "arduino_comm.h"
#include "wifi_manager.h"
#include "sensors.h"
#include "espnow_link.h"
#include "laser_gate.h"
#include "config.h"

AsyncWebServer server(WS_PORT);
AsyncWebSocket ws("/");

// ================================================================
// DÉCLARATION FONCTION
// ================================================================
void onWsEvent(AsyncWebSocket *server, AsyncWebSocketClient *client,
               AwsEventType type, void *arg, uint8_t *data, size_t len);

// ================================================================
// INITIALISATION
// ================================================================
void initWebSocket() {
  ws.onEvent(onWsEvent);
  server.addHandler(&ws);

  // Page web d'accueil
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
    String html = "<html><head><meta charset='utf-8'></head><body>";
    html += "<h1>ESP32 FSOmni Gate V3.0</h1>";
    html += "<p><strong>Unité " + String(UNIT_ID) + "</strong></p>";
    html += "<p><strong>Serveur WebSocket actif</strong></p>";
    html += "<p>ws://" + getAPIP().toString() + ":" + String(WS_PORT) + "/</p>";
    html += "<p>ESP-NOW transport + Laser gate validation</p>";
    html += "</body></html>";
    request->send(200, "text/html", html);
  });

  server.begin();
  Serial.printf("[WS] WebSocket : ws://%s:%d/\n", getAPIP().toString().c_str(), WS_PORT);
}

// ================================================================
// GESTION ÉVÉNEMENTS WEBSOCKET
// ================================================================
void onWsEvent(AsyncWebSocket *server, AsyncWebSocketClient *client,
               AwsEventType type, void *arg, uint8_t *data, size_t len) {

  switch(type) {
    case WS_EVT_CONNECT:
      Serial.printf("[WS] Client connecte [ID:%u] %s\n",
                    client->id(), client->remoteIP().toString().c_str());

      // Message de bienvenue
      {
        StaticJsonDocument<256> doc;
        doc["type"] = "connected";
        doc["message"] = "ESP32 FSOmni Gate V3.0";
        doc["device"] = "ESP32-S3";
        doc["firmware_version"] = FIRMWARE_VERSION;
        doc["unit_id"] = UNIT_ID;
        doc["peer_mac"] = PEER_MAC_STR;
        String msg;
        serializeJson(doc, msg);
        client->text(msg);
      }

      // Télémétrie initiale
      {
        StaticJsonDocument<512> doc;
        doc["type"] = "telemetry";
        doc["gate_open"] = laserGateIsOpen();
        doc["espnow_ready"] = espNowIsReady();
        doc["laser_pulse_count"] = laserGateGetPulseCount();
        String msg;
        serializeJson(doc, msg);
        client->text(msg);
      }

      sendArduinoStatus();
      break;

    case WS_EVT_DISCONNECT:
      Serial.printf("[WS] Client deconnecte [ID:%u]\n", client->id());
      break;

    case WS_EVT_DATA:
      {
        // Buffer local pour éviter data[len]=0 (UB)
        char buf[1025];
        size_t copyLen = (len < sizeof(buf) - 1) ? len : sizeof(buf) - 1;
        memcpy(buf, data, copyLen);
        buf[copyLen] = 0;

        String message = String(buf);
        Serial.printf("[WS] msg [ID:%u]: %s\n", client->id(), message.c_str());

        StaticJsonDocument<1024> doc;
        if (deserializeJson(doc, message)) {
          Serial.println("[WS] JSON parse error");
          return;
        }

        // ─── Type numérique ───
        if (doc["type"].is<int>()) {
          int typeNum = doc["type"];

          // Type 2 : Message texte → envoyer via ESP-NOW
          if (typeNum == 2) {
            const char* text = doc["text"];
            int unitId = doc.containsKey("unit_id") ? doc["unit_id"].as<int>() : UNIT_ID;

            Serial.printf("[WS] -> ESP-NOW TX de Unité %d: \"%s\"\n", unitId, text);

            // Envoyer les données via ESP-NOW (avec unit_id)
            // Les lasers ne sont plus utilisés
            bool ok = espNowSend((const uint8_t*)text, strlen(text), ESPNOW_MSG_TEXT, unitId);

            // Notifier Android
            if (ok) {
              ws.textAll("{\"type\":10,\"status\":\"tx_started\"}");
            } else {
              ws.textAll("{\"type\":10,\"status\":\"tx_error\"}");
            }
          }
          // Type 12 : Ping
          else if (typeNum == 12) {
            StaticJsonDocument<128> resp;
            resp["type"] = 13;
            resp["timestamp"] = millis();
            String msg;
            serializeJson(resp, msg);
            client->text(msg);
          }
        }
        // ─── Type string ───
        else if (doc["type"].is<const char*>()) {
          const char* msgType = doc["type"];

          if (strcmp(msgType, "ping") == 0) {
            client->text("{\"type\":\"pong\",\"timestamp\":" + String(millis()) + "}");
          }
          // Stats ESP-NOW + gate
          else if (strcmp(msgType, "stats") == 0) {
            StaticJsonDocument<256> resp;
            resp["type"] = "stats";
            resp["unit_id"] = UNIT_ID;
            resp["gate_open"] = laserGateIsOpen();
            resp["last_pulse_ms"] = laserGateTimeSinceLastPulse();
            resp["pulse_count"] = laserGateGetPulseCount();
            resp["espnow_tx"] = espNowGetTxCount();
            resp["espnow_rx"] = espNowGetRxCount();
            resp["espnow_tx_errors"] = espNowGetTxErrors();
            resp["espnow_rx_errors"] = espNowGetRxErrors();
            String msg;
            serializeJson(resp, msg);
            client->text(msg);
          }
          // Servo (réservé)
          else if (strcmp(msgType, "servo") == 0) {
            const char* axis = doc["axis"];
            float value = doc["value"];
            
            if (axis && strcmp(axis, "tilt") == 0) {
              Serial.printf("[WS] Servo tilt : %.2f°\n", value);
              sendArduinoServo(value);
              
              // Répondre à Android
              client->text("{\"type\":\"servo_ack\",\"axis\":\"tilt\",\"value\":" + String(value) + "}");
            }
          }
        }
      }
      break;

    case WS_EVT_PONG:
      Serial.printf("[WS] Pong [ID:%u]\n", client->id());
      break;

    case WS_EVT_ERROR:
      Serial.printf("[WS] Error [ID:%u]\n", client->id());
      break;
  }
}

// ================================================================
// BROADCAST VERS CLIENTS (format INCHANGÉ pour Android)
// ================================================================
void broadcastLaserRx(const String& text, int unitId) {
  StaticJsonDocument<512> doc;
  doc["type"] = 2;
  doc["text"] = text;
  doc["unit_id"] = unitId;
  doc["length"] = text.length();
  String msg;
  serializeJson(doc, msg);
  ws.textAll(msg);
  Serial.println("[WS] RX broadcasted");
}

void broadcastTxStatus(const String& status, int queueLen) {
  (void)queueLen;
  if (status == "tx_started") {
    ws.textAll("{\"type\":10,\"status\":\"tx_started\"}");
  } else if (status == "tx_done") {
    ws.textAll("{\"type\":10,\"status\":\"tx_done\"}");
  } else if (status == "tx_error") {
    ws.textAll("{\"type\":10,\"status\":\"tx_error\"}");
  }
}

void broadcastError(const String& error) {
  StaticJsonDocument<256> doc;
  doc["type"] = 99;
  doc["message"] = error;
  String msg;
  serializeJson(doc, msg);
  ws.textAll(msg);
}

// ================================================================
// BROADCAST DONNÉES CAPTEURS (20 Hz, INCHANGÉ)
// ================================================================
void broadcastSensorsData() {
  if (ws.count() == 0) return;

  StaticJsonDocument<512> doc;
  doc["type"] = "sensors";

  doc["temperature"] = currentSensorData.temperature;
  doc["pressure"] = currentSensorData.pressure;
  doc["altitude"] = currentSensorData.altitude;
  doc["luminosity"] = currentSensorData.luminosity;
  doc["attenuation"] = currentSensorData.attenuation;

  JsonObject accel = doc.createNestedObject("accelerometer");
  accel["x"] = currentSensorData.accelX;
  accel["y"] = currentSensorData.accelY;
  accel["z"] = currentSensorData.accelZ;

  JsonObject gyro = doc.createNestedObject("gyroscope");
  gyro["x"] = currentSensorData.gyroX;
  gyro["y"] = currentSensorData.gyroY;
  gyro["z"] = currentSensorData.gyroZ;

  doc["vibration"] = currentSensorData.vibration;

  String msg;
  serializeJson(doc, msg);
  ws.textAll(msg);
}

// ================================================================
// BOUCLE DE MAINTENANCE
// ================================================================
void websocketLoop() {
  ws.cleanupClients();
}

// ================================================================
// WEBSOCKET KEEPALIVE PING
// ================================================================
void sendWebSocketPing() {
  if (ws.count() > 0) {
    StaticJsonDocument<64> doc;
    doc["type"] = "ping";
    doc["timestamp"] = millis();
    String msg;
    serializeJson(doc, msg);
    ws.textAll(msg);
  }
}
