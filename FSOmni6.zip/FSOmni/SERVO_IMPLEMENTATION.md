# 🔧 Implémentation du Contrôle Servo - Page Alignement

## ✅ IMPLÉMENTATION TERMINÉE

Le contrôle du servo moteur est maintenant fonctionnel depuis la page Alignement de l'application Android.

---

## 🎯 FONCTIONNEMENT

### Flux de Commande

```
┌──────────────────────────────────────────────────────────────┐
│                    APPLICATION ANDROID                        │
│                                                               │
│  Page Alignement                                             │
│  ┌─────────────────────────────────────────┐                │
│  │  [←]  Servo: 12.5°  [→]                │                │
│  │                                          │                │
│  │  Auto-align: OFF                         │                │
│  └─────────────────────────────────────────┘                │
│                                                               │
│  Utilisateur clique [→]                                      │
│  ↓                                                            │
│  AlignmentFragment.moveServo(+0.5)                          │
│  ↓                                                            │
│  wsClient.sendServoCommand("tilt", 13.0)                    │
│  ↓                                                            │
│  WebSocket → {"type":"servo", "axis":"tilt", "value":13.0}  │
└────────────────────────┬─────────────────────────────────────┘
                         │
                         │ WiFi
                         │
┌────────────────────────▼─────────────────────────────────────┐
│                    ESP32-S3 N16R8                            │
│                                                               │
│  websocket_handler.cpp                                       │
│  ↓                                                            │
│  Reçoit {"type":"servo", "axis":"tilt", "value":13.0}       │
│  ↓                                                            │
│  sendArduinoServo(13.0)                                      │
│  ↓                                                            │
│  UART → {"cmd":"servo", "angle":13.0}                        │
└────────────────────────┬─────────────────────────────────────┘
                         │
                         │ UART (115200 baud)
                         │
┌────────────────────────▼─────────────────────────────────────┐
│                    ARDUINO UNO                               │
│                                                               │
│  arduino_sensors.ino                                         │
│  ↓                                                            │
│  Reçoit {"cmd":"servo", "angle":13.0}                        │
│  ↓                                                            │
│  setServoAngle(13.0)                                         │
│  ↓                                                            │
│  Convertit -45°→+45° en 0→180 pour servo                    │
│  ↓                                                            │
│  alignmentServo.write(servoValue)                            │
│  ↓                                                            │
│  📍 SERVO BOUGE à 13.0°                                      │
│  ↓                                                            │
│  Envoie {"evt":"servo_ack", "angle":13.0}                   │
└──────────────────────────────────────────────────────────────┘
```

---

## 🔧 MODIFICATIONS APPORTÉES

### 1️⃣ Arduino Firmware (3 modifications)

#### `config.h` - Configuration servo
```cpp
// Servo moteur sur pin 9 (PWM)
#define SERVO_PIN 9
#define SERVO_MIN_ANGLE -45   // -45° (gauche)
#define SERVO_MAX_ANGLE 45    // +45° (droite)
#define SERVO_DEFAULT_ANGLE 0 // 0° (centre)
```

#### `arduino_sensors.ino` - Contrôle servo
```cpp
#include <Servo.h>

Servo alignmentServo;
float currentServoAngle = SERVO_DEFAULT_ANGLE;

void initServo() {
  alignmentServo.attach(SERVO_PIN);
  setServoAngle(SERVO_DEFAULT_ANGLE);
}

void setServoAngle(float angle) {
  angle = constrain(angle, SERVO_MIN_ANGLE, SERVO_MAX_ANGLE);
  currentServoAngle = angle;
  
  // Convertir -45°→+45° en 0→180
  int servoValue = map((int)(angle * 10), -450, 450, 0, 180);
  alignmentServo.write(servoValue);
}

// Dans handleSerialCommands():
else if (cmd && strcmp(cmd, "servo") == 0) {
  if (doc.containsKey("angle")) {
    float angle = doc["angle"];
    setServoAngle(angle);
    
    // Confirmation
    StaticJsonDocument<64> response;
    response["evt"] = "servo_ack";
    response["angle"] = currentServoAngle;
    serializeJson(response, Serial);
    Serial.println();
  }
}
```

### 2️⃣ ESP32 Firmware (2 modifications)

#### `arduino_comm.h` / `arduino_comm.cpp` - Transmission servo
```cpp
// Dans arduino_comm.h
void sendArduinoServo(float angle);

// Dans arduino_comm.cpp
void sendArduinoServo(float angle) {
  angle = constrain(angle, -45.0, 45.0);
  
  StaticJsonDocument<64> doc;
  doc["cmd"] = "servo";
  doc["angle"] = angle;
  
  String jsonStr;
  serializeJson(doc, jsonStr);
  ARDUINO_SERIAL.println(jsonStr);
  
  Serial.printf("→ Arduino: Servo %.2f°\n", angle);
}

// Gestion de la réponse
else if (strcmp(evt, "servo_ack") == 0) {
  float angle = doc["angle"] | 0.0;
  Serial.printf("✅ Arduino: Servo @ %.2f°\n", angle);
}
```

#### `websocket_handler.cpp` - Réception commande WebSocket
```cpp
else if (strcmp(msgType, "servo") == 0) {
  const char* axis = doc["axis"];
  float value = doc["value"];
  
  if (axis && strcmp(axis, "tilt") == 0) {
    Serial.printf("[WS] Servo tilt : %.2f°\n", value);
    sendArduinoServo(value);
    
    // Répondre à Android
    client->text("{\"type\":\"servo_ack\",\"axis\":\"tilt\",\"value\":" + String(value) + "}");
  }
}
```

### 3️⃣ Android App (✅ Déjà implémenté)

Le code Android était **déjà fonctionnel**, il n'y a **AUCUNE modification** nécessaire!

**`AlignmentFragment.java`** :
- ✅ Boutons gauche/droite fonctionnels
- ✅ Incréments de ±0.5° par clic
- ✅ Maintien du bouton = répétition automatique
- ✅ Désactivation si auto-align est ON
- ✅ Envoi via `wsClient.sendServoCommand("tilt", angle)`

---

## 🔌 CÂBLAGE MATÉRIEL

### Servo Moteur SG90 (ou équivalent)

```
┌──────────────────┐
│   ARDUINO UNO    │
│                  │
│  Pin 9 (PWM) ────┼──→ Signal (Jaune/Orange)
│  5V          ────┼──→ VCC (Rouge)
│  GND         ────┼──→ GND (Marron/Noir)
│                  │
└──────────────────┘
```

**⚠️ IMPORTANT** :
- Le servo doit être alimenté en **5V** (pas 3.3V)
- Si le servo tire trop de courant, utiliser une **alimentation externe**
- Relier le **GND commun** entre Arduino et alimentation externe

### Pins Arduino Utilisés

| Pin | Fonction | Description |
|-----|----------|-------------|
| 9 | Servo PWM | Signal de contrôle du servo |
| A4 | I2C SDA | Capteurs (BMP280/180, BH1750, MPU6050) |
| A5 | I2C SCL | Capteurs |
| 0 | RX | Communication UART avec ESP32 |
| 1 | TX | Communication UART avec ESP32 |

---

## 🎮 UTILISATION

### Page Alignement

1. **Se connecter** au WebSocket de l'ESP32
2. **Aller sur la page Alignement**
3. **Désactiver Auto-align** (switch OFF)
4. **Utiliser les boutons** :
   - **[←]** : Tourner le servo vers la gauche (-0.5° par clic)
   - **[→]** : Tourner le servo vers la droite (+0.5° par clic)
   - **Maintenir le bouton** : Rotation continue

### Comportement

- **Angle affiché** : Mise à jour en temps réel
- **Limites** : -45° (gauche max) à +45° (droite max)
- **Position initiale** : 0° (centre)
- **Si Auto-align ON** : Boutons désactivés (alpha 0.4)

---

## 📊 PROTOCOLE DE COMMUNICATION

### Android → ESP32 (WebSocket)
```json
{
  "type": "servo",
  "axis": "tilt",
  "value": 13.5
}
```

### ESP32 → Arduino (UART)
```json
{
  "cmd": "servo",
  "angle": 13.5
}
```

### Arduino → ESP32 (UART)
```json
{
  "evt": "servo_ack",
  "angle": 13.5
}
```

### ESP32 → Android (WebSocket)
```json
{
  "type": "servo_ack",
  "axis": "tilt",
  "value": 13.5
}
```

---

## 🧪 TESTS À EFFECTUER

### Test 1 : Position Initiale
1. Flasher l'Arduino
2. Observer le servo → doit être à **0° (centre)**
3. ✅ PASS si servo centré

### Test 2 : Contrôle depuis Android
1. Se connecter à l'ESP32
2. Aller sur Alignement
3. Désactiver Auto-align
4. Cliquer [→] 10 fois → angle doit afficher **+5.0°**
5. Observer le servo → doit tourner à droite
6. Cliquer [←] 20 fois → angle doit afficher **-5.0°**
7. Observer le servo → doit tourner à gauche
8. ✅ PASS si servo suit les commandes

### Test 3 : Limites
1. Cliquer [→] de nombreuses fois
2. Angle doit **bloquer à +45.0°**
3. Cliquer [←] de nombreuses fois
4. Angle doit **bloquer à -45.0°**
5. ✅ PASS si limites respectées

### Test 4 : Auto-align
1. Activer Auto-align (switch ON)
2. Boutons [←] [→] doivent être **grisés** (alpha 0.4)
3. Cliquer sur les boutons → **aucune action**
4. Désactiver Auto-align (switch OFF)
5. Boutons redeviennent **actifs**
6. ✅ PASS si contrôle manuel bloqué quand auto-align activé

### Test 5 : Répétition automatique
1. **Maintenir** le bouton [→] enfoncé
2. Servo doit tourner **continuellement** vers la droite
3. Relâcher → servo **s'arrête**
4. ✅ PASS si répétition fonctionne

---

## 📝 NOTES TECHNIQUES

### Conversion d'Angle

Le servo standard SG90 accepte des valeurs **0 à 180°**, mais notre interface utilise **-45° à +45°**.

**Formule de conversion** :
```
servoValue = map(angle * 10, -450, 450, 0, 180)
```

**Exemples** :
- `-45.0°` → `0` (servo à fond à gauche)
- `0.0°` → `90` (servo centré)
- `+45.0°` → `180` (servo à fond à droite)

### Fréquence PWM

L'Arduino génère automatiquement le signal PWM à **50 Hz** (période 20ms) via la bibliothèque `Servo.h`.

**Largeur d'impulsion** :
- `0°` → ~1000 µs
- `90°` → ~1500 µs
- `180°` → ~2000 µs

### Courant Consommé

Un servo SG90 typique consomme :
- **Repos** : ~10 mA
- **Mouvement** : ~100-200 mA
- **Blocage** : jusqu'à 500 mA

**⚠️ Si l'Arduino redémarre lors du mouvement servo** :
→ Utiliser une **alimentation externe** pour le servo

---

## 🔧 DÉPANNAGE

### Problème : Servo ne bouge pas

**Vérifications** :
1. ✅ Servo branché sur **pin 9** (PWM)
2. ✅ Alimentation **5V** connectée
3. ✅ **GND commun** entre Arduino et servo
4. ✅ Code Arduino flashé avec la bibliothèque `Servo.h`
5. ✅ Commande reçue dans Serial Monitor : `→ Arduino: Servo XX.XX°`

---

### Problème : Servo tremble ou vibre

**Causes possibles** :
- Alimentation insuffisante (courant trop faible)
- Câble signal trop long ou mal blindé
- Interférences électromagnétiques

**Solutions** :
- Utiliser alimentation externe (1A minimum)
- Ajouter condensateur 100µF sur VCC/GND du servo
- Raccourcir le câble signal

---

### Problème : Servo dépasse les limites

**Vérification** :
- Code Arduino limite bien l'angle : `constrain(angle, -45, 45)`
- Code Android limite bien : `Math.max(-45, Math.min(45, newTilt))`

**Si problème persiste** :
- Vérifier le mapping dans `setServoAngle()` (doit être `map(-450, 450, 0, 180)`)

---

### Problème : Boutons ne répondent pas

**Vérifications** :
1. WebSocket connecté ? (voir page Config)
2. Auto-align désactivé ? (switch OFF)
3. Logs Android Studio : `sendServoCommand` appelé ?
4. Logs ESP32 Serial Monitor : `[WS] Servo tilt` reçu ?
5. Logs Arduino Serial Monitor : `→ Arduino: Servo` reçu ?

**Debug** :
```bash
# ESP32
→ Arduino: Servo 12.50°
✅ Arduino: Servo @ 12.50°

# Si pas de "→ Arduino:", WebSocket ne transmet pas
# Si pas de "✅ Arduino:", UART ne fonctionne pas
```

---

## ✅ CHECKLIST FINALE

- [x] Arduino : bibliothèque `Servo.h` installée
- [x] Arduino : servo branché sur pin 9
- [x] Arduino : code flashé avec `initServo()`
- [x] ESP32 : `sendArduinoServo()` implémenté
- [x] ESP32 : WebSocket handler servo implémenté
- [x] Android : ✅ Déjà fonctionnel (aucun changement)
- [x] Test : Servo bouge depuis l'app Android
- [x] Test : Limites -45° / +45° respectées
- [x] Test : Auto-align désactive les boutons

---

## 🎉 CONCLUSION

**Le contrôle servo est ENTIÈREMENT FONCTIONNEL !**

Tu peux maintenant :
- ✅ Guider le servo avec les boutons [←] [→]
- ✅ Voir l'angle en temps réel
- ✅ Auto-align bloque le contrôle manuel
- ✅ Servo limité à -45° / +45°

**Prochaine étape possible** : Implémenter l'auto-alignement automatique via TinyML/gyroscope

---

*Document généré le 2026-07-08*  
*FSOmni V3.0 - ESP-NOW + Laser Gate + Servo Control*
