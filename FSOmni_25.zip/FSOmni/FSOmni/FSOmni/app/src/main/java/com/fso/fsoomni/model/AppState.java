package com.fso.fsoomni.model;

import java.util.concurrent.CopyOnWriteArrayList;

public class AppState {

    private boolean connected = false;
    private String ip = "192.168.4.1";
    private double servoTilt = 14.22;
    private boolean tinymlEnabled = true;
    private boolean autoAlignEnabled = true;
    private double lastThroughput = 9.8;
    private double lastBer = 1.2e-9;
    private double lastRssi = -42;
    private double lastAlignmentPrecision = 90.0;
    private double lastLuminosity = 5000.0;       // Luminosité ambiante (lux)
    private double lastAttenuation = 0.4;          // Atténuation (dB/km)
    private double lastTemperature = 25.0;         // Température (°C)
    private double lastPressure = 1013.25;         // Pression (hPa)
    private double lastAltitude = 0.0;             // Altitude (m)
    private double lastAccelX = 0.0;               // Accélération X (g)
    private double lastAccelY = 0.0;               // Accélération Y (g)
    private double lastAccelZ = 1.0;               // Accélération Z (g)
    private double lastGyroX = 0.0;                // Gyroscope X (°/s)
    private double lastGyroY = 0.0;                // Gyroscope Y (°/s)
    private double lastGyroZ = 0.0;                // Gyroscope Z (°/s)
    private double lastVibration = 0.0;            // Niveau de vibration (0-100%)
    private double espTemp = 42.0;
    private double espEtat = 88.0;
    private String espUptime = "12j 04h 22m";
    private double lightIntensity = -18.4;

    // Channel status
    private String ch1Status = "ok";
    private String ch2Status = "ok";
    private String ch3Status = "ok";

    // ÉTAPE 2 : Numéro de l'unité (0 = non configuré)
    private int myUnitId = 0;

    // Bar chart data
    private int[] barValues = {65, 72, 58, 80, 92, 85, 70, 95, 88, 78, 90, 98};

    // Callback for state changes - supports multiple listeners
    public interface OnStateChangeListener {
        void onStateChanged(String key, Object value);
    }

    private final CopyOnWriteArrayList<OnStateChangeListener> listeners = new CopyOnWriteArrayList<>();

    public void addOnStateChangeListener(OnStateChangeListener listener) {
        if (listener != null && !listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public void removeOnStateChangeListener(OnStateChangeListener listener) {
        listeners.remove(listener);
    }

    private void notifyChange(String key, Object value) {
        for (OnStateChangeListener l : listeners) {
            l.onStateChanged(key, value);
        }
    }

    public boolean isConnected() {
        return connected;
    }

    public void setConnected(boolean connected) {
        this.connected = connected;
        notifyChange("connected", connected);
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public double getServoTilt() {
        return servoTilt;
    }

    public void setServoTilt(double servoTilt) {
        this.servoTilt = servoTilt;
        notifyChange("servoTilt", servoTilt);
    }

    public boolean isTinymlEnabled() {
        return tinymlEnabled;
    }

    public void setTinymlEnabled(boolean tinymlEnabled) {
        this.tinymlEnabled = tinymlEnabled;
        notifyChange("tinymlEnabled", tinymlEnabled);
    }

    public boolean isAutoAlignEnabled() {
        return autoAlignEnabled;
    }

    public void setAutoAlignEnabled(boolean autoAlignEnabled) {
        this.autoAlignEnabled = autoAlignEnabled;
        notifyChange("autoAlignEnabled", autoAlignEnabled);
    }

    public double getLastThroughput() {
        return lastThroughput;
    }

    public void setLastThroughput(double lastThroughput) {
        this.lastThroughput = lastThroughput;
        notifyChange("throughput", lastThroughput);
    }

    public double getLastBer() {
        return lastBer;
    }

    public void setLastBer(double lastBer) {
        this.lastBer = lastBer;
        notifyChange("ber", lastBer);
    }

    public double getLastRssi() {
        return lastRssi;
    }

    public void setLastRssi(double lastRssi) {
        this.lastRssi = lastRssi;
        notifyChange("rssi", lastRssi);
    }

    public double getLastAlignmentPrecision() {
        return lastAlignmentPrecision;
    }

    public void setLastAlignmentPrecision(double lastAlignmentPrecision) {
        this.lastAlignmentPrecision = lastAlignmentPrecision;
        notifyChange("alignmentPrecision", lastAlignmentPrecision);
    }

    public double getLastLuminosity() {
        return lastLuminosity;
    }

    public void setLastLuminosity(double lastLuminosity) {
        this.lastLuminosity = lastLuminosity;
        notifyChange("luminosity", lastLuminosity);
    }

    public double getLastAttenuation() {
        return lastAttenuation;
    }

    public void setLastAttenuation(double lastAttenuation) {
        this.lastAttenuation = lastAttenuation;
        notifyChange("attenuation", lastAttenuation);
    }

    public double getLastTemperature() {
        return lastTemperature;
    }

    public void setLastTemperature(double lastTemperature) {
        this.lastTemperature = lastTemperature;
        notifyChange("temperature", lastTemperature);
    }

    public double getLastPressure() {
        return lastPressure;
    }

    public void setLastPressure(double lastPressure) {
        this.lastPressure = lastPressure;
        notifyChange("pressure", lastPressure);
    }

    public double getLastAltitude() {
        return lastAltitude;
    }

    public void setLastAltitude(double lastAltitude) {
        this.lastAltitude = lastAltitude;
        notifyChange("altitude", lastAltitude);
    }

    public double getLastAccelX() {
        return lastAccelX;
    }

    public void setLastAccelX(double lastAccelX) {
        this.lastAccelX = lastAccelX;
        notifyChange("accelX", lastAccelX);
    }

    public double getLastAccelY() {
        return lastAccelY;
    }

    public void setLastAccelY(double lastAccelY) {
        this.lastAccelY = lastAccelY;
        notifyChange("accelY", lastAccelY);
    }

    public double getLastAccelZ() {
        return lastAccelZ;
    }

    public void setLastAccelZ(double lastAccelZ) {
        this.lastAccelZ = lastAccelZ;
        notifyChange("accelZ", lastAccelZ);
    }

    public double getLastGyroX() {
        return lastGyroX;
    }

    public void setLastGyroX(double lastGyroX) {
        this.lastGyroX = lastGyroX;
        notifyChange("gyroX", lastGyroX);
    }

    public double getLastGyroY() {
        return lastGyroY;
    }

    public void setLastGyroY(double lastGyroY) {
        this.lastGyroY = lastGyroY;
        notifyChange("gyroY", lastGyroY);
    }

    public double getLastGyroZ() {
        return lastGyroZ;
    }

    public void setLastGyroZ(double lastGyroZ) {
        this.lastGyroZ = lastGyroZ;
        notifyChange("gyroZ", lastGyroZ);
    }

    public double getLastVibration() {
        return lastVibration;
    }

    public void setLastVibration(double lastVibration) {
        this.lastVibration = lastVibration;
        notifyChange("vibration", lastVibration);
    }

    public double getEspTemp() {
        return espTemp;
    }

    public void setEspTemp(double espTemp) {
        this.espTemp = espTemp;
        notifyChange("espTemp", espTemp);
    }

    public double getEspEtat() {
        return espEtat;
    }

    public void setEspEtat(double espEtat) {
        this.espEtat = espEtat;
        notifyChange("espEtat", espEtat);
    }

    public String getEspUptime() {
        return espUptime;
    }

    public void setEspUptime(String espUptime) {
        this.espUptime = espUptime;
        notifyChange("espUptime", espUptime);
    }

    public double getLightIntensity() {
        return lightIntensity;
    }

    public void setLightIntensity(double lightIntensity) {
        this.lightIntensity = lightIntensity;
        notifyChange("lightIntensity", lightIntensity);
    }

    public String getCh1Status() {
        return ch1Status;
    }

    public void setCh1Status(String ch1Status) {
        this.ch1Status = ch1Status;
    }

    public String getCh2Status() {
        return ch2Status;
    }

    public void setCh2Status(String ch2Status) {
        this.ch2Status = ch2Status;
    }

    public String getCh3Status() {
        return ch3Status;
    }

    public void setCh3Status(String ch3Status) {
        this.ch3Status = ch3Status;
    }

    public int[] getBarValues() {
        return barValues;
    }

    public void pushBarValue(int newValue) {
        // Shift all values left
        System.arraycopy(barValues, 1, barValues, 0, barValues.length - 1);
        barValues[barValues.length - 1] = newValue;
        notifyChange("barValues", barValues);
    }

    // ================================================================
    // ÉTAPE 2 : Gestion du numéro d'unité
    // ================================================================

    public int getMyUnitId() {
        return myUnitId;
    }

    public void setMyUnitId(int myUnitId) {
        this.myUnitId = myUnitId;
        notifyChange("myUnitId", myUnitId);
    }

    public boolean isUnitIdConfigured() {
        return myUnitId > 0;
    }
}
