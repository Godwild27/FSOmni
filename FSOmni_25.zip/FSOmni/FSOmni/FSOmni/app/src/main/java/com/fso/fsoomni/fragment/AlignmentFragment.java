package com.fso.fsoomni.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.fso.fsoomni.R;
import com.fso.fsoomni.model.AppState;
import com.fso.fsoomni.view.ToggleSwitchView;
import com.fso.fsoomni.websocket.FSOWebSocketClient;

public class AlignmentFragment extends Fragment {

    private AppState appState;
    private FSOWebSocketClient wsClient;
    private Handler handler = new Handler(Looper.getMainLooper());

    private ToggleSwitchView toggleAutoAlign;
    private TextView servoXValue;
    private TextView alignBerValue;
    private View alignBerProgress;
    private TextView lightIntensityValue;
    private View lightIntensityProgress;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() != null) {
            appState = ((com.fso.fsoomni.activity.MainActivity) getActivity()).getAppState();
            wsClient = ((com.fso.fsoomni.activity.MainActivity) getActivity()).getWsClient();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_alignment, container, false);

        toggleAutoAlign = view.findViewById(R.id.toggle_auto_align);
        servoXValue = view.findViewById(R.id.servo_x_value);
        alignBerValue = view.findViewById(R.id.align_ber_value);
        alignBerProgress = view.findViewById(R.id.align_ber_progress);
        lightIntensityValue = view.findViewById(R.id.light_intensity_value);
        lightIntensityProgress = view.findViewById(R.id.light_intensity_progress);

        // Initialize toggle
        if (appState != null) {
            toggleAutoAlign.setChecked(appState.isAutoAlignEnabled());
        }

        // Toggle listener
        toggleAutoAlign.setOnCheckedChangeListener(isChecked -> {
            if (appState != null) {
                appState.setAutoAlignEnabled(isChecked);
            }
            if (wsClient != null) {
                wsClient.sendAutoAlignCommand(isChecked);
            }
        });

        // Servo left
        ImageButton btnLeft = view.findViewById(R.id.btn_servo_left);
        btnLeft.setOnClickListener(v -> moveServo(-0.5));

        btnLeft.setOnTouchListener(new View.OnTouchListener() {
            private Handler repeatHandler = new Handler(Looper.getMainLooper());
            private Runnable repeatRunnable;

            @Override
            public boolean onTouch(View v, android.view.MotionEvent event) {
                if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                    v.setAlpha(0.7f);
                    repeatRunnable = () -> moveServo(-0.5);
                    repeatHandler.postDelayed(repeatRunnable, 200);
                    return true;
                } else if (event.getAction() == android.view.MotionEvent.ACTION_UP) {
                    v.setAlpha(1.0f);
                    if (repeatRunnable != null) repeatHandler.removeCallbacks(repeatRunnable);
                    return true;
                } else if (event.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
                    v.setAlpha(1.0f);
                    if (repeatRunnable != null) repeatHandler.removeCallbacks(repeatRunnable);
                    return true;
                }
                return false;
            }
        });

        // Servo right
        ImageButton btnRight = view.findViewById(R.id.btn_servo_right);
        btnRight.setOnClickListener(v -> moveServo(0.5));

        btnRight.setOnTouchListener(new View.OnTouchListener() {
            private Handler repeatHandler = new Handler(Looper.getMainLooper());
            private Runnable repeatRunnable;

            @Override
            public boolean onTouch(View v, android.view.MotionEvent event) {
                if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                    v.setAlpha(0.7f);
                    repeatRunnable = () -> moveServo(0.5);
                    repeatHandler.postDelayed(repeatRunnable, 200);
                    return true;
                } else if (event.getAction() == android.view.MotionEvent.ACTION_UP) {
                    v.setAlpha(1.0f);
                    if (repeatRunnable != null) repeatHandler.removeCallbacks(repeatRunnable);
                    return true;
                } else if (event.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
                    v.setAlpha(1.0f);
                    if (repeatRunnable != null) repeatHandler.removeCallbacks(repeatRunnable);
                    return true;
                }
                return false;
            }
        });

        // State listener
        if (appState != null) {
            appState.addOnStateChangeListener((key, value) -> handler.post(() -> {
                if ("servoTilt".equals(key)) {
                    servoXValue.setText(String.format("%.2f°", (Double) value));
                }
                if ("ber".equals(key)) {
                    double ber = (Double) value;
                    alignBerValue.setText(String.format("%.0e", ber).replace("e-0", "⁻"));
                }
                if ("lightIntensity".equals(key)) {
                    double intensity = (Double) value;
                    lightIntensityValue.setText(String.format("%.1f dBm", intensity));
                    int progress = (int) Math.max(0, Math.min(100, ((intensity + 50) / 50.0) * 100));
                    View parent = (View) lightIntensityProgress.getParent();
                    if (parent.getWidth() > 0) {
                        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) lightIntensityProgress.getLayoutParams();
                        params.width = (int) (progress / 100f * parent.getWidth());
                        lightIntensityProgress.setLayoutParams(params);
                    }
                }
            }));
        }

        return view;
    }

    private void moveServo(double delta) {
        if (appState == null) return;

        double newTilt = appState.getServoTilt() + delta;
        newTilt = Math.max(-45, Math.min(45, newTilt));
        appState.setServoTilt(newTilt);
        servoXValue.setText(String.format("%.2f°", newTilt));

        if (wsClient != null) {
            wsClient.sendServoCommand("tilt", newTilt);
        }
    }
}
