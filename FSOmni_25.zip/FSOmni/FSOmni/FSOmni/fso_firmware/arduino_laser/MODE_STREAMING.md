# 🚀 Mode Streaming Pur - Arduino Laser Controller

## 📐 Architecture du Système

```
┌─────────────────────────────────────────────────────────────────┐
│                     ESP32-S3 N16R8 (16MB RAM)                   │
│  • WiFi / WebSocket                                             │
│  • Capteurs I2C (BMP280, MPU6050, BH1750)                       │
│  • Bufferisation fichiers/vocal                                 │
│  • Fragmentation en chunks 100 octets                           │
│  • Flow control (attend tx_done avant chunk suivant)            │
└──────────────────────┬──────────────────────────────────────────┘
                       │ Serial 115200 baud
                       │ JSON: {"cmd":"tx","text":"chunk1"}
                       ↓
┌─────────────────────────────────────────────────────────────────┐
│                 Arduino Uno (2KB RAM) - PASSTHROUGH             │
│  • Reçoit chunk ESP32                                           │
│  • Transmet IMMÉDIATEMENT par laser OOK                         │
│  • Renvoie {"evt":"tx_done"} → ESP32                            │
│  • PAS de bufferisation                                         │
│  • PAS de queue                                                 │
│  • Mode streaming pur                                           │
└──────────────────────┬──────────────────────────────────────────┘
                       │ Laser OOK 3 canaux (600 bits/s)
                       ↓
                   🔦 LASER TX/RX
```

---

## 🔄 Protocole Streaming ESP32 ↔ Arduino

### 1. ESP32 → Arduino (Transmission)

**Commande TX** :
```json
{"cmd":"tx","text":"Hello World","unit":1}
```

**Réponses Arduino** :
```json
{"evt":"tx_started"}          // Transmission laser démarrée
{"evt":"tx_done"}             // Transmission terminée → ESP32 peut envoyer le chunk suivant
{"evt":"error","msg":"TX busy - wait for tx_done"}  // TX occupé → ESP32 doit attendre
```

### 2. Arduino → ESP32 (Réception)

**Message RX reçu par laser** :
```json
{"evt":"rx","text":"Hello World","unit":1}
```

### 3. Commandes de Contrôle

**Ping** :
```json
{"cmd":"ping"}
```
**Réponse** :
```json
{"evt":"pong","free_ram":1200,"tx_busy":0,"tx_ready":1}
```

**Status** :
```json
{"cmd":"status"}
```
**Réponse** :
```json
{"evt":"status","tx_busy":0,"tx_ready":1,"free_ram":1200,"uptime":3600}
```

---

## 📊 Flow Control

### Transmission de Fichier (Exemple 10 KB)

```
ESP32 : {"cmd":"tx","text":"chunk_001","seq":1}
         ↓
Arduino: {"evt":"tx_started"}
         [Transmission laser en cours...]
Arduino: {"evt":"tx_done","seq":1}
         ↓
ESP32 : {"cmd":"tx","text":"chunk_002","seq":2}
         ↓
Arduino: {"evt":"tx_started"}
         [Transmission laser en cours...]
Arduino: {"evt":"tx_done","seq":2}
         ↓
ESP32 : {"cmd":"tx","text":"chunk_003","seq":3}
         ...
```

**Règles** :
- ✅ ESP32 **DOIT** attendre `{"evt":"tx_done"}` avant d'envoyer le chunk suivant
- ✅ Si ESP32 envoie trop vite → Arduino répond `{"evt":"error","msg":"TX busy"}`
- ✅ Arduino transmet **immédiatement** sans bufferiser
- ✅ Pas de limite de taille totale du fichier (géré par ESP32)

---

## 💾 Consommation RAM Arduino Uno

### Avant (avec queue TX)
```
MAX_FRAME_SIZE      : 4096 × 2 = 8192 octets (TX + RX buffers)
TX_QUEUE            : 8 × 512 = 4096 octets
StaticJsonDocument  : ~2000 octets
TOTAL               : ~14000 octets → 643% de RAM (IMPOSSIBLE)
```

### Après (mode streaming)
```
MAX_FRAME_SIZE      : 128 × 2 = 256 octets (TX + RX buffers)
TX_QUEUE            : SUPPRIMÉ = 0 octets
StaticJsonDocument  : ~400 octets (réduit)
Variables globales  : ~300 octets
TOTAL               : ~950 octets → 46% de RAM ✅
```

**Économie : ~13 KB de RAM !**

---

## ⚙️ Limitations Techniques

### 1. Taille des Chunks
- **Maximum 100 octets** par chunk (données utiles)
- **MAX_FRAME_SIZE = 128 octets** (avec overhead protocole OOK)
- Solution : ESP32 fragmente automatiquement

### 2. Débit Laser
- **600 bits/s théorique** (3 canaux × 200 bits/s)
- **~75 octets/seconde effectif** (avec overhead protocole)
- **1 chunk 100 octets ≈ 1.3 secondes** de transmission

### 3. Latence
- **Cooldown TX→RX : 1 seconde** (évite bruit résiduel)
- **Temps chunk→chunk : ~2.5 secondes** (1.3s TX + 1s cooldown + 0.2s processing)
- **Fichier 10 KB ≈ 4 minutes** (100 chunks × 2.5s)

### 4. Messages JSON
- **Maximum ~100 caractères** par commande JSON
- `{"cmd":"tx","text":"...(max 80 chars)...","unit":1}` ✅

---

## 🎯 Cas d'Usage

### ✅ Messages Courts (Streaming Direct)
```json
ESP32 → {"cmd":"tx","text":"ALIGN"}
Arduino → {"evt":"tx_started"}
         [Transmission laser 0.5s]
Arduino → {"evt":"tx_done"}
```

### ✅ Messages Longs (Fragmentation Automatique)
```
Message original : "Lorem ipsum dolor sit amet..." (500 caractères)

ESP32 fragmente automatiquement :
  Chunk 1 : "Lorem ipsum dolor sit amet, consectetur adipiscing elit..."
  Chunk 2 : "Sed do eiusmod tempor incididunt ut labore et dolore..."
  Chunk 3 : "magna aliqua. Ut enim ad minim veniam, quis nostrud..."
  ...
  Chunk 6 : "exercitation ullamco laboris nisi ut aliquip ex ea."

Chaque chunk envoyé après réception de tx_done du précédent.
```

### ✅ Fichiers (Streaming par Chunks)
```
Fichier 1 MB → 10000 chunks de 100 octets
ESP32 lit le fichier chunk par chunk
Envoie au fur et à mesure
Arduino transmet en temps réel
Récepteur réassemble côté ESP32
```

### ✅ Audio (Streaming Temps Réel)
```
Microphone ESP32 → Buffer 100 octets → Arduino → Laser
Débit requis : 8 kHz × 8 bits = 8000 octets/s
Débit laser : ~75 octets/s
LIMITATION : Audio très compressé uniquement (ADPCM 4-bit ≈ 4000 octets/s)
```

---

## 🚨 Gestion d'Erreurs

### Erreur : TX Busy
```json
ESP32 → {"cmd":"tx","text":"chunk_002"}
Arduino → {"evt":"error","msg":"TX busy - wait for tx_done"}
```
**Action ESP32** : Réessayer après 100ms

### Erreur : Message Trop Long
```json
ESP32 → {"cmd":"tx","text":"(150 caractères...)"}
Arduino → {"evt":"error","msg":"Message too long"}
```
**Action ESP32** : Fragmenter en chunks plus petits

### Erreur : Perte de Synchronisation
```
RX détecte trame corrompue
Arduino → {"evt":"error","msg":"Frame corrupted"}
```
**Action ESP32** : Renvoyer le chunk avec même seq

---

## 📈 Performances Réelles

### Test 1 : Message Court
```
Message : "HELLO" (5 octets)
Temps TX : ~0.5 seconde
Cooldown : 1 seconde
Total : 1.5 secondes
```

### Test 2 : Message 100 Octets
```
Message : 100 caractères
Temps TX : ~1.3 secondes
Cooldown : 1 seconde
Total : 2.3 secondes
```

### Test 3 : Fichier 10 KB
```
Chunks : 100 × 100 octets
Temps par chunk : 2.3 secondes
Total : 230 secondes (3m50s)
```

### Test 4 : Fichier 1 MB
```
Chunks : 10000 × 100 octets
Temps estimé : 23000 secondes (6h24m)
```

---

## 🔧 Configuration ESP32

### Code ESP32 (exemple simplifié)

```cpp
// Envoyer un fichier par streaming
void sendFileStreaming(File file) {
  uint8_t buffer[100];
  uint32_t seq = 0;
  
  while (file.available()) {
    // Lire 100 octets
    size_t len = file.read(buffer, 100);
    
    // Créer commande JSON
    StaticJsonDocument<256> doc;
    doc["cmd"] = "tx";
    doc["text"] = base64_encode(buffer, len);
    doc["seq"] = seq++;
    
    // Envoyer à l'Arduino
    serializeJson(doc, Serial2);
    Serial2.println();
    
    // ATTENDRE tx_done
    bool done = false;
    while (!done) {
      if (Serial2.available()) {
        String response = Serial2.readStringUntil('\n');
        StaticJsonDocument<128> resp;
        deserializeJson(resp, response);
        
        if (resp["evt"] == "tx_done") {
          done = true;
        }
      }
      delay(10);
    }
  }
  
  Serial.println("File transmission complete!");
}
```

---

## ✅ Avantages du Mode Streaming

1. **RAM optimisée** : Utilise seulement 46% de la RAM Arduino (au lieu de 643%)
2. **Scalabilité infinie** : Pas de limite de taille de fichier (géré par ESP32)
3. **Flow control natif** : ESP32 contrôle le débit via tx_done
4. **Simplicité** : Arduino est un simple passthrough
5. **Fiabilité** : Pas de risque de débordement de queue

---

## ⚠️ Inconvénients

1. **Latence élevée** : 2.3s par chunk (acceptable pour FSO longue distance)
2. **Audio limité** : Nécessite compression forte
3. **Débit faible** : ~75 octets/s (mais suffisant pour FSO)
4. **Dépendance ESP32** : Toute la logique est côté ESP32

---

**Conclusion** : Le mode streaming pur est **optimal** pour un système FSO avec Arduino Uno (2KB RAM) + ESP32-S3 (16MB RAM). L'Arduino gère uniquement la modulation laser temps réel, et l'ESP32 gère toute la bufferisation et la logique de fragmentation.
