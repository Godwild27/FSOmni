// ================================================================
// laser_config.h — Configuration Laser OOK
// ================================================================
// Définit tous les paramètres hardware et protocole pour la
// communication laser OOK (On-Off Keying) sur 3 canaux parallèles.
// 
// ⚠️ HARDWARE: Arduino Uno (ATmega328P)
// ================================================================

#ifndef LASER_CONFIG_H
#define LASER_CONFIG_H

// ================================================================
// CONFIGURATION GPIO — ARDUINO UNO PINS
// ================================================================
// TX Laser (sortie vers LED laser)
#define TX1_PIN 2    // Digital Pin 2 — laser TX canal 1
#define TX2_PIN 3    // Digital Pin 3 — laser TX canal 2
#define TX3_PIN 4    // Digital Pin 4 — laser TX canal 3

// RX Laser (entrée depuis photodiode)
#define RX1_PIN 5    // Digital Pin 5 — photodiode RX canal 1
#define RX2_PIN 6    // Digital Pin 6 — photodiode RX canal 2
#define RX3_PIN 7    // Digital Pin 7 — photodiode RX canal 3

// ================================================================
// PARAMÈTRES DE COMMUNICATION — STREAMING PUR (Arduino Uno)
// ================================================================
#define BIT_DURATION_US     5000    // 5ms par bit = 200 bits/s par canal
#define NUM_CHANNELS        3       // 3 canaux en parallèle = 600 bits/s total
#define MAX_FRAME_SIZE      128     // Taille max d'un chunk streaming (octets)

// ================================================================
// PROTOCOLE OOK — STRUCTURE DE TRAME
// ================================================================
#define PREAMBLE_PATTERN    0xAA    // Pattern de synchronisation
#define PREAMBLE_LENGTH     8       // Nombre d'octets de préambule
#define SYNC_WORD           0x7E    // Mot de synchronisation
#define FRAME_HEADER        0x02    // Début de trame (STX)
#define FRAME_FOOTER        0x03    // Fin de trame (ETX)
#define ESCAPE_BYTE         0x1B    // Caractère d'échappement (ESC)

// ================================================================
// COOLDOWN TX → RX
// ================================================================
// Temps d'attente (ms) entre fin TX et réactivation RX
// Évite que le RX capte du bruit résiduel juste après la fin du laser
#define TX_RX_COOLDOWN_MS   1000

// ================================================================
// MODE STREAMING PUR
// ================================================================
// ⚠️ PAS DE QUEUE TX : L'Arduino transmet immédiatement les chunks
// L'ESP32 gère la bufferisation, fragmentation et flow control
// Architecture : ESP32 (16MB RAM) ↔ Serial ↔ Arduino (passthrough) ↔ Laser

// ================================================================
// NOTES TECHNIQUES
// ================================================================
// • Modulation OOK : HIGH = laser ON (bit 1), LOW = laser OFF (bit 0)
// • Pas de PWM : digitalWrite() direct pour ISR-safe
// • Timer hardware : 200 Hz (5ms par bit) - Timer1 sur Arduino Uno
// • Débit total : 200 bits/s × 3 canaux = 600 bits/s
// • Arduino Uno : ATmega328P @ 16MHz, 2KB RAM
// • Mode streaming : Pas de bufferisation côté Arduino
// • Flow control : Arduino envoie "ready" quand disponible

#endif
