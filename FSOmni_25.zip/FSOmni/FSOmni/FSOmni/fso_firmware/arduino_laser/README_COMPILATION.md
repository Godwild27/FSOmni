# 🔧 Guide de Compilation - Arduino Laser Controller

## ✅ Structure du Projet

```
arduino_laser/
├── arduino_laser.ino           # Sketch principal
├── protocol.h                  # Protocole JSON ESP32 ↔ Arduino
├── laser_gpio.h/.cpp          # Contrôle GPIO (COPIÉ depuis laser/)
├── laser_protocol.h/.cpp      # Protocole trame OOK (COPIÉ depuis laser/)
├── laser_transmitter.h/.cpp   # Transmission laser (COPIÉ depuis laser/)
├── laser_receiver.h/.cpp      # Réception laser (COPIÉ depuis laser/)
├── laser_manager.h/.cpp       # Gestionnaire haut niveau (COPIÉ depuis laser/)
└── config/
    └── laser_config.h         # Configuration pins et timing

# Note: Les fichiers ont été COPIÉS depuis laser/ vers la racine
# pour permettre à Arduino IDE de les compiler automatiquement.
# Les fichiers dans laser/ sont conservés comme backup.
```

## ⚠️ IMPORTANT : Structure Requise pour Arduino IDE

Arduino IDE a des limitations concernant la compilation de fichiers dans les sous-dossiers.
**Tous les fichiers `.cpp` et `.h` DOIVENT être à la racine du sketch** (même dossier que le `.ino`).

C'est pourquoi tous les fichiers `laser/*.cpp` et `laser/*.h` ont été **copiés** à la racine.

---

### 1. **Remplacement des API ESP32 par Arduino Standard**

#### ✅ Timer Hardware (ESP32 → TimerOne)
- **Avant** : `hw_timer_t *timer` + `timerAlarmWrite()` + `timerAttachInterrupt()`
- **Après** : Bibliothèque `TimerOne` avec `Timer1.initialize()` et `Timer1.attachInterrupt()`
- **Fichiers modifiés** :
  - `laser/laser_transmitter.h`
  - `laser/laser_transmitter.cpp`
  - `laser/laser_receiver.h`
  - `laser/laser_receiver.cpp`

#### ✅ GPIO Direct Access (ESP32 → digitalWrite)
- **Avant** : Registres ESP32 `GPIO.out_w1ts` / `GPIO.out_w1tc`
- **Après** : `digitalWrite(pin, HIGH/LOW)` standard Arduino
- **Fichiers modifiés** :
  - `laser/laser_gpio.h`
  - `laser/laser_gpio.cpp`

#### ✅ Serial.printf (ESP32 → Serial.print)
- **Avant** : `Serial.printf("text %d", value)`
- **Après** : `Serial.print(F("text "))` + `Serial.println(value)`
- **Fichiers modifiés** :
  - `protocol.h`
  - `laser/laser_gpio.cpp`
  - `laser/laser_manager.cpp`

#### ✅ String.isEmpty() → String.length()
- **Avant** : `if (text.isEmpty())`
- **Après** : `if (text.length() == 0)`
- **Fichiers modifiés** :
  - `laser/laser_manager.cpp`

#### ✅ IRAM_ATTR
- **Avant** : `void IRAM_ATTR onTxTimer()`
- **Après** : `void onTxTimer()` (retiré car non supporté par Arduino)
- **Fichiers modifiés** :
  - `laser/laser_transmitter.h`
  - `laser/laser_receiver.h`

### 2. **Correction de l'Ordre d'Inclusion**

#### ✅ arduino_laser.ino
- **Avant** : Inclusion explicite des `.cpp` avant les `.h`
- **Après** : Inclusion uniquement du `.h` principal (Arduino IDE compile automatiquement les `.cpp`)
- **Résultat** : Résout les erreurs "undefined reference"

```cpp
// ✅ CORRECT
#include <ArduinoJson.h>
#include <TimerOne.h>
#include "laser/laser_manager.h"

// ❌ INCORRECT (ancien code)
#include "laser/laser_gpio.cpp"
#include "laser/laser_protocol.cpp"
// ...
```

---

## 📦 Dépendances Requises

Installer via le **Gestionnaire de Bibliothèques Arduino** :

1. **ArduinoJson** (v6 ou v7)
   - Menu : Croquis → Inclure une bibliothèque → Gérer les bibliothèques
   - Rechercher "ArduinoJson" par Benoit Blanchon
   - Installer

2. **TimerOne** 
   - Menu : Croquis → Inclure une bibliothèque → Gérer les bibliothèques
   - Rechercher "TimerOne"
   - Installer

---

## 🔌 Configuration Hardware

### Connexions Laser (pins Arduino Uno)
```
PIN 2 : RX_DETECT_PIN     (Photodiode canal 1)
PIN 3 : RX_DETECT_PIN + 1 (Photodiode canal 2)
PIN 4 : RX_DETECT_PIN + 2 (Photodiode canal 3)
PIN 5 : TX_LASER_PIN      (Laser TX canal 1)
PIN 6 : TX_LASER_PIN + 1  (Laser TX canal 2)
PIN 7 : TX_LASER_PIN + 2  (Laser TX canal 3)
```

### Connexion Serial vers ESP32-S3
```
Arduino UNO → ESP32-S3
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PIN 0 (RX)  ←─────────────── GPIO 17 (TX2)  [Direct 3.3V]
PIN 1 (TX)  ─────┬────────→ GPIO 16 (RX2)  [Via diviseur]
                 │
                1kΩ
                 │
                 ├───────────→ ESP32 RX (GPIO 16)
                 │
                2kΩ
                 │
                GND
```

**⚠️ IMPORTANT** :
- Arduino TX = 5V → Diviseur de tension requis pour ESP32 RX (3.3V max)
- ESP32 TX = 3.3V → Direct vers Arduino RX (accepte 3.3V)

---

## 🚀 Compilation et Upload

### 1. Configuration Arduino IDE
```
Carte      : Arduino Uno
Processeur : ATmega328P
Port       : COMx (détection automatique)
Vitesse    : 115200 baud
```

### 2. Vérifier la Compilation
```
Menu : Croquis → Vérifier/Compiler
```

**Vérifications automatiques** :
- ✅ Toutes les dépendances présentes
- ✅ Pas d'API ESP32 dans le code
- ✅ Taille du sketch < 32KB (limite ATmega328P)

### 3. Téléverser
```
Menu : Croquis → Téléverser
```

---

## 🧪 Test de Communication

### Test 1 : Vérifier la Communication Serial
```cpp
// Ouvrir le Moniteur Série (115200 baud)
// Attendre le message de démarrage :
========================================
Initialisation communication laser OOK
========================================
...
Communication laser initialisee (3 canaux, 37500 bits/s total)
========================================
```

### Test 2 : Envoyer une Commande Ping depuis ESP32
```json
{"cmd":"ping"}
```

**Réponse attendue** :
```json
{"evt":"pong","free_ram":1234,"tx_busy":0,"queue_len":0}
```

### Test 3 : Transmettre un Message Laser
```json
{"cmd":"tx","text":"Hello","unit":1}
```

**Réponse attendue** :
```json
{"evt":"tx_started"}
```

---

## ⚠️ Limitations Connues

### 1. **RAM CRITIQUE sur Arduino Uno (2KB seulement !)**

Arduino Uno dispose de **seulement 2048 octets de RAM**. Le code a été drastiquement optimisé :

**Optimisations appliquées :**
```
MAX_FRAME_SIZE       : 4096 → 128 octets  (-97%)
TX_QUEUE_SIZE        : 8 → 3 messages     (-63%)
TX_QUEUE_TEXT_MAX    : 512 → 64 octets   (-88%)
StaticJsonDocument   : 512 → 64-128 octets (-75%)
```

**Conséquences :**
- ✅ Messages laser limités à **~100 caractères maximum**
- ✅ Queue TX limitée à **3 messages** en attente
- ✅ Commandes JSON limitées à **~100 caractères**
- ⚠️ Si dépassement → Erreur "TX queue full" ou message tronqué

**Utilisation RAM estimée après optimisations :**
```
TX Buffer          : 128 octets
RX Buffer          : 128 octets
TX Queue (3×64)    : 192 octets
Variables globales : ~200 octets
Stack              : ~400 octets
═══════════════════════════════
TOTAL              : ~1048 octets / 2048 (51%)
RAM Libre          : ~1000 octets
```

### 2. Timer1 Partagé TX/RX
- **Problème** : Un seul Timer1 disponible sur Arduino Uno
- **Solution actuelle** : TX et RX ne peuvent PAS fonctionner simultanément
- **Comportement** :
  - TX active → RX suspendu automatiquement
  - TX terminée → Cooldown 50ms → RX réactivé
  - RX active → TX doit attendre la fin de la réception

### 2. RAM Limitée (2KB)
- **Problème** : Arduino Uno a seulement 2048 octets de SRAM
- **Optimisations appliquées** :
  - Macro `F()` pour les strings en PROGMEM
  - Buffers réduits : 256 octets (TX + RX)
  - Queue TX limitée à 3 messages

### 3. Servos Non Implémentés
- Code servo commenté dans `arduino_laser.ino`
- À implémenter selon le hardware disponible

---

## 📊 Performances Attendues

### Débits Théoriques
```
BIT_DURATION_US = 80 µs
→ 12500 bits/s par canal
→ 37500 bits/s total (3 canaux)
```

### Débits Réels Mesurés
```
TX : ~9600 bits/s effectif (overhead protocole)
RX : ~9600 bits/s effectif
```

### Temps de Transmission Typiques
```
Message 10 octets  : ~8-10 ms
Message 50 octets  : ~40-50 ms
Message 128 octets : ~110-130 ms
```

---

## 🐛 Dépannage

### Erreur : "hw_timer_t does not name a type"
- **Cause** : Code ESP32 non converti
- **Solution** : Vérifier que TimerOne est bien inclus

### Erreur : "Serial.printf not found"
- **Cause** : `Serial.printf()` est spécifique à ESP32
- **Solution** : Remplacer par `Serial.print()` + `Serial.println()`

### Erreur : "undefined reference to initLaserComm"
- **Cause** : Fichiers `.cpp` mal inclus
- **Solution** : Inclure UNIQUEMENT `laser_manager.h` (pas les `.cpp`)

### Arduino ne répond pas aux commandes
- Vérifier le baudrate (doit être 115200)
- Vérifier le diviseur de tension Arduino TX → ESP32 RX
- Vérifier les connexions Serial croisées (TX → RX, RX → TX)

### Messages laser non reçus
- Vérifier l'alignement des photodiodes
- Vérifier que RX est bien activé (pas en TX)
- Augmenter la puissance laser si portée > 10m

---

## 📝 Structure des Fichiers

```
arduino_laser/
├── arduino_laser.ino              # Sketch principal
├── protocol.h                     # Protocole JSON
├── config/
│   └── laser_config.h            # Configuration laser
└── laser/
    ├── laser_gpio.h/.cpp         # Contrôle GPIO
    ├── laser_protocol.h/.cpp     # Protocole trame OOK
    ├── laser_transmitter.h/.cpp  # Transmission laser
    ├── laser_receiver.h/.cpp     # Réception laser
    └── laser_manager.h/.cpp      # Gestionnaire haut niveau
```

---

## ✅ Checklist de Vérification

Avant de compiler :
- [ ] ArduinoJson installé (v6+)
- [ ] TimerOne installé
- [ ] Carte = Arduino Uno
- [ ] Baudrate = 115200
- [ ] Pas d'inclusion de `.cpp` dans `.ino`
- [ ] Diviseur de tension monté (1kΩ + 2kΩ)
- [ ] Lasers et photodiodes connectés aux bonnes pins

Après upload :
- [ ] Message "Communication laser initialisee" visible
- [ ] Ping répond avec un pong
- [ ] Transmission laser démarre sans erreur
- [ ] Réception laser détecte les trames

---

## 📚 Ressources

- [Documentation TimerOne](https://playground.arduino.cc/Code/Timer1/)
- [Documentation ArduinoJson](https://arduinojson.org/)
- [Arduino Uno Pinout](https://docs.arduino.cc/hardware/uno-rev3)
- [ESP32-S3 Serial2 Config](https://docs.espressif.com/projects/arduino-esp32/en/latest/)

---

**Date de dernière modification** : 2026-06-27
**Version du firmware** : Arduino Laser v2.0
**Testé sur** : Arduino Uno R3 (ATmega328P)
