// ================================================================
// laser_gpio.h — Gestion GPIO pour Laser OOK
// ================================================================
// Configure et contrôle les GPIO TX/RX pour les 3 canaux laser.
// Version Arduino Uno (ATmega328P)
// ================================================================

#ifndef LASER_GPIO_H
#define LASER_GPIO_H

#include <Arduino.h>
#include "config/laser_config.h"

// ================================================================
// DÉCLARATION DES PINS
// ================================================================
extern const uint8_t txPins[NUM_CHANNELS];
extern const uint8_t rxPins[NUM_CHANNELS];

// ================================================================
// INITIALISATION GPIO
// ================================================================
/**
 * Initialise les GPIO TX et RX pour les 3 canaux laser
 * - TX : OUTPUT, LOW par défaut (laser éteint)
 * - RX : INPUT_PULLUP (photodiode avec pull-up interne)
 */
void initLaserGPIO();

// ================================================================
// CONTRÔLE TX (ISR-SAFE pour Arduino)
// ================================================================
/**
 * Active un canal TX (laser ON)
 * @param channel Canal à activer (0-2)
 * 
 * Sur Arduino Uno, digitalWrite est ISR-safe
 */
inline void setTxPinHigh(uint8_t channel) {
  digitalWrite(txPins[channel], HIGH);
}

/**
 * Désactive un canal TX (laser OFF)
 * @param channel Canal à désactiver (0-2)
 */
inline void setTxPinLow(uint8_t channel) {
  digitalWrite(txPins[channel], LOW);
}

/**
 * Définit l'état d'un canal TX
 * @param channel Canal (0-2)
 * @param state true = laser ON, false = laser OFF
 */
inline void setTxPin(uint8_t channel, bool state) {
  digitalWrite(txPins[channel], state ? HIGH : LOW);
}

// ================================================================
// LECTURE RX
// ================================================================
/**
 * Lit l'état d'un canal RX (photodiode)
 * @param channel Canal à lire (0-2)
 * @return true si lumière détectée, false sinon
 */
inline bool readRxPin(uint8_t channel) {
  return digitalRead(rxPins[channel]) == HIGH;
}

/**
 * Éteint tous les canaux TX (sécurité)
 */
void stopAllLasers();

#endif
