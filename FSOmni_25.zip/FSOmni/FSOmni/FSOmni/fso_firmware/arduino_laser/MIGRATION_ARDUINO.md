# 🔧 Migration vers Arduino Uno

## Problème actuel

Le code laser a été écrit pour **ESP32** et utilise :
- `Serial.printf()` → pas supporté sur Arduino Uno
- `hw_timer_t` → Timer ESP32, il faut utiliser **Timer1** sur Arduino
- `IRAM_ATTR` → spécifique ESP32
- `timerBegin()`, `timerAttachInterrupt()` → API ESP32

## ✅ Solutions à implémenter

### 1. Remplacer Serial.printf par Serial.print

Arduino Uno ne supporte pas `printf`. Il faut utiliser :
```cpp
// ESP32 (avant)
Serial.printf("Valeur: %d\n", valeur);

// Arduino (après)
Serial.print(F("Valeur: "));
Serial.println(valeur);
```

### 2. Remplacer hw_timer_t par Timer1 (Arduino)

Sur Arduino Uno, utiliser la bibliothèque **TimerOne** :

```cpp
// Dans platformio.ini ou Arduino IDE
lib_deps = 
    paulstoffregen/TimerOne@^1.1.1

// Dans le code
#include <TimerOne.h>

// Initialisation (200 Hz = 5000 µs)
Timer1.initialize(BIT_DURATION_US);
Timer1.attachInterrupt(onTxTimer);
Timer1.start();
```

### 3. Supprimer IRAM_ATTR

```cpp
// ESP32 (avant)
void IRAM_ATTR onTxTimer() { }

// Arduino (après)
void onTxTimer() { }
```

### 4. Remplacer String.isEmpty() par String.length()

```cpp
// Avant
if (!receivedText.isEmpty())

// Après  
if (receivedText.length() > 0)
```

## 📦 Bibliothèques requises

Pour Arduino Uno:
```
ArduinoJson
TimerOne
```

## 🚀 Prochaines étapes

1. Installer la bibliothèque TimerOne
2. Créer les fichiers .cpp adaptés pour Arduino Uno
3. Tester la compilation
