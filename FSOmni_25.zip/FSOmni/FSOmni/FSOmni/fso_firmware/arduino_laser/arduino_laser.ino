// ================================================================
// arduino_laser.ino — Arduino Laser Controller
// ================================================================
// Contrôleur laser OOK dédié pour Arduino Uno
// Communication avec ESP32 via Serial (115200 baud)
// 
// RESPONSABILITÉS :
// - Transmission/Réception laser OOK 3 canaux
// - Contrôle servo-moteurs
// - Exécution des commandes depuis ESP32
// - Remontée des messages reçus vers ESP32
// ================================================================

#include <ArduinoJson.h>
#include <TimerOne.h>

// Header principal (tous les fichiers .cpp/.h sont maintenant à la racine)
#include "laser_manager.h"

// ================================================================
// CONFIGURATION
// ================================================================
#define SERIAL_BAUD 115200

// ================================================================
// SERVO (à implémenter)
// ================================================================
// #include <Servo.h>
// #define SERVO_TILT_PIN 10
// #define SERVO_PAN_PIN 11
// Servo servoTilt;
// Servo servoPan;

// ================================================================
// SETUP
// ================================================================
void setup() {
  // Initialiser communication avec ESP32
  Serial.begin(SERIAL_BAUD);
  delay(500);
  
  // Initialiser le système laser complet
  initLaserComm();
  
  // Démarrer la réception
  startReceiving();
  
  // TODO: Initialiser les servos
  // servoTilt.attach(SERVO_TILT_PIN);
  // servoPan.attach(SERVO_PAN_PIN);
  
  // Signaler que l'Arduino est prêt
  sendEvent("ready", "Arduino Laser v2.0");
}

// ================================================================
// LOOP PRINCIPAL
// ================================================================
void loop() {
  // 1. Maintenance communication laser
  laserCommLoop();
  
  // 2. Lire et traiter les commandes depuis l'ESP32
  handleSerialCommands();
  
  // 3. Envoyer les messages laser reçus vers l'ESP32
  sendReceivedMessages();
  
  delay(10);
}

// ================================================================
// GESTION DES COMMANDES DEPUIS ESP32
// ================================================================
void handleSerialCommands() {
  if (Serial.available()) {
    String jsonCmd = Serial.readStringUntil('\n');
    
    StaticJsonDocument<128> doc;  // ⚠️ RÉDUIT: 512→128 pour économiser RAM
    DeserializationError error = deserializeJson(doc, jsonCmd);
    
    if (error) {
      sendError("JSON parse error");
      return;
    }
    
    const char* cmd = doc["cmd"];
    if (cmd == nullptr) {
      sendError("Missing 'cmd' field");
      return;
    }
    
    // ──────────────────────────────────────────────────────────
    // COMMANDE: Transmettre un message laser (mode streaming)
    // ──────────────────────────────────────────────────────────
    if (strcmp(cmd, "tx") == 0) {
      const char* text = doc["text"];
      int unitId = doc["unit"] | 0;
      
      if (text == nullptr) {
        sendError("Missing 'text' field");
        return;
      }
      
      bool ok = transmitText(String(text), unitId);
      
      if (ok) {
        sendEvent("tx_started", "");
      } else {
        sendError("TX busy - wait for tx_done");
      }
    }
    
    // ──────────────────────────────────────────────────────────
    // COMMANDE: Contrôler un servo
    // ──────────────────────────────────────────────────────────
    else if (strcmp(cmd, "servo") == 0) {
      const char* axis = doc["axis"];
      float angle = doc["angle"];
      
      if (axis == nullptr) {
        sendError("Missing 'axis' field");
        return;
      }
      
      // TODO: Contrôler le servo
      /*
      if (strcmp(axis, "tilt") == 0) {
        servoTilt.write(angle);
      } else if (strcmp(axis, "pan") == 0) {
        servoPan.write(angle);
      }
      */
      
      sendEvent("servo_ok", "");
    }
    
    // ──────────────────────────────────────────────────────────
    // COMMANDE: Ping
    // ──────────────────────────────────────────────────────────
    else if (strcmp(cmd, "ping") == 0) {
      sendPong();
    }
    
    // ──────────────────────────────────────────────────────────
    // COMMANDE: Status
    // ──────────────────────────────────────────────────────────
    else if (strcmp(cmd, "status") == 0) {
      sendStatus();
    }
    
    else {
      sendError("Unknown command");
    }
  }
}

// ================================================================
// ENVOI DES MESSAGES LASER REÇUS VERS ESP32
// ================================================================
void sendReceivedMessages() {
  if (hasReceivedMessage()) {
    StaticJsonDocument<128> doc;  // ⚠️ RÉDUIT: 512→128 pour économiser RAM
    doc["evt"] = "rx";
    doc["text"] = receivedText;
    doc["unit"] = receivedUnitId;
    
    serializeJson(doc, Serial);
    Serial.println();
    
    // Vider le buffer
    receivedText = "";
    receivedUnitId = 0;
  }
}

// ================================================================
// FONCTIONS UTILITAIRES - ENVOI JSON VERS ESP32
// ================================================================

void sendEvent(const char* eventType, const char* message) {
  StaticJsonDocument<96> doc;  // ⚠️ RÉDUIT: 256→96 pour économiser RAM
  doc["evt"] = eventType;
  if (strlen(message) > 0) {
    doc["msg"] = message;
  }
  serializeJson(doc, Serial);
  Serial.println();
}

void sendError(const char* message) {
  StaticJsonDocument<64> doc;
  doc["evt"] = "error";
  doc["msg"] = message;
  serializeJson(doc, Serial);
  Serial.println();
}

void sendPong() {
  StaticJsonDocument<96> doc;
  doc["evt"] = "pong";
  doc["free_ram"] = freeRam();
  doc["tx_busy"] = isTransmitterBusy();
  doc["tx_ready"] = isLaserReadyToTransmit();
  serializeJson(doc, Serial);
  Serial.println();
}

void sendStatus() {
  StaticJsonDocument<96> doc;
  doc["evt"] = "status";
  doc["tx_busy"] = isTransmitterBusy();
  doc["tx_ready"] = isLaserReadyToTransmit();
  doc["free_ram"] = freeRam();
  doc["uptime"] = millis() / 1000;
  serializeJson(doc, Serial);
  Serial.println();
}

int freeRam() {
  extern int __heap_start, *__brkval;
  int v;
  return (int) &v - (__brkval == 0 ? (int) &__heap_start : (int) __brkval);
}
