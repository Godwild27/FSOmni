// ================================================================
// laser_transmitter.h — Émetteur Laser OOK (Mode Streaming)
// ================================================================
// Gère la transmission de données par laser sur 3 canaux parallèles :
// - Timer1 ISR pour modulation OOK bit par bit (Arduino Uno)
// - Mode streaming pur : pas de queue, transmission immédiate
// - Flow control géré par ESP32
// ================================================================

#ifndef LASER_TRANSMITTER_H
#define LASER_TRANSMITTER_H

#include <Arduino.h>
#include "config/laser_config.h"
#include "protocol.h"
#include "laser_gpio.h"

// ================================================================
// ÉTAT TRANSMISSION
// ================================================================
extern TxState txState;

// Buffer de transmission (volatile pour accès ISR)
extern volatile uint8_t  txBuffer[MAX_FRAME_SIZE];
extern volatile uint16_t txBufferLen;
extern volatile uint16_t txBitGroupIndex;
extern volatile bool     txBusy;
extern volatile bool     txEnabled;

// Signaux inter-ISR/loop
extern volatile bool txJustFinished;    // Flag posé par ISR quand TX termine

// ================================================================
// INITIALISATION
// ================================================================
/**
 * Initialise le système de transmission laser
 * - Configure Timer1 (200 Hz sur Arduino Uno)
 * - Attache l'ISR de transmission
 */
void initTransmitter();

// ================================================================
// ISR TRANSMISSION
// ================================================================
/**
 * ISR Timer1 TX — appelée toutes les 5ms (200 Hz)
 * Transmet 3 bits en parallèle (un par canal) à chaque appel
 */
void onTxTimer();

// ================================================================
// TRANSMISSION (Mode Streaming)
// ================================================================
/**
 * Démarre une transmission laser immédiate
 * Rejette si TX déjà occupée (ESP32 doit attendre "tx_done")
 * 
 * @param text Texte à transmettre
 * @param unitId ID de l'unité émettrice
 * @return true si transmission démarrée, false si TX occupée
 */
bool startTransmission(const String& text, int unitId);

/**
 * Vérifie si le transmetteur est occupé
 * @return true si transmission en cours
 */
bool isTransmitterBusy();

#endif
