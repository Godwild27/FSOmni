// ================================================================
// laser_manager.cpp — Implémentation Gestionnaire Laser
// ================================================================

#include "laser_manager.h"

// ================================================================
// VARIABLES GLOBALES MANAGER
// ================================================================
bool     txInCooldown = false;
uint32_t txCooldownStart = 0;

String receivedText = "";
int    receivedUnitId = 0;

// ================================================================
// INITIALISATION COMPLÈTE
// ================================================================
void initLaserComm() {
  Serial.println(F("========================================"));
  Serial.println(F("Initialisation communication laser OOK"));
  Serial.println(F("========================================"));
  
  // 1. Initialiser les GPIO
  initLaserGPIO();
  
  // 2. Initialiser le transmetteur
  initTransmitter();
  
  // 3. Initialiser le récepteur
  initReceiver();
  
  Serial.print(F("Communication laser initialisee ("));
  Serial.print(NUM_CHANNELS);
  Serial.print(F(" canaux, "));
  Serial.print((1000000 / BIT_DURATION_US) * NUM_CHANNELS);
  Serial.println(F(" bits/s total)"));
  Serial.println(F("========================================"));
}

// ================================================================
// API TRANSMISSION (Mode Streaming)
// ================================================================
bool transmitText(const String& text, int unitId) {
  // Mode streaming : rejeter si TX occupée
  if (txBusy || txInCooldown) {
    Serial.println(F("⏳ TX occupee - ESP32 doit attendre tx_done"));
    return false;
  }
  
  // Transmettre immédiatement
  return startTransmission(text, unitId);
}

// ================================================================
// BOUCLE DE MAINTENANCE
// ================================================================
void laserCommLoop() {
  
  // ──────────────────────────────────────────────────────────
  // LOG PRÉAMBULE (déplacé hors ISR pour éviter Serial dans ISR)
  // ──────────────────────────────────────────────────────────
  if (preambleJustDetected) {
    preambleJustDetected = false;
    Serial.println("  [RX] 🎯 Préambule détecté - Enregistrement activé");
  }
  
  // ──────────────────────────────────────────────────────────
  // 1. L'ISR vient de terminer une TX → démarrer le cooldown
  // ──────────────────────────────────────────────────────────
  if (txJustFinished) {
    txJustFinished    = false;
    txInCooldown      = true;
    txCooldownStart   = millis();
    
    uint32_t duration = millis() - txState.startTime;
    txState.bitRate   = (txBufferLen * 8 * 1000.0) / duration;
    
    Serial.print(F("  [TX] ✅ Transmission terminee en "));
    Serial.print(duration);
    Serial.print(F(" ms (debit: "));
    Serial.print(txState.bitRate);
    Serial.println(F(" bits/s)"));
    Serial.print(F("  [COOLDOWN] ⏱️  Attente "));
    Serial.print(TX_RX_COOLDOWN_MS);
    Serial.println(F(" ms avant reactivation RX..."));
    
    // Suspendre RX pendant le cooldown
    pauseReceiving();
  }
  
  // ──────────────────────────────────────────────────────────
  // 2. Cooldown écoulé → réactiver RX immédiatement
  // ──────────────────────────────────────────────────────────
  if (txInCooldown && (millis() - txCooldownStart >= TX_RX_COOLDOWN_MS)) {
    txInCooldown = false;
    
    // Mode streaming : toujours réactiver RX après cooldown
    // Pas de queue à vider
    resumeReceiving();
  }
  
  // ──────────────────────────────────────────────────────────
  // 3. Trame RX complète reçue → traiter
  // ──────────────────────────────────────────────────────────
  if (isFrameReady()) {
    pauseReceiving();  // Suspendre RX pendant traitement
    
    uint32_t duration = millis() - rxState.startTime;
    rxState.bitRate   = (rxBufferLen * 8 * 1000.0) / duration;
    
    Serial.print(F("  [RX] ✅ Reception terminee en "));
    Serial.print(duration);
    Serial.print(F(" ms (debit: "));
    Serial.print(rxState.bitRate);
    Serial.println(F(" bits/s)"));
    
    // Parser la trame
    if (rxBufferLen > 0) {
      Serial.print(F("  [RX] 📥 Traitement de la trame recue ("));
      Serial.print(rxBufferLen);
      Serial.println(F(" octets)"));
      
      if (parseLaserFrame(rxBuffer, rxBufferLen, receivedText, receivedUnitId)) {
        Serial.print(F("  [RX] ✅ unit_id="));
        Serial.print(receivedUnitId);
        Serial.print(F(", text=\""));
        Serial.print(receivedText);
        Serial.println(F("\""));
        rxState.receivedBytes = receivedText.length();
      } else {
        Serial.println(F("  [RX] ❌ Erreur parsing trame"));
      }
    }
    
    // Réinitialiser pour la prochaine trame
    resetReceiverForNextFrame();
  }
}

// ================================================================
// UTILITAIRES STATUS
// ================================================================
bool isLaserReadyToTransmit() {
  return !txBusy && !txInCooldown;  // Mode streaming : pas de queue
}

bool hasReceivedMessage() {
  return receivedText.length() > 0;  // ✅ Arduino compatible
}
