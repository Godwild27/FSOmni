// ================================================================
// laser_gpio.cpp — Implémentation GPIO Laser
// ================================================================

#include "laser_gpio.h"

// ================================================================
// DÉFINITION DES PINS
// ================================================================
const uint8_t txPins[NUM_CHANNELS] = {TX1_PIN, TX2_PIN, TX3_PIN};
const uint8_t rxPins[NUM_CHANNELS] = {RX1_PIN, RX2_PIN, RX3_PIN};

// ================================================================
// INITIALISATION GPIO
// ================================================================
void initLaserGPIO() {
  Serial.println(F("  [GPIO] Initialisation des GPIO laser..."));
  
  // Configuration TX — sortie numérique (OOK : HIGH = laser ON, LOW = laser OFF)
  for (int ch = 0; ch < NUM_CHANNELS; ch++) {
    pinMode(txPins[ch], OUTPUT);
    digitalWrite(txPins[ch], LOW);  // Laser éteint par défaut
    Serial.print(F("    TX Canal "));
    Serial.print(ch + 1);
    Serial.print(F(" : Pin "));
    Serial.print(txPins[ch]);
    Serial.println(F(" (OUTPUT)"));
  }
  
  // Configuration RX — entrée avec pull-up (photodiode)
  for (int ch = 0; ch < NUM_CHANNELS; ch++) {
    pinMode(rxPins[ch], INPUT_PULLUP);
    Serial.print(F("    RX Canal "));
    Serial.print(ch + 1);
    Serial.print(F(" : Pin "));
    Serial.print(rxPins[ch]);
    Serial.println(F(" (INPUT_PULLUP)"));
  }
  
  Serial.println(F("  [GPIO] ✅ GPIO laser configurés"));
}

// ================================================================
// SÉCURITÉ
// ================================================================
void stopAllLasers() {
  for (int ch = 0; ch < NUM_CHANNELS; ch++) {
    digitalWrite(txPins[ch], LOW);
  }
}
