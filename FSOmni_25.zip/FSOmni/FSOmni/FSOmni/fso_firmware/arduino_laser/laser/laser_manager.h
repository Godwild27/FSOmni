// ================================================================
// laser_manager.h — Gestionnaire Principal Laser
// ================================================================
// API publique unifiée pour la communication laser OOK.
// Coordonne TX et RX avec gestion du cooldown TX→RX.
// 
// C'EST LE SEUL FICHIER À INCLURE DANS LE CODE PRINCIPAL !
// ================================================================

#ifndef LASER_MANAGER_H
#define LASER_MANAGER_H

#include <Arduino.h>
#include "../config/laser_config.h"
#include "../protocol.h"  // ✅ Corrigé: protocol.h est à la racine
#include "laser_gpio.h"
#include "laser_protocol.h"
#include "laser_transmitter.h"
#include "laser_receiver.h"

// ================================================================
// GESTION DU COOLDOWN TX → RX
// ================================================================
// État du cooldown
extern bool     txInCooldown;       // On est dans la période de garde
extern uint32_t txCooldownStart;    // Timestamp de début du cooldown

// ================================================================
// MESSAGES REÇUS (disponibles pour le code applicatif)
// ================================================================
extern String receivedText;         // Dernier texte reçu par laser
extern int    receivedUnitId;       // ID de l'unité émettrice

// ================================================================
// INITIALISATION COMPLÈTE
// ================================================================
/**
 * Initialise tout le système de communication laser
 * - GPIO (TX et RX)
 * - Transmetteur (timer TX + queue)
 * - Récepteur (timer RX)
 * 
 * À appeler une fois dans setup()
 */
void initLaserComm();

// ================================================================
// API TRANSMISSION
// ================================================================
/**
 * Transmet un message texte par laser
 * 
 * Si le transmetteur est occupé ou en cooldown, le message
 * est automatiquement mis en file d'attente (TX queue).
 * 
 * @param text Texte à transmettre (max ~4000 caractères)
 * @param unitId ID de l'unité émettrice (0-999+)
 * @return true si transmission démarrée ou mise en queue
 *         false si erreur (queue pleine ou message trop long)
 */
bool transmitText(const String& text, int unitId);

// ================================================================
// BOUCLE DE MAINTENANCE
// ================================================================
/**
 * Boucle de maintenance à appeler régulièrement dans loop()
 * 
 * Gère :
 * - Fin de transmission et démarrage du cooldown
 * - Expiration du cooldown et réactivation RX
 * - Vidage de la queue TX si messages en attente
 * - Traitement des trames RX complètes
 * 
 * À appeler dans loop() toutes les 10-50ms
 */
void laserCommLoop();

// ================================================================
// UTILITAIRES STATUS
// ================================================================
/**
 * Vérifie si le système laser est prêt à transmettre immédiatement
 * @return true si TX disponible (pas busy, pas en cooldown, queue vide)
 */
bool isLaserReadyToTransmit();

/**
 * Obtient le nombre de messages en attente dans la queue TX
 * @return Nombre de messages (0-8)
 */
uint8_t getTxQueueLength();

/**
 * Vérifie si un nouveau message a été reçu par laser
 * Utiliser receivedText et receivedUnitId pour lire le message
 * Penser à vider receivedText après traitement !
 * 
 * @return true si receivedText n'est pas vide
 */
bool hasReceivedMessage();

#endif
