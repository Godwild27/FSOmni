// ================================================================
// laser_receiver.cpp — Implémentation Récepteur Laser
// ================================================================

#include "laser_receiver.h"
#include <TimerOne.h>  // ✅ Timer1 pour Arduino Uno

// ================================================================
// VARIABLES GLOBALES RX
// ================================================================
RxState rxState;

volatile uint8_t  rxBuffer[MAX_FRAME_SIZE];
volatile uint16_t rxBufferLen = 0;
volatile uint16_t rxBitGroupIndex = 0;
volatile bool     rxFrameComplete = false;
volatile bool     rxPreambleDetected = false;
volatile uint8_t  rxPreambleCount = 0;
volatile bool     rxEnabled = true;

volatile bool preambleJustDetected = false;

// Note: On utilise le même Timer1 que TX, mais en mode partagé
// RX et TX ne peuvent pas être actifs en même temps

// ================================================================
// INITIALISATION RÉCEPTEUR
// ================================================================
void initReceiver() {
  Serial.println(F("  [RX] Initialisation du recepteur..."));
  
  // Timer1 est déjà initialisé par initTransmitter()
  // On va le partager entre TX et RX
  
  Serial.println(F("  [RX] Timer RX configure (200 Hz, 5ms par bit)"));
}

// ================================================================
// ISR RÉCEPTION
// ================================================================
void onRxTimer() {
  if (!rxEnabled) return;
  if (rxFrameComplete) return;
  
  // Échantillonner les 3 canaux en parallèle
  for (int ch = 0; ch < NUM_CHANNELS; ch++) {
    uint32_t bitIdx    = rxBitGroupIndex * NUM_CHANNELS + ch;
    uint32_t byteIndex = bitIdx / 8;
    uint8_t  bitPos    = bitIdx % 8;
    
    // Overflow protection
    if (byteIndex >= MAX_FRAME_SIZE) {
      rxFrameComplete = true;
      rxState.errorCount++;
      return;
    }
    
    // Lire le bit du canal (photodiode)
    uint8_t bit = readRxPin(ch) ? 1 : 0;
    
    // Stocker le bit dans le buffer
    if (bit) {
      rxBuffer[byteIndex] |= (1 << bitPos);
    } else {
      rxBuffer[byteIndex] &= ~(1 << bitPos);
    }
  }
  
  rxBitGroupIndex++;
  
  // ──────────────────────────────────────────────────────────
  // DÉTECTION DU PRÉAMBULE
  // ──────────────────────────────────────────────────────────
  if (!rxPreambleDetected) {
    if (rxBitGroupIndex >= PREAMBLE_LENGTH) {
      uint8_t preambleMatches = 0;
      for (int i = 0; i < PREAMBLE_LENGTH; i++) {
        if (rxBuffer[i] == PREAMBLE_PATTERN) {
          preambleMatches++;
        }
      }
      
      // Préambule détecté si au moins 6/8 octets correspondent
      if (preambleMatches >= 6) {
        rxPreambleDetected   = true;
        preambleJustDetected = true;  // Pour log asynchrone
      } else {
        // Faux départ, réinitialiser
        rxBitGroupIndex = 0;
        memset((void*)rxBuffer, 0, 64);  // Reset buffer préambule
        return;
      }
    } else {
      return;  // Pas assez de données pour le préambule
    }
  }
  
  // ──────────────────────────────────────────────────────────
  // DÉTECTION DU FOOTER
  // ──────────────────────────────────────────────────────────
  if (rxBitGroupIndex > 96) {  // Au moins 32 octets reçus
    uint32_t lastByteIdx = (rxBitGroupIndex * NUM_CHANNELS) / 8;
    
    if (lastByteIdx > 0 && lastByteIdx < MAX_FRAME_SIZE) {
      if (rxBuffer[lastByteIdx - 1] == FRAME_FOOTER) {
        rxFrameComplete = true;
        rxBufferLen     = lastByteIdx;
      }
    }
  }
  
  // Protection timeout (trame trop longue)
  if (rxBitGroupIndex > 11000) {  // 4096 octets × 8 bits / 3 canaux = 10923 groupes max
    rxFrameComplete = true;
    rxBufferLen     = 0;  // Marquer comme erreur
  }
}

// ================================================================
// CONTRÔLE RÉCEPTION
// ================================================================
void startReceiving() {
  Serial.println(F("  [RX] Demarrage de la reception laser..."));
  
  memset((void*)rxBuffer, 0, MAX_FRAME_SIZE);
  rxBufferLen          = 0;
  rxBitGroupIndex      = 0;
  rxFrameComplete      = false;
  rxPreambleDetected   = false;
  rxState.active       = true;
  rxState.startTime    = millis();
  rxEnabled            = true;
  
  // Utiliser Timer1 avec l'ISR RX
  Timer1.attachInterrupt(onRxTimer);
  Timer1.start();
  
  Serial.println(F("  [RX] Reception active (attente du preambule)"));
}

void stopReceiving() {
  Timer1.stop();
  rxEnabled      = false;
  rxState.active = false;
  Serial.println(F("  [RX] Reception laser arretee"));
}

void pauseReceiving() {
  rxEnabled = false;
  Serial.println(F("  [RX] RX pause pendant TX"));
}

void resumeReceiving() {
  rxPreambleDetected = false;
  rxBitGroupIndex    = 0;
  rxFrameComplete    = false;
  memset((void*)rxBuffer, 0, 64);  // Reset buffer préambule
  rxState.startTime  = millis();
  rxState.active     = true;
  rxEnabled          = true;
  
  // Réattacher l'ISR RX au Timer1
  Timer1.attachInterrupt(onRxTimer);
  Timer1.start();
  
  Serial.println(F("  [RX] RX reactive apres cooldown"));
}

// ================================================================
// VÉRIFICATION TRAME
// ================================================================
bool isFrameReady() {
  return rxFrameComplete;
}

void resetReceiverForNextFrame() {
  rxFrameComplete    = false;
  rxPreambleDetected = false;
  rxBitGroupIndex    = 0;
  memset((void*)rxBuffer, 0, MAX_FRAME_SIZE);
  rxState.startTime  = millis();
  rxState.active     = true;
  rxEnabled          = true;
}
