// ================================================================
// laser_receiver.h — Récepteur Laser OOK
// ================================================================
// Gère la réception de données par photodiodes sur 3 canaux parallèles :
// - Timer1 ISR pour échantillonnage synchrone (Arduino Uno)
// - Détection de préambule et synchronisation
// - Reconstruction de trame bit par bit
// - Détection automatique du footer
// ================================================================

#ifndef LASER_RECEIVER_H
#define LASER_RECEIVER_H

#include <Arduino.h>
#include "../config/laser_config.h"
#include "../protocol.h"  // ✅ Corrigé: protocol.h est à la racine
#include "laser_gpio.h"

// ================================================================
// ÉTAT RÉCEPTION
// ================================================================
extern RxState rxState;

// Buffer de réception (volatile pour accès ISR)
extern volatile uint8_t  rxBuffer[MAX_FRAME_SIZE];
extern volatile uint16_t rxBufferLen;
extern volatile uint16_t rxBitGroupIndex;
extern volatile bool     rxFrameComplete;
extern volatile bool     rxPreambleDetected;
extern volatile uint8_t  rxPreambleCount;
extern volatile bool     rxEnabled;

// Signaux inter-ISR/loop
extern volatile bool preambleJustDetected;  // Pour log asynchrone

// ================================================================
// INITIALISATION
// ================================================================
/**
 * Initialise le système de réception laser
 * - Configure Timer1 (200 Hz sur Arduino Uno)
 * - Initialise les buffers RX
 * - Attache l'ISR de réception
 */
void initReceiver();

// ================================================================
// ISR RÉCEPTION
// ================================================================
/**
 * ISR Timer1 RX — appelée toutes les 5ms (200 Hz)
 * Échantillonne 3 bits en parallèle (un par canal) à chaque appel
 * Détecte automatiquement le préambule et le footer
 */
void onRxTimer();

// ================================================================
// CONTRÔLE RÉCEPTION
// ================================================================
/**
 * Démarre la réception laser
 * Réinitialise les buffers et active l'ISR
 */
void startReceiving();

/**
 * Arrête la réception laser
 * Désactive l'ISR et met à jour l'état
 */
void stopReceiving();

/**
 * Suspend temporairement la réception (pendant TX)
 * Plus léger que stopReceiving(), juste un flag
 */
void pauseReceiving();

/**
 * Reprend la réception après une pause
 * Réinitialise les buffers pour une nouvelle trame
 */
void resumeReceiving();

// ================================================================
// VÉRIFICATION TRAME
// ================================================================
/**
 * Vérifie si une trame complète a été reçue
 * @return true si trame prête à être traitée
 */
bool isFrameReady();

/**
 * Réinitialise le récepteur pour la prochaine trame
 * Appelé après traitement d'une trame complète
 */
void resetReceiverForNextFrame();

#endif
