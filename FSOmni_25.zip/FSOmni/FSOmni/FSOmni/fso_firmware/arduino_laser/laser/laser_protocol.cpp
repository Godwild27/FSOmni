// ================================================================
// laser_protocol.cpp — Implémentation Protocole Laser
// ================================================================

#include "laser_protocol.h"

// ================================================================
// CONSTRUCTION DE TRAME TX
// ================================================================
uint16_t buildLaserFrame(volatile uint8_t* buffer, const String& text, int unitId) {
  // Format payload : "unitId:text" ou "0:text" si unitId non configuré
  String payload = (unitId > 0) ? String(unitId) + ":" + text : "0:" + text;
  
  uint16_t framePos = 0;
  
  // 1. Préambule (synchronisation)
  for (int i = 0; i < PREAMBLE_LENGTH; i++) {
    buffer[framePos++] = PREAMBLE_PATTERN;
  }
  
  // 2. Sync word
  buffer[framePos++] = SYNC_WORD;
  
  // 3. Frame header (STX)
  buffer[framePos++] = FRAME_HEADER;
  
  // 4. Payload avec échappement des caractères spéciaux
  for (unsigned int i = 0; i < payload.length(); i++) {
    uint8_t b = payload[i];
    
    // Échapper les caractères de contrôle
    if (b == FRAME_HEADER || b == FRAME_FOOTER || b == ESCAPE_BYTE) {
      buffer[framePos++] = ESCAPE_BYTE;
      if (framePos >= MAX_FRAME_SIZE - 2) {
        Serial.println("  [PROTOCOL] ❌ Trame trop longue pendant construction");
        return 0;
      }
    }
    
    buffer[framePos++] = b;
    
    if (framePos >= MAX_FRAME_SIZE - 1) {
      Serial.println("  [PROTOCOL] ❌ Dépassement buffer pendant construction");
      return 0;
    }
  }
  
  // 5. Frame footer (ETX)
  buffer[framePos++] = FRAME_FOOTER;
  
  return framePos;
}

// ================================================================
// PARSING DE TRAME RX
// ================================================================
bool parseLaserFrame(const volatile uint8_t* buffer, uint16_t bufferLen,
                     String& text, int& unitId) {
  
  // 1. Trouver le FRAME_HEADER
  int headerPos = -1;
  for (int i = 0; i < bufferLen; i++) {
    if (buffer[i] == FRAME_HEADER) {
      headerPos = i;
      break;
    }
  }
  
  if (headerPos == -1) {
    Serial.println("  [PROTOCOL] ❌ FRAME_HEADER non trouvé");
    return false;
  }
  
  // 2. Trouver le FRAME_FOOTER
  int footerPos = -1;
  for (int i = headerPos + 1; i < bufferLen; i++) {
    if (buffer[i] == FRAME_FOOTER) {
      footerPos = i;
      break;
    }
  }
  
  if (footerPos == -1) {
    Serial.println("  [PROTOCOL] ❌ FRAME_FOOTER non trouvé");
    return false;
  }
  
  // 3. Décoder le payload (avec gestion de l'échappement)
  String decoded = "";
  bool escaped = false;
  
  for (int i = headerPos + 1; i < footerPos; i++) {
    uint8_t b = buffer[i];
    
    if (escaped) {
      decoded += (char)b;
      escaped = false;
    } else if (b == ESCAPE_BYTE) {
      escaped = true;
    } else {
      decoded += (char)b;
    }
  }
  
  // 4. Parser le format "unitId:text"
  int colonPos = decoded.indexOf(':');
  
  if (colonPos > 0) {
    unitId = decoded.substring(0, colonPos).toInt();
    text   = decoded.substring(colonPos + 1);
  } else {
    // Pas de format unitId:text → assume unitId = 0
    unitId = 0;
    text   = decoded;
  }
  
  return true;
}

// ================================================================
// UTILITAIRES
// ================================================================
uint16_t estimateFrameSize(const String& text, int unitId) {
  String payload = (unitId > 0) ? String(unitId) + ":" + text : "0:" + text;
  
  // Préambule + Sync + Header + Footer = 11 octets
  // Payload + ~10% d'échappement
  return 11 + payload.length() + (payload.length() / 10);
}

bool isMessageTransmittable(const String& text, int unitId) {
  uint16_t estimatedSize = estimateFrameSize(text, unitId);
  return estimatedSize <= MAX_FRAME_SIZE;
}
