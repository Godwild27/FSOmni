// ================================================================
// laser_protocol.h — Protocole de Trame OOK
// ================================================================
// Gère la construction et le parsing des trames laser OOK :
// - Préambule pour synchronisation
// - Encapsulation des données (header/footer)
// - Échappement des caractères spéciaux
// - Format payload : "unitId:text"
// ================================================================

#ifndef LASER_PROTOCOL_H
#define LASER_PROTOCOL_H

#include <Arduino.h>
#include "../config/laser_config.h"

// ================================================================
// CONSTRUCTION DE TRAME TX
// ================================================================
/**
 * Construit une trame laser complète prête à transmettre
 * 
 * Structure de la trame :
 * [PREAMBLE × 8] [SYNC] [HEADER] [payload échappé] [FOOTER]
 * 
 * @param buffer Buffer de sortie (doit être >= MAX_FRAME_SIZE)
 * @param text Texte à transmettre
 * @param unitId ID de l'unité émettrice (0 si non configuré)
 * @return Longueur de la trame construite (en octets), 0 si erreur
 */
uint16_t buildLaserFrame(volatile uint8_t* buffer, const String& text, int unitId);

// ================================================================
// PARSING DE TRAME RX
// ================================================================
/**
 * Parse une trame laser reçue et extrait le payload
 * 
 * @param buffer Buffer contenant la trame reçue
 * @param bufferLen Longueur du buffer
 * @param text [OUT] Texte extrait
 * @param unitId [OUT] ID de l'unité émettrice
 * @return true si parsing réussi, false sinon
 */
bool parseLaserFrame(const volatile uint8_t* buffer, uint16_t bufferLen, 
                     String& text, int& unitId);

// ================================================================
// UTILITAIRES PROTOCOLE
// ================================================================
/**
 * Estime la taille de la trame pour un texte donné
 * Utile pour valider avant transmission
 * 
 * @param text Texte à estimer
 * @param unitId ID de l'unité
 * @return Taille estimée en octets
 */
uint16_t estimateFrameSize(const String& text, int unitId);

/**
 * Vérifie si un message peut être transmis (taille OK)
 * 
 * @param text Texte à vérifier
 * @param unitId ID de l'unité
 * @return true si transmissible, false si trop long
 */
bool isMessageTransmittable(const String& text, int unitId);

#endif
