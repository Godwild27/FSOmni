// ================================================================
// laser_transmitter.h — Émetteur Laser OOK
// ================================================================
// Gère la transmission de données par laser sur 3 canaux parallèles :
// - File d'attente TX (queue) pour messages pendant transmission
// - Timer1 ISR pour modulation OOK bit par bit (Arduino Uno)
// - Gestion de l'état TX et statistiques
// ================================================================

#ifndef LASER_TRANSMITTER_H
#define LASER_TRANSMITTER_H

#include <Arduino.h>
#include "../config/laser_config.h"
#include "../protocol.h"  // ✅ Corrigé: protocol.h est à la racine
#include "laser_gpio.h"

// ================================================================
// FILE D'ATTENTE TX (TX QUEUE)
// ================================================================
struct TxQueueEntry {
  char text[TX_QUEUE_TEXT_MAX];
  int  unitId;
  bool valid;
};

extern TxQueueEntry txQueue[TX_QUEUE_SIZE];
extern uint8_t txQueueHead;    // Prochain à lire
extern uint8_t txQueueTail;    // Prochain à écrire
extern uint8_t txQueueCount;   // Nombre d'entrées actuelles

/**
 * Ajoute un message dans la file d'attente TX
 * @param text Texte à transmettre
 * @param unitId ID de l'unité émettrice
 * @return true si ajouté avec succès, false si queue pleine
 */
bool txQueuePush(const String& text, int unitId);

/**
 * Récupère le prochain message de la file d'attente
 * @param text [OUT] Texte récupéré
 * @param unitId [OUT] ID de l'unité
 * @return true si message récupéré, false si queue vide
 */
bool txQueuePop(String& text, int& unitId);

// ================================================================
// ÉTAT TRANSMISSION
// ================================================================
extern TxState txState;

// Buffer de transmission (volatile pour accès ISR)
extern volatile uint8_t  txBuffer[MAX_FRAME_SIZE];
extern volatile uint16_t txBufferLen;
extern volatile uint16_t txBitGroupIndex;
extern volatile bool     txBusy;
extern volatile bool     txEnabled;

// Signaux inter-ISR/loop
extern volatile bool txJustFinished;    // Flag posé par ISR quand TX termine

// ================================================================
// INITIALISATION
// ================================================================
/**
 * Initialise le système de transmission laser
 * - Configure Timer1 (200 Hz sur Arduino Uno)
 * - Initialise la queue TX
 * - Attache l'ISR de transmission
 */
void initTransmitter();

// ================================================================
// ISR TRANSMISSION
// ================================================================
/**
 * ISR Timer1 TX — appelée toutes les 5ms (200 Hz)
 * Transmet 3 bits en parallèle (un par canal) à chaque appel
 */
void onTxTimer();

// ================================================================
// TRANSMISSION
// ================================================================
/**
 * Démarre une transmission laser (interne)
 * Ne doit être appelée que si TX n'est pas occupée
 * 
 * @param text Texte à transmettre
 * @param unitId ID de l'unité émettrice
 * @return true si transmission démarrée, false si erreur
 */
bool startTransmission(const String& text, int unitId);

/**
 * Vérifie si le transmetteur est occupé
 * @return true si transmission en cours ou en cooldown
 */
bool isTransmitterBusy();

#endif
