// ================================================================
// laser_transmitter.cpp — Implémentation Transmetteur Laser
// ================================================================

#include "laser_transmitter.h"
#include "laser_protocol.h"
#include <TimerOne.h>  // ✅ Bibliothèque Timer1 pour Arduino Uno

// ================================================================
// VARIABLES GLOBALES TX
// ================================================================
TxState txState;
TxQueueEntry txQueue[TX_QUEUE_SIZE];
uint8_t txQueueHead = 0;
uint8_t txQueueTail = 0;
uint8_t txQueueCount = 0;

volatile uint8_t  txBuffer[MAX_FRAME_SIZE];
volatile uint16_t txBufferLen = 0;
volatile uint16_t txBitGroupIndex = 0;
volatile bool     txBusy = false;
volatile bool     txEnabled = false;

volatile bool txJustFinished = false;
volatile bool txTimerActive = false;  // Flag pour savoir si le timer est actif

// ================================================================
// FILE D'ATTENTE TX
// ================================================================
bool txQueuePush(const String& text, int unitId) {
  if (txQueueCount >= TX_QUEUE_SIZE) {
    Serial.println(F("  [TX] File d'attente TX pleine"));
    return false;
  }
  
  TxQueueEntry& entry = txQueue[txQueueTail];
  strncpy(entry.text, text.c_str(), TX_QUEUE_TEXT_MAX - 1);
  entry.text[TX_QUEUE_TEXT_MAX - 1] = '\0';
  entry.unitId = unitId;
  entry.valid = true;
  
  txQueueTail = (txQueueTail + 1) % TX_QUEUE_SIZE;
  txQueueCount++;
  
  Serial.print(F("  [TX] Message en queue ["));
  Serial.print(txQueueCount);
  Serial.print(F("/"));
  Serial.print(TX_QUEUE_SIZE);
  Serial.println(F("]"));
  
  return true;
}

bool txQueuePop(String& text, int& unitId) {
  if (txQueueCount == 0) return false;
  
  TxQueueEntry& entry = txQueue[txQueueHead];
  text   = String(entry.text);
  unitId = entry.unitId;
  entry.valid = false;
  
  txQueueHead = (txQueueHead + 1) % TX_QUEUE_SIZE;
  txQueueCount--;
  
  return true;
}

// ================================================================
// INITIALISATION TRANSMETTEUR
// ================================================================
void initTransmitter() {
  Serial.println(F("  [TX] Initialisation du transmetteur..."));
  
  // Initialiser la queue TX
  memset(txQueue, 0, sizeof(txQueue));
  txQueueHead = txQueueTail = txQueueCount = 0;
  Serial.print(F("  [TX] File d'attente initialisee ("));
  Serial.print(TX_QUEUE_SIZE);
  Serial.println(F(" slots)"));
  
  // Initialiser Timer1 pour 200 Hz (5000 µs)
  Timer1.initialize(BIT_DURATION_US);
  Timer1.attachInterrupt(onTxTimer);
  Timer1.stop();  // Arrêter le timer, il sera démarré lors de la transmission
  txTimerActive = false;
  
  Serial.println(F("  [TX] Timer TX configure (200 Hz, 5ms par bit)"));
}

// ================================================================
// ISR TRANSMISSION
// ================================================================
void onTxTimer() {
  if (!txEnabled || !txBusy) return;
  
  bool allChannelsDone = true;
  
  // Transmettre 3 bits en parallèle (un par canal)
  for (int ch = 0; ch < NUM_CHANNELS; ch++) {
    uint32_t bitIdx    = txBitGroupIndex * NUM_CHANNELS + ch;
    uint32_t byteIndex = bitIdx / 8;
    uint8_t  bitPos    = bitIdx % 8;
    
    // Canal terminé ?
    if (byteIndex >= txBufferLen) {
      setTxPinLow(ch);
      continue;
    }
    
    allChannelsDone = false;
    
    // Lire le bit à transmettre
    uint8_t bit = (txBuffer[byteIndex] >> bitPos) & 0x01;
    
    // Moduler le laser (OOK : HIGH = laser ON, LOW = laser OFF)
    setTxPin(ch, bit);
  }
  
  // Tous les canaux ont terminé ?
  if (allChannelsDone) {
    // Éteindre tous les lasers
    for (int ch = 0; ch < NUM_CHANNELS; ch++) {
      setTxPinLow(ch);
    }
    
    txBusy         = false;
    txEnabled      = false;
    txState.active = false;
    txJustFinished = true;
    
    // Arrêter le timer
    Timer1.stop();
    txTimerActive = false;
    return;
  }
  
  txBitGroupIndex++;
}

// ================================================================
// TRANSMISSION
// ================================================================
bool startTransmission(const String& text, int unitId) {
  Serial.print(F("  [TX] Preparation transmission: unit_id="));
  Serial.println(unitId);
  
  // Vérifier la taille
  if (!isMessageTransmittable(text, unitId)) {
    Serial.println(F("  [TX] Message trop long"));
    return false;
  }
  
  // Construire la trame
  txBufferLen = buildLaserFrame(txBuffer, text, unitId);
  
  if (txBufferLen == 0) {
    Serial.println(F("  [TX] Erreur construction trame"));
    return false;
  }
  
  Serial.print(F("  [TX] Trame construite : "));
  Serial.print(txBufferLen);
  Serial.println(F(" octets"));
  
  // Démarrer la transmission
  txBitGroupIndex    = 0;
  txBusy             = true;
  txState.active     = true;
  txState.totalBytes = txBufferLen;
  txState.sentBytes  = 0;
  txState.startTime  = millis();
  txEnabled          = true;
  
  // Démarrer le timer
  if (!txTimerActive) {
    Timer1.start();
    txTimerActive = true;
  }
  
  Serial.println(F("  [TX] Transmission demarree"));
  return true;
}

bool isTransmitterBusy() {
  return txBusy || txEnabled;
}
