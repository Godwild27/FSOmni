// ================================================================
// arduino_comm.h — Communication avec Arduino
// ================================================================

#ifndef ARDUINO_COMM_H
#define ARDUINO_COMM_H

#include <Arduino.h>
#include <ArduinoJson.h>
#include "config.h"

// État de l'Arduino
extern bool arduinoReady;

// Initialisation
void initArduinoComm();

// Envoi de commandes vers Arduino
void sendLaserTxCommand(const String& text, int unitId);
void sendServoCommand(const String& axis, float angle);
void sendArduinoPing();
void sendArduinoStatus();

// Réception des messages Arduino
void handleArduinoMessages();

// Callbacks pour traiter les événements Arduino
typedef void (*ArduinoRxCallback)(const String& text, int unitId);
typedef void (*ArduinoTxCallback)(const String& status, int queueLen);
typedef void (*ArduinoErrorCallback)(const String& error);

void setArduinoRxCallback(ArduinoRxCallback callback);
void setArduinoTxCallback(ArduinoTxCallback callback);
void setArduinoErrorCallback(ArduinoErrorCallback callback);

#endif
