// ================================================================
// esp32_fsomni.ino — ESP32 Bridge WebSocket ↔ Arduino
// ================================================================
// Architecture modulaire : chaque fonctionnalité dans son fichier
// 
// RESPONSABILITÉS :
// - WiFi AP : wifi_manager.h/.cpp
// - WebSocket : websocket_handler.h/.cpp
// - Communication Arduino : arduino_comm.h/.cpp
// - Capteurs : sensors.h/.cpp
// - Configuration : config.h
// ================================================================

#include "config.h"
#include "wifi_manager.h"
#include "arduino_comm.h"
#include "websocket_handler.h"
#include "sensors.h"

// ================================================================
// VARIABLES GLOBALES
// ================================================================
unsigned long lastPingTime = 0;

// Timer hardware pour lecture capteurs (non-bloquant)
hw_timer_t *sensorTimer = NULL;
volatile bool sensorReadFlag = false;

// Callback du timer (ISR)
void IRAM_ATTR onSensorTimer() {
  sensorReadFlag = true;  // Flag pour lecture dans loop()
}

// ================================================================
// SETUP
// ================================================================
void setup() {
  Serial.begin(SERIAL_BAUD);
  delay(1000);
  
  Serial.println("========================================");
  Serial.println("  ESP32 FSOmni - v2.0");
  Serial.println("  Architecture Modulaire");
  Serial.println("========================================");
  
  // 1. Initialiser WiFi
  initWiFiAP();
  
  // 2. Initialiser capteurs
  initSensors();
  
  // 3. Initialiser communication Arduino
  initArduinoComm();
  
  // 4. Configurer les callbacks Arduino → WebSocket
  setArduinoRxCallback([](const String& text, int unitId) {
    broadcastLaserRx(text, unitId);
  });
  
  setArduinoTxCallback([](const String& status, int queueLen) {
    broadcastTxStatus(status, queueLen);
  });
  
  setArduinoErrorCallback([](const String& error) {
    broadcastError(error);
  });
  
  // 5. Initialiser WebSocket
  initWebSocket();
  
  // 6. Configurer timer hardware pour lecture capteurs (50ms = 20 Hz - TEMPS RÉEL)
  // Nouvelle API ESP32 Arduino Core 3.x
  sensorTimer = timerBegin(20);  // Fréquence 20 Hz
  timerAttachInterrupt(sensorTimer, &onSensorTimer);  // Attache ISR
  timerAlarm(sensorTimer, 50000, true, 0);  // 50ms, auto-reload, count-up
  
  Serial.println("✅ Timer capteurs démarré (20 Hz - TEMPS RÉEL)");
  Serial.println("✅ ESP32 Bridge prêt");
  Serial.println("========================================");
}

// ================================================================
// LOOP PRINCIPAL
// ================================================================
void loop() {
  // 1. Traiter les messages Arduino
  handleArduinoMessages();
  
  // 2. Maintenance WebSocket
  websocketLoop();
  
  // 3. Ping périodique Arduino (heartbeat)
  if (millis() - lastPingTime > PING_INTERVAL) {
    sendArduinoPing();
    lastPingTime = millis();
  }
  
  // 4. Lecture capteurs déclenchée par timer (NON-BLOQUANT)
  if (sensorReadFlag) {
    sensorReadFlag = false;  // Reset flag
    readSensors();
    broadcastSensorsData();
  }
  
  delay(10);
}
