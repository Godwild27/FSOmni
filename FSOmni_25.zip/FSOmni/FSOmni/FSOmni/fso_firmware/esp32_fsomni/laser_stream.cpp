// ================================================================
// laser_stream.cpp — Implémentation Gestionnaire Streaming Laser
// ================================================================

#include "laser_stream.h"
#include "config.h"
#include <LittleFS.h>

// ================================================================
// VARIABLES GLOBALES
// ================================================================
static QueueHandle_t laserTxQueue = nullptr;
static TaskHandle_t laserTaskHandle = nullptr;
static LaserRxCallback rxCallback = nullptr;
static LaserStats stats = {0};
static bool isPaused = false;
static bool txDoneReceived = false;
static uint32_t currentSequence = 0;

// ================================================================
// TÂCHE FREERTOS - CORE 1 (Non-bloquant)
// ================================================================
void laserStreamTask(void* parameter) {
  LaserChunk chunk;
  unsigned long txStartTime = 0;
  
  Serial.println("[LASER] Tâche streaming démarrée sur Core 1");
  
  while (true) {
    // Vérifier si en pause
    if (isPaused) {
      vTaskDelay(100 / portTICK_PERIOD_MS);
      continue;
    }
    
    // Récupérer le prochain chunk (non-bloquant, timeout 50ms)
    if (xQueueReceive(laserTxQueue, &chunk, 50 / portTICK_PERIOD_MS) == pdTRUE) {
      
      // Préparer la commande JSON pour l'Arduino
      StaticJsonDocument<256> doc;
      doc["cmd"] = "tx";
      
      // Encoder les données en base64 ou hex
      String dataStr = "";
      for (size_t i = 0; i < chunk.length; i++) {
        if (chunk.data[i] >= 32 && chunk.data[i] <= 126) {
          dataStr += (char)chunk.data[i];  // ASCII imprimable
        } else {
          char hex[4];
          sprintf(hex, "\\x%02X", chunk.data[i]);
          dataStr += hex;
        }
      }
      
      doc["text"] = dataStr;
      doc["unit"] = chunk.unitId;
      doc["seq"] = chunk.sequence;
      doc["type"] = (int)chunk.type;
      
      // Envoyer à l'Arduino via Serial2
      txStartTime = millis();
      serializeJson(doc, ARDUINO_SERIAL);
      ARDUINO_SERIAL.println();
      
      Serial.printf("[LASER] → Arduino: seq=%u, len=%u, type=%d\n", 
                    chunk.sequence, chunk.length, chunk.type);
      
      // Attendre tx_done de l'Arduino (avec timeout)
      txDoneReceived = false;
      unsigned long timeout = millis() + LASER_TIMEOUT_MS;
      
      while (!txDoneReceived && millis() < timeout) {
        laserProcessIncoming();  // Traite les messages entrants
        vTaskDelay(10 / portTICK_PERIOD_MS);  // Yield CPU
      }
      
      // Vérifier résultat
      if (txDoneReceived) {
        unsigned long txTime = millis() - txStartTime;
        stats.chunksTotal++;
        stats.bytesTotal += chunk.length;
        stats.avgTxTime = (stats.avgTxTime * (stats.chunksTotal - 1) + txTime) / stats.chunksTotal;
        
        Serial.printf("[LASER] ✓ Chunk %u transmis en %lu ms\n", chunk.sequence, txTime);
      } else {
        stats.chunksFailed++;
        Serial.printf("[LASER] ✗ Timeout chunk %u\n", chunk.sequence);
      }
      
    } else {
      // Pas de chunk en attente, traiter quand même les messages entrants
      laserProcessIncoming();
      vTaskDelay(10 / portTICK_PERIOD_MS);
    }
  }
}

// ================================================================
// TRAITEMENT MESSAGES ENTRANTS ARDUINO
// ================================================================
void laserProcessIncoming() {
  while (ARDUINO_SERIAL.available()) {
    String line = ARDUINO_SERIAL.readStringUntil('\n');
    line.trim();
    
    if (line.length() == 0) continue;
    
    // Parser le JSON
    StaticJsonDocument<512> doc;
    DeserializationError error = deserializeJson(doc, line);
    
    if (error) {
      Serial.printf("[LASER] ✗ Erreur parsing JSON: %s\n", error.c_str());
      continue;
    }
    
    const char* evt = doc["evt"];
    if (evt == nullptr) continue;
    
    // ──────────────────────────────────────────────────────────
    // TX_DONE : Transmission terminée
    // ──────────────────────────────────────────────────────────
    if (strcmp(evt, "tx_done") == 0) {
      txDoneReceived = true;
      uint32_t seq = doc["seq"] | 0;
      Serial.printf("[LASER] ← Arduino: tx_done seq=%u\n", seq);
    }
    
    // ──────────────────────────────────────────────────────────
    // RX : Message reçu par laser
    // ──────────────────────────────────────────────────────────
    else if (strcmp(evt, "rx") == 0) {
      const char* text = doc["text"];
      int unitId = doc["unit"] | 0;
      uint32_t seq = doc["seq"] | 0;
      
      if (text != nullptr) {
        size_t len = strlen(text);
        stats.chunksReceived++;
        stats.bytesReceived += len;
        
        Serial.printf("[LASER] ← RX: unit=%d, seq=%u, len=%u\n", unitId, seq, len);
        
        // Appeler le callback si défini
        if (rxCallback != nullptr) {
          rxCallback((const uint8_t*)text, len, unitId, seq);
        }
      }
    }
    
    // ──────────────────────────────────────────────────────────
    // ERROR : Erreur Arduino
    // ──────────────────────────────────────────────────────────
    else if (strcmp(evt, "error") == 0) {
      const char* msg = doc["msg"];
      Serial.printf("[LASER] ✗ Arduino error: %s\n", msg ? msg : "unknown");
    }
    
    // ──────────────────────────────────────────────────────────
    // PONG : Réponse ping
    // ──────────────────────────────────────────────────────────
    else if (strcmp(evt, "pong") == 0) {
      int freeRam = doc["free_ram"] | 0;
      bool txBusy = doc["tx_busy"] | false;
      bool txReady = doc["tx_ready"] | true;
      Serial.printf("[LASER] ← Pong: RAM=%d, busy=%d, ready=%d\n", freeRam, txBusy, txReady);
    }
    
    // ──────────────────────────────────────────────────────────
    // STATUS : Statut Arduino
    // ──────────────────────────────────────────────────────────
    else if (strcmp(evt, "status") == 0) {
      bool txBusy = doc["tx_busy"] | false;
      bool txReady = doc["tx_ready"] | true;
      int freeRam = doc["free_ram"] | 0;
      uint32_t uptime = doc["uptime"] | 0;
      Serial.printf("[LASER] ← Status: busy=%d, ready=%d, RAM=%d, uptime=%us\n", 
                    txBusy, txReady, freeRam, uptime);
    }
    
    // ──────────────────────────────────────────────────────────
    // READY : Arduino prêt
    // ──────────────────────────────────────────────────────────
    else if (strcmp(evt, "ready") == 0) {
      Serial.println("[LASER] ← Arduino ready!");
    }
  }
}

// ================================================================
// INITIALISATION
// ================================================================
void initLaserStream(LaserRxCallback callback) {
  Serial.println("[LASER] Initialisation du système de streaming...");
  
  // Sauvegarder le callback
  rxCallback = callback;
  
  // Créer la queue FreeRTOS
  laserTxQueue = xQueueCreate(LASER_TX_QUEUE_SIZE, sizeof(LaserChunk));
  if (laserTxQueue == nullptr) {
    Serial.println("[LASER] ✗ Erreur création queue");
    return;
  }
  
  // Initialiser les stats
  memset(&stats, 0, sizeof(stats));
  
  // Créer la tâche sur Core 1
  BaseType_t result = xTaskCreatePinnedToCore(
    laserStreamTask,      // Fonction
    "LaserStream",        // Nom
    8192,                 // Stack size (8KB)
    nullptr,              // Paramètre
    1,                    // Priorité (1 = basse, laisse Core 0 prioritaire)
    &laserTaskHandle,     // Handle
    1                     // Core 1 (Core 0 = WiFi)
  );
  
  if (result != pdPASS) {
    Serial.println("[LASER] ✗ Erreur création tâche");
    return;
  }
  
  Serial.printf("[LASER] ✓ Tâche créée sur Core 1 (queue size: %d chunks)\n", LASER_TX_QUEUE_SIZE);
  
  // Attendre que l'Arduino soit prêt
  delay(1000);
  laserPing();
}

// ================================================================
// API TRANSMISSION
// ================================================================

bool laserSendText(const String& text, int unitId) {
  if (text.length() == 0) return false;
  
  return laserSendData((const uint8_t*)text.c_str(), text.length(), unitId, LASER_TX_TEXT) > 0;
}

uint32_t laserSendData(const uint8_t* data, size_t length, int unitId, LaserTxType type) {
  if (data == nullptr || length == 0) return 0;
  
  uint32_t chunkCount = 0;
  size_t offset = 0;
  
  // Fragmenter en chunks
  while (offset < length) {
    LaserChunk chunk;
    chunk.type = type;
    chunk.unitId = unitId;
    chunk.sequence = currentSequence++;
    chunk.length = min((size_t)LASER_CHUNK_SIZE, length - offset);
    memcpy(chunk.data, data + offset, chunk.length);
    
    // Ajouter à la queue (bloque si queue pleine, timeout 1s)
    if (xQueueSend(laserTxQueue, &chunk, 1000 / portTICK_PERIOD_MS) == pdTRUE) {
      chunkCount++;
      offset += chunk.length;
    } else {
      Serial.printf("[LASER] ✗ Queue pleine, %u chunks perdus\n", (length - offset) / LASER_CHUNK_SIZE);
      break;
    }
  }
  
  Serial.printf("[LASER] %u chunks ajoutés à la queue (total: %u octets)\n", 
                chunkCount, chunkCount * LASER_CHUNK_SIZE);
  
  return chunkCount;
}

bool laserSendFile(const String& filepath, int unitId) {
  File file = LittleFS.open(filepath, "r");  // LittleFS au lieu de SPIFFS
  if (!file) {
    Serial.printf("[LASER] ✗ Impossible d'ouvrir %s\n", filepath.c_str());
    return false;
  }
  
  size_t fileSize = file.size();
  Serial.printf("[LASER] Streaming fichier %s (%u octets)...\n", filepath.c_str(), fileSize);
  
  uint8_t buffer[LASER_CHUNK_SIZE];
  uint32_t chunkCount = 0;
  
  while (file.available()) {
    size_t len = file.read(buffer, LASER_CHUNK_SIZE);
    if (len > 0) {
      LaserChunk chunk;
      chunk.type = LASER_TX_FILE;
      chunk.unitId = unitId;
      chunk.sequence = currentSequence++;
      chunk.length = len;
      memcpy(chunk.data, buffer, len);
      
      if (xQueueSend(laserTxQueue, &chunk, portMAX_DELAY) == pdTRUE) {
        chunkCount++;
      }
    }
  }
  
  file.close();
  Serial.printf("[LASER] ✓ Fichier %s fragmenté en %u chunks\n", filepath.c_str(), chunkCount);
  
  return true;
}

// ================================================================
// CONTRÔLE
// ================================================================

void laserStopTransmission() {
  Serial.println("[LASER] Arrêt transmission et vidage queue");
  xQueueReset(laserTxQueue);
  currentSequence = 0;
}

void laserPauseTransmission() {
  Serial.println("[LASER] Pause transmission");
  isPaused = true;
}

void laserResumeTransmission() {
  Serial.println("[LASER] Reprise transmission");
  isPaused = false;
}

// ================================================================
// STATISTIQUES
// ================================================================

LaserStats laserGetStats() {
  stats.isBusy = (uxQueueMessagesWaiting(laserTxQueue) > 0);
  return stats;
}

void laserResetStats() {
  memset(&stats, 0, sizeof(stats));
  Serial.println("[LASER] Stats réinitialisées");
}

bool laserIsBusy() {
  return uxQueueMessagesWaiting(laserTxQueue) > 0;
}

uint32_t laserGetQueueLength() {
  return uxQueueMessagesWaiting(laserTxQueue);
}

// ================================================================
// COMMANDES ARDUINO
// ================================================================

bool laserPing() {
  StaticJsonDocument<64> doc;
  doc["cmd"] = "ping";
  serializeJson(doc, ARDUINO_SERIAL);
  ARDUINO_SERIAL.println();
  
  Serial.println("[LASER] → Ping Arduino...");
  
  // Attendre pong (timeout 1s)
  unsigned long timeout = millis() + 1000;
  while (millis() < timeout) {
    laserProcessIncoming();
    delay(10);
  }
  
  return true;  // TODO: Vérifier si pong reçu
}

void laserRequestStatus() {
  StaticJsonDocument<64> doc;
  doc["cmd"] = "status";
  serializeJson(doc, ARDUINO_SERIAL);
  ARDUINO_SERIAL.println();
  
  Serial.println("[LASER] → Request status");
}

