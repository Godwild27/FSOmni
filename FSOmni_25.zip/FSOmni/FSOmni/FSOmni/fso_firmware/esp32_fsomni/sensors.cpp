// ================================================================
// sensors.cpp — Implémentation capteurs
// ================================================================

#include "sensors.h"
#include <ArduinoJson.h>
#include <Wire.h>

// Bibliothèques des capteurs
#include <Adafruit_BMP085.h>    // BMP180
#include <Adafruit_BMP280.h>    // BMP280
#include <BH1750.h>             // BH1750 (luminosité)
#include <Adafruit_MPU6050.h>   // MPU6050 (accéléromètre + gyroscope)
#include <Adafruit_Sensor.h>    // Bibliothèque unifiée

// ================================================================
// CONFIGURATION PINS I2C (broches GPIO personnalisées)
// ================================================================
// Tu peux utiliser n'importe quels GPIO disponibles !
// Exemples :
//   - GPIO 21, 22 (défaut hardware I2C)
//   - GPIO 16, 17 (si utilisé pour Arduino Serial)
//   - GPIO 25, 26 (DAC disponibles)
//   - GPIO 32, 33 (ADC disponibles)
// ================================================================
#define I2C_SDA 4     // ⬅️ CHANGE ICI pour SDA
#define I2C_SCL 5     // ⬅️ CHANGE ICI pour SCL

// ================================================================
// TYPE DE CAPTEUR DÉTECTÉ
// ================================================================
enum BMP_Type {
  BMP_NONE,
  BMP_180,
  BMP_280
};

// ================================================================
// VARIABLES GLOBALES
// ================================================================
SensorData currentSensorData = {
  0.0, 0.0, 0.0,           // temp, pressure, altitude
  0.0,                      // luminosity
  0.0, 0.0, 0.0,           // accelX, accelY, accelZ
  0.0, 0.0, 0.0,           // gyroX, gyroY, gyroZ
  0.0,                      // vibration
  0.0,                      // attenuation
  false, 0                  // valid, timestamp
};

// Instances des capteurs
Adafruit_BMP085 bmp180;
Adafruit_BMP280 bmp280;
BH1750 lightMeter;
Adafruit_MPU6050 mpu;

BMP_Type activeBMP = BMP_NONE;
bool bh1750Active = false;
bool mpu6050Active = false;

// ================================================================
// INITIALISATION
// ================================================================
void initSensors() {
  Serial.println("========================================");
  Serial.println("Initialisation des capteurs I2C");
  Serial.println("========================================");
  
  // ──────────────────────────────────────────────────────────
  // INITIALISER I2C sur GPIO personnalisés
  // ──────────────────────────────────────────────────────────
  Wire.begin(I2C_SDA, I2C_SCL);
  Wire.setClock(100000);  // 100 kHz (standard I2C)
  delay(100);
  
  Serial.printf("I2C initialisé : SDA=GPIO%d, SCL=GPIO%d\n", I2C_SDA, I2C_SCL);
  
  // ──────────────────────────────────────────────────────────
  // 1. DÉTECTION BMP280 ou BMP180 (Température + Pression)
  // ──────────────────────────────────────────────────────────
  Serial.println("\n🔍 Détection BMP280/BMP180...");
  
  if (bmp280.begin(0x76)) {
    Serial.println("✅ BMP280 détecté à l'adresse 0x76");
    activeBMP = BMP_280;
    
    // Configuration optimale
    bmp280.setSampling(Adafruit_BMP280::MODE_NORMAL,
                       Adafruit_BMP280::SAMPLING_X2,
                       Adafruit_BMP280::SAMPLING_X16,
                       Adafruit_BMP280::FILTER_X16,
                       Adafruit_BMP280::STANDBY_MS_500);
  } 
  else if (bmp280.begin(0x77)) {
    Serial.println("✅ BMP280 détecté à l'adresse 0x77");
    activeBMP = BMP_280;
    bmp280.setSampling(Adafruit_BMP280::MODE_NORMAL,
                       Adafruit_BMP280::SAMPLING_X2,
                       Adafruit_BMP280::SAMPLING_X16,
                       Adafruit_BMP280::FILTER_X16,
                       Adafruit_BMP280::STANDBY_MS_500);
  }
  else if (bmp180.begin()) {
    Serial.println("✅ BMP180 détecté");
    activeBMP = BMP_180;
  }
  else {
    Serial.println("⚠️  Aucun BMP180/BMP280 détecté");
    activeBMP = BMP_NONE;
  }
  
  // ──────────────────────────────────────────────────────────
  // 2. DÉTECTION BH1750 (Luminosité)
  // ──────────────────────────────────────────────────────────
  Serial.println("\n🔍 Détection BH1750...");
  
  // Tester d'abord l'adresse 0x23 (ADDR → GND, défaut)
  if (lightMeter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE, 0x23)) {
    Serial.println("✅ BH1750 détecté à l'adresse 0x23");
    bh1750Active = true;
  }
  // Sinon tester l'adresse 0x5C (ADDR → VCC)
  else if (lightMeter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE, 0x5C)) {
    Serial.println("✅ BH1750 détecté à l'adresse 0x5C");
    bh1750Active = true;
  }
  else {
    Serial.println("⚠️  BH1750 non détecté (testé 0x23 et 0x5C)");
    Serial.println("   → Vérifier câblage et résistances pull-up");
    bh1750Active = false;
  }
  
  // ──────────────────────────────────────────────────────────
  // 3. DÉTECTION MPU6050 (Accéléromètre + Gyroscope)
  // ──────────────────────────────────────────────────────────
  Serial.println("\n🔍 Détection MPU6050...");
  
  // La bibliothèque Adafruit teste automatiquement 0x68 et 0x69
  if (mpu.begin(0x68)) {
    Serial.println("✅ MPU6050 détecté à l'adresse 0x68");
    mpu6050Active = true;
    
    // Configuration MPU6050
    mpu.setAccelerometerRange(MPU6050_RANGE_8_G);      // ±8g
    mpu.setGyroRange(MPU6050_RANGE_500_DEG);           // ±500°/s
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);        // Filtre 21Hz
    
    Serial.println("  Configuration: ±8g, ±500°/s, filtre 21Hz");
  }
  else if (mpu.begin(0x69)) {
    Serial.println("✅ MPU6050 détecté à l'adresse 0x69");
    mpu6050Active = true;
    
    // Configuration MPU6050
    mpu.setAccelerometerRange(MPU6050_RANGE_8_G);      // ±8g
    mpu.setGyroRange(MPU6050_RANGE_500_DEG);           // ±500°/s
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);        // Filtre 21Hz
    
    Serial.println("  Configuration: ±8g, ±500°/s, filtre 21Hz");
  }
  else {
    Serial.println("⚠️  MPU6050 non détecté (testé 0x68 et 0x69)");
    mpu6050Active = false;
  }
  
  // ──────────────────────────────────────────────────────────
  // LECTURE INITIALE
  // ──────────────────────────────────────────────────────────
  Serial.println("\n========================================");
  readSensors();
  Serial.println("✅ Capteurs initialisés");
  Serial.println("========================================");
}

// ================================================================
// LECTURE DES CAPTEURS
// ================================================================
void readSensors() {
  currentSensorData.temperature = readTemperature();
  currentSensorData.pressure = readPressure();
  currentSensorData.altitude = readAltitude();
  currentSensorData.luminosity = readLuminosity();
  
  readAccelerometer(currentSensorData.accelX, 
                    currentSensorData.accelY, 
                    currentSensorData.accelZ);
  
  readGyroscope(currentSensorData.gyroX, 
                currentSensorData.gyroY, 
                currentSensorData.gyroZ);
  
  currentSensorData.vibration = detectVibration();
  currentSensorData.attenuation = calculateAttenuation();
  currentSensorData.timestamp = millis();
  currentSensorData.valid = true;
  
  Serial.println("\n📊 LECTURE CAPTEURS:");
  Serial.printf("  Température  : %.1f °C\n", currentSensorData.temperature);
  Serial.printf("  Pression     : %.1f hPa\n", currentSensorData.pressure);
  Serial.printf("  Altitude     : %.1f m\n", currentSensorData.altitude);
  Serial.printf("  Luminosité   : %.1f lux\n", currentSensorData.luminosity);
  Serial.printf("  Accél (X,Y,Z): %.2f, %.2f, %.2f g\n", 
                currentSensorData.accelX, 
                currentSensorData.accelY, 
                currentSensorData.accelZ);
  Serial.printf("  Gyro (X,Y,Z) : %.1f, %.1f, %.1f °/s\n", 
                currentSensorData.gyroX, 
                currentSensorData.gyroY, 
                currentSensorData.gyroZ);
  Serial.printf("  Vibration    : %.1f %%\n", currentSensorData.vibration);
  Serial.printf("  Atténuation  : %.2f dB/km\n", currentSensorData.attenuation);
}

// ================================================================
// LUMINOSITÉ (BH1750)
// ================================================================
float readLuminosity() {
  if (bh1750Active) {
    float lux = lightMeter.readLightLevel();
    if (!isnan(lux) && lux >= 0) {
      return lux;
    }
  }
  
  // Fallback : valeur par défaut
  return 5000.0;
}

// ================================================================
// TEMPÉRATURE (BMP180/BMP280)
// ================================================================
float readTemperature() {
  if (activeBMP == BMP_180) {
    float tempC = bmp180.readTemperature();
    if (!isnan(tempC)) {
      return tempC;
    }
  } 
  else if (activeBMP == BMP_280) {
    float tempC = bmp280.readTemperature();
    if (!isnan(tempC)) {
      return tempC;
    }
  }
  
  // Fallback : température par défaut
  return 25.0;
}

// ================================================================
// PRESSION (BMP180/BMP280)
// ================================================================
float readPressure() {
  if (activeBMP == BMP_180) {
    float pressurePa = bmp180.readPressure();
    if (!isnan(pressurePa)) {
      return pressurePa / 100.0;  // Pa → hPa
    }
  } 
  else if (activeBMP == BMP_280) {
    float pressurePa = bmp280.readPressure();
    if (!isnan(pressurePa)) {
      return pressurePa / 100.0;  // Pa → hPa
    }
  }
  
  // Fallback : pression au niveau de la mer
  return 1013.25;
}

// ================================================================
// ALTITUDE (BMP180/BMP280)
// ================================================================
float readAltitude() {
  float seaLevelPressure = 1013.25;  // hPa
  
  if (activeBMP == BMP_180) {
    return bmp180.readAltitude(seaLevelPressure * 100);  // hPa → Pa
  } 
  else if (activeBMP == BMP_280) {
    return bmp280.readAltitude(seaLevelPressure);
  }
  
  // Fallback
  return 0.0;
}

// ================================================================
// ACCÉLÉROMÈTRE (MPU6050)
// ================================================================
void readAccelerometer(float& x, float& y, float& z) {
  if (mpu6050Active) {
    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);
    
    x = a.acceleration.x / 9.81;  // m/s² → g
    y = a.acceleration.y / 9.81;
    z = a.acceleration.z / 9.81;
  } else {
    x = y = 0.0;
    z = 1.0;  // Gravité terrestre
  }
}

// ================================================================
// GYROSCOPE (MPU6050)
// ================================================================
void readGyroscope(float& x, float& y, float& z) {
  if (mpu6050Active) {
    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);
    
    x = g.gyro.x * 57.2958;  // rad/s → °/s
    y = g.gyro.y * 57.2958;
    z = g.gyro.z * 57.2958;
  } else {
    x = y = z = 0.0;
  }
}

// ================================================================
// DÉTECTION DE VIBRATION (MPU6050)
// ================================================================
float detectVibration() {
  if (!mpu6050Active) return 0.0;
  
  float ax, ay, az;
  readAccelerometer(ax, ay, az);
  
  // Calculer la magnitude de l'accélération (sans gravité)
  float magnitude = sqrt(ax*ax + ay*ay + (az-1.0)*(az-1.0));
  
  // Convertir en pourcentage (0-100)
  // Seuils : 0.1g = 10%, 1.0g = 100%
  float vibrationPercent = magnitude * 100.0;
  
  if (vibrationPercent > 100.0) vibrationPercent = 100.0;
  if (vibrationPercent < 0.0) vibrationPercent = 0.0;
  
  return vibrationPercent;
}

// ================================================================
// ATTÉNUATION ATMOSPHÉRIQUE
// ================================================================
float calculateAttenuation() {
  // Formule simplifiée de l'atténuation atmosphérique pour laser
  // Basée sur température, pression et humidité
  
  float temp = currentSensorData.temperature;
  float pressure = currentSensorData.pressure;
  
  // Formule empirique (dB/km)
  // L'atténuation augmente avec l'humidité et diminue avec la pression
  
  // Atténuation de base (conditions idéales)
  float baseAttenuation = 0.2;  // dB/km
  
  // Facteur température (atténuation augmente avec chaleur)
  float tempFactor = 1.0 + (temp - 20.0) * 0.01;
  
  // Facteur pression (atténuation diminue avec haute pression)
  float pressureFactor = 1013.25 / pressure;
  
  // Calcul final
  float attenuation = baseAttenuation * tempFactor * pressureFactor;
  
  // Limiter entre 0.1 et 5.0 dB/km
  if (attenuation < 0.1) attenuation = 0.1;
  if (attenuation > 5.0) attenuation = 5.0;
  
  return attenuation;
}

// ================================================================
// UTILITAIRES
// ================================================================
bool areSensorsDataFresh(unsigned long maxAgeMs) {
  if (!currentSensorData.valid) return false;
  return (millis() - currentSensorData.timestamp) < maxAgeMs;
}

String getSensorsJSON() {
  StaticJsonDocument<512> doc;
  doc["type"] = "sensors";
  
  // Température et pression
  doc["temperature"] = currentSensorData.temperature;
  doc["pressure"] = currentSensorData.pressure;
  doc["altitude"] = currentSensorData.altitude;
  
  // Luminosité
  doc["luminosity"] = currentSensorData.luminosity;
  
  // Accéléromètre
  JsonObject accel = doc.createNestedObject("accelerometer");
  accel["x"] = currentSensorData.accelX;
  accel["y"] = currentSensorData.accelY;
  accel["z"] = currentSensorData.accelZ;
  
  // Gyroscope
  JsonObject gyro = doc.createNestedObject("gyroscope");
  gyro["x"] = currentSensorData.gyroX;
  gyro["y"] = currentSensorData.gyroY;
  gyro["z"] = currentSensorData.gyroZ;
  
  // Vibration et atténuation
  doc["vibration"] = currentSensorData.vibration;
  doc["attenuation"] = currentSensorData.attenuation;
  doc["timestamp"] = currentSensorData.timestamp;
  
  String json;
  serializeJson(doc, json);
  return json;
}
