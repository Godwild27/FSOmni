// ================================================================
// config.h — Configuration ESP32 Bridge
// ================================================================

#ifndef CONFIG_H
#define CONFIG_H

// ================================================================
// CONFIGURATION WiFi ACCESS POINT
// ================================================================
#define WIFI_SSID "FSOmni"
#define WIFI_PASSWORD "fsomni2026"
#define WIFI_CHANNEL 6
#define MAX_CLIENTS 4

// ================================================================
// CONFIGURATION WEBSOCKET
// ================================================================
#define WS_PORT 8080

// ================================================================
// CONFIGURATION COMMUNICATION ARDUINO
// ================================================================
#define ARDUINO_SERIAL Serial2
#define ARDUINO_BAUD 115200
#define ARDUINO_RX_PIN 16
#define ARDUINO_TX_PIN 17

// ================================================================
// CONFIGURATION GÉNÉRALE
// ================================================================
#define SERIAL_BAUD 115200
#define PING_INTERVAL 30000  // Ping Arduino toutes les 30s

#endif
