// ================================================================
// websocket_handler.cpp — Implémentation WebSocket
// ================================================================

#include "websocket_handler.h"
#include "arduino_comm.h"
#include "wifi_manager.h"
#include "sensors.h"

AsyncWebServer server(WS_PORT);
AsyncWebSocket ws("/");

// ================================================================
// DÉCLARATION FONCTION
// ================================================================
void onWsEvent(AsyncWebSocket *server, AsyncWebSocketClient *client,
               AwsEventType type, void *arg, uint8_t *data, size_t len);

// ================================================================
// INITIALISATION
// ================================================================
void initWebSocket() {
  ws.onEvent(onWsEvent);
  server.addHandler(&ws);
  
  // Page web d'accueil
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
    String html = "<html><head><meta charset='utf-8'></head><body>";
    html += "<h1>ESP32 FSOmni Bridge v2.0</h1>";
    html += "<p><strong>Serveur WebSocket actif</strong></p>";
    html += "<p>ws://" + getAPIP().toString() + ":" + String(WS_PORT) + "/</p>";
    html += "<p>Architecture modulaire ESP32 + Arduino</p>";
    html += "</body></html>";
    request->send(200, "text/html", html);
  });
  
  server.begin();
  Serial.printf("✅ WebSocket : ws://%s:%d/\n", getAPIP().toString().c_str(), WS_PORT);
}

// ================================================================
// GESTION ÉVÉNEMENTS WEBSOCKET
// ================================================================
void onWsEvent(AsyncWebSocket *server, AsyncWebSocketClient *client,
               AwsEventType type, void *arg, uint8_t *data, size_t len) {
  
  switch(type) {
    case WS_EVT_CONNECT:
      Serial.printf("✅ Client WS connecté [ID:%u] %s\n",
                    client->id(), client->remoteIP().toString().c_str());
      
      // Message de bienvenue
      {
        StaticJsonDocument<256> doc;
        doc["type"] = "connected";
        doc["message"] = "ESP32 Bridge v2.0";
        doc["device"] = "ESP32-S3";
        doc["firmware_version"] = "2.0.0";
        String msg;
        serializeJson(doc, msg);
        client->text(msg);
      }
      
      // Télémétrie initiale
      {
        StaticJsonDocument<512> doc;
        doc["type"] = "telemetry";
        doc["throughput"] = 9.8;
        doc["ber"] = 1.2e-9;
        doc["rssi"] = -42.0;
        doc["alignment_precision"] = 90.0;
        String msg;
        serializeJson(doc, msg);
        client->text(msg);
      }
      
      sendArduinoStatus();
      break;
    
    case WS_EVT_DISCONNECT:
      Serial.printf("🔌 Client WS déconnecté [ID:%u]\n", client->id());
      break;
    
    case WS_EVT_DATA:
      {
        data[len] = 0;
        String message = String((char*)data);
        
        Serial.printf("📩 WS message [ID:%u]: %s\n", client->id(), message.c_str());
        
        StaticJsonDocument<1024> doc;
        if (deserializeJson(doc, message)) {
          Serial.println("❌ JSON parse error");
          return;
        }
        
        // Type numérique
        if (doc["type"].is<int>()) {
          int typeNum = doc["type"];
          
          // Type 2 : Message laser
          if (typeNum == 2) {
            const char* text = doc["text"];
            int unitId = doc.containsKey("unit_id") ? doc["unit_id"].as<int>() : 0;
            
            Serial.printf("  → TX laser: unit=%d\n", unitId);
            sendLaserTxCommand(String(text), unitId);
          }
          // Type 12 : Ping
          else if (typeNum == 12) {
            StaticJsonDocument<128> resp;
            resp["type"] = 13;
            resp["timestamp"] = millis();
            String msg;
            serializeJson(resp, msg);
            client->text(msg);
          }
        }
        // Type string
        else if (doc["type"].is<const char*>()) {
          const char* msgType = doc["type"];
          
          // Commande servo
          if (strcmp(msgType, "servo") == 0) {
            const char* axis = doc["axis"];
            float value = doc["value"];
            sendServoCommand(String(axis), value);
          }
          // Ping
          else if (strcmp(msgType, "ping") == 0) {
            client->text("{\"type\":\"pong\",\"timestamp\":" + String(millis()) + "}");
          }
        }
      }
      break;
    
    case WS_EVT_PONG:
      Serial.printf("🏓 Pong [ID:%u]\n", client->id());
      break;
    
    case WS_EVT_ERROR:
      Serial.printf("❌ WS error [ID:%u]\n", client->id());
      break;
  }
}

// ================================================================
// BROADCAST VERS CLIENTS
// ================================================================
void broadcastLaserRx(const String& text, int unitId) {
  StaticJsonDocument<512> doc;
  doc["type"] = 2;
  doc["text"] = text;
  doc["unit_id"] = unitId;
  doc["length"] = text.length();
  
  String msg;
  serializeJson(doc, msg);
  ws.textAll(msg);
  
  Serial.println("  ✅ RX broadcasted");
}

void broadcastTxStatus(const String& status, int queueLen) {
  if (status == "tx_started") {
    ws.textAll("{\"type\":10,\"status\":\"tx_started\"}");
  } else if (status == "tx_queued") {
    String msg = "{\"type\":10,\"status\":\"tx_queued\",\"queue_len\":" + String(queueLen) + "}";
    ws.textAll(msg);
  }
}

void broadcastError(const String& error) {
  StaticJsonDocument<256> doc;
  doc["type"] = 99;
  doc["message"] = error;
  
  String msg;
  serializeJson(doc, msg);
  ws.textAll(msg);
}

// ================================================================
// BROADCAST DONNÉES CAPTEURS
// ================================================================
void broadcastSensorsData() {
  StaticJsonDocument<512> doc;
  doc["type"] = "sensors";  // ✅ Cohérent avec sensors.h
  
  // Température et pression
  doc["temperature"] = currentSensorData.temperature;
  doc["pressure"] = currentSensorData.pressure;
  doc["altitude"] = currentSensorData.altitude;
  
  // Luminosité et atténuation
  doc["luminosity"] = currentSensorData.luminosity;
  doc["attenuation"] = currentSensorData.attenuation;
  
  // Accéléromètre
  JsonObject accel = doc.createNestedObject("accelerometer");
  accel["x"] = currentSensorData.accelX;
  accel["y"] = currentSensorData.accelY;
  accel["z"] = currentSensorData.accelZ;
  
  // Gyroscope
  JsonObject gyro = doc.createNestedObject("gyroscope");
  gyro["x"] = currentSensorData.gyroX;
  gyro["y"] = currentSensorData.gyroY;
  gyro["z"] = currentSensorData.gyroZ;
  
  // Vibration (important pour détecter désalignement)
  doc["vibration"] = currentSensorData.vibration;
  
  String msg;
  serializeJson(doc, msg);
  ws.textAll(msg);
  
  Serial.println("  ✅ Données capteurs diffusées");
}

// ================================================================
// BOUCLE DE MAINTENANCE
// ================================================================
void websocketLoop() {
  ws.cleanupClients();
}
