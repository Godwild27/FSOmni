// ================================================================
// arduino_comm.cpp — Implémentation Communication Arduino
// ================================================================

#include "arduino_comm.h"

// État
bool arduinoReady = false;

// Callbacks
ArduinoRxCallback rxCallback = nullptr;
ArduinoTxCallback txCallback = nullptr;
ArduinoErrorCallback errorCallback = nullptr;

// ================================================================
// INITIALISATION
// ================================================================
void initArduinoComm() {
  ARDUINO_SERIAL.begin(ARDUINO_BAUD, SERIAL_8N1, ARDUINO_RX_PIN, ARDUINO_TX_PIN);
  Serial.printf("Communication Arduino : RX=GPIO%d, TX=GPIO%d @ %d baud\n",
                ARDUINO_RX_PIN, ARDUINO_TX_PIN, ARDUINO_BAUD);
}

// ================================================================
// ENVOI DE COMMANDES VERS ARDUINO
// ================================================================
void sendLaserTxCommand(const String& text, int unitId) {
  StaticJsonDocument<512> cmd;
  cmd["cmd"] = "tx";
  cmd["text"] = text;
  cmd["unit"] = unitId;
  
  serializeJson(cmd, ARDUINO_SERIAL);
  ARDUINO_SERIAL.println();
  
  Serial.printf("→ Arduino: TX command (unit=%d, text=\"%s\")\n", unitId, text.c_str());
}

void sendServoCommand(const String& axis, float angle) {
  StaticJsonDocument<128> cmd;
  cmd["cmd"] = "servo";
  cmd["axis"] = axis;
  cmd["angle"] = angle;
  
  serializeJson(cmd, ARDUINO_SERIAL);
  ARDUINO_SERIAL.println();
  
  Serial.printf("→ Arduino: Servo command (axis=%s, angle=%.1f)\n", axis.c_str(), angle);
}

void sendArduinoPing() {
  ARDUINO_SERIAL.println("{\"cmd\":\"ping\"}");
  Serial.println("→ Arduino: Ping");
}

void sendArduinoStatus() {
  ARDUINO_SERIAL.println("{\"cmd\":\"status\"}");
  Serial.println("→ Arduino: Status request");
}

// ================================================================
// RÉCEPTION DES MESSAGES ARDUINO
// ================================================================
void handleArduinoMessages() {
  if (ARDUINO_SERIAL.available()) {
    String jsonMsg = ARDUINO_SERIAL.readStringUntil('\n');
    
    Serial.printf("← Arduino: %s\n", jsonMsg.c_str());
    
    StaticJsonDocument<512> doc;
    DeserializationError error = deserializeJson(doc, jsonMsg);
    
    if (error) {
      Serial.printf("❌ Erreur parsing JSON Arduino : %s\n", error.c_str());
      return;
    }
    
    const char* evt = doc["evt"];
    if (evt == nullptr) {
      Serial.println("⚠️  Message Arduino sans champ 'evt'");
      return;
    }
    
    // ──────────────────────────────────────────────────────────
    // MESSAGE LASER REÇU
    // ──────────────────────────────────────────────────────────
    if (strcmp(evt, "rx") == 0) {
      String text = doc["text"].as<String>();
      int unitId = doc["unit"].as<int>();
      
      Serial.printf("  📥 RX: unit=%d, text=\"%s\"\n", unitId, text.c_str());
      
      if (rxCallback != nullptr) {
        rxCallback(text, unitId);
      }
    }
    
    // ──────────────────────────────────────────────────────────
    // TX DÉMARRÉE / EN QUEUE
    // ──────────────────────────────────────────────────────────
    else if (strcmp(evt, "tx_started") == 0) {
      Serial.println("  ✅ TX démarrée");
      if (txCallback != nullptr) {
        txCallback("tx_started", 0);
      }
    }
    else if (strcmp(evt, "tx_queued") == 0) {
      int queueLen = doc["queue_len"].as<int>();
      Serial.printf("  📬 TX en queue (%d messages)\n", queueLen);
      if (txCallback != nullptr) {
        txCallback("tx_queued", queueLen);
      }
    }
    
    // ──────────────────────────────────────────────────────────
    // ERREUR ARDUINO
    // ──────────────────────────────────────────────────────────
    else if (strcmp(evt, "error") == 0) {
      String errMsg = doc["msg"].as<String>();
      Serial.printf("  ❌ Erreur: %s\n", errMsg.c_str());
      if (errorCallback != nullptr) {
        errorCallback(errMsg);
      }
    }
    
    // ──────────────────────────────────────────────────────────
    // PONG
    // ──────────────────────────────────────────────────────────
    else if (strcmp(evt, "pong") == 0) {
      arduinoReady = true;
      Serial.printf("  🏓 Pong: RAM=%d, TX busy=%d, Queue=%d\n",
                    doc["free_ram"].as<int>(),
                    doc["tx_busy"].as<int>(),
                    doc["queue_len"].as<int>());
    }
    
    // ──────────────────────────────────────────────────────────
    // ARDUINO PRÊT
    // ──────────────────────────────────────────────────────────
    else if (strcmp(evt, "ready") == 0) {
      arduinoReady = true;
      Serial.println("  ✅ Arduino prêt");
    }
    
    // ──────────────────────────────────────────────────────────
    // STATUS
    // ──────────────────────────────────────────────────────────
    else if (strcmp(evt, "status") == 0) {
      Serial.printf("  📊 Status: TX=%d, RX=%d, Queue=%d, RAM=%d\n",
                    doc["tx_busy"].as<int>(),
                    doc["rx_enabled"].as<int>(),
                    doc["queue_len"].as<int>(),
                    doc["free_ram"].as<int>());
    }
  }
}

// ================================================================
// CALLBACKS
// ================================================================
void setArduinoRxCallback(ArduinoRxCallback callback) {
  rxCallback = callback;
}

void setArduinoTxCallback(ArduinoTxCallback callback) {
  txCallback = callback;
}

void setArduinoErrorCallback(ArduinoErrorCallback callback) {
  errorCallback = callback;
}
