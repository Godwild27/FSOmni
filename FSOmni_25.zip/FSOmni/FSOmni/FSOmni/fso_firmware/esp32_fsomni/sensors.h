// ================================================================
// sensors.h — Gestion des capteurs atmosphériques
// ================================================================

#ifndef SENSORS_H
#define SENSORS_H

#include <Arduino.h>

// ================================================================
// STRUCTURE DE DONNÉES CAPTEURS
// ================================================================
struct SensorData {
  // BMP180/BMP280 - Température et Pression
  float temperature;     // Température (°C)
  float pressure;        // Pression atmosphérique (hPa)
  float altitude;        // Altitude estimée (m)
  
  // BH1750 - Luminosité
  float luminosity;      // Luminosité ambiante (lux)
  
  // MPU6050 - Accéléromètre et Gyroscope
  float accelX;          // Accélération X (g)
  float accelY;          // Accélération Y (g)
  float accelZ;          // Accélération Z (g)
  float gyroX;           // Vitesse angulaire X (°/s)
  float gyroY;           // Vitesse angulaire Y (°/s)
  float gyroZ;           // Vitesse angulaire Z (°/s)
  float vibration;       // Niveau de vibration détecté (0-100)
  
  // Calculs dérivés
  float attenuation;     // Atténuation atmosphérique (dB/km)
  
  // Métadonnées
  bool valid;            // Données valides
  unsigned long timestamp; // Timestamp de la dernière lecture
};

// ================================================================
// VARIABLES GLOBALES
// ================================================================
extern SensorData currentSensorData;

// ================================================================
// INITIALISATION
// ================================================================
/**
 * Initialise les capteurs (I2C, GPIO, etc.)
 */
void initSensors();

// ================================================================
// LECTURE DES CAPTEURS
// ================================================================
/**
 * Lit tous les capteurs et met à jour currentSensorData
 */
void readSensors();

/**
 * Lecture de la température
 * @return Température en °C
 */
float readTemperature();

/**
 * Lecture de la pression
 * @return Pression en hPa (hectopascal)
 */
float readPressure();

/**
 * Lecture de l'altitude
 * @return Altitude en mètres
 */
float readAltitude();

/**
 * Lecture de la luminosité (BH1750)
 * @return Luminosité en lux
 */
float readLuminosity();

/**
 * Lecture de l'accéléromètre (MPU6050)
 * @param x, y, z [OUT] Accélérations en g
 */
void readAccelerometer(float& x, float& y, float& z);

/**
 * Lecture du gyroscope (MPU6050)
 * @param x, y, z [OUT] Vitesses angulaires en °/s
 */
void readGyroscope(float& x, float& y, float& z);

/**
 * Détection du niveau de vibration
 * @return Niveau de vibration (0-100)
 */
float detectVibration();

/**
 * Calcul de l'atténuation atmosphérique
 * @return Atténuation en dB/km
 */
float calculateAttenuation();

// ================================================================
// UTILITAIRES
// ================================================================
/**
 * Vérifie si les données capteurs sont récentes
 * @param maxAgeMs Age maximum en millisecondes
 * @return true si les données sont récentes
 */
bool areSensorsDataFresh(unsigned long maxAgeMs);

/**
 * Obtenir les données capteurs sous forme JSON
 * @return String JSON
 */
String getSensorsJSON();

#endif
