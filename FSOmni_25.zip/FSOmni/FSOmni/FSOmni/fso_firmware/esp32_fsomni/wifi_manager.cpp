// ================================================================
// wifi_manager.cpp — Implémentation WiFi
// ================================================================

#include "wifi_manager.h"

void initWiFiAP() {
  Serial.println("Configuration du point d'accès WiFi...");
  
  WiFi.mode(WIFI_AP);
  WiFi.softAP(WIFI_SSID, WIFI_PASSWORD, WIFI_CHANNEL, 0, MAX_CLIENTS);
  
  IPAddress IP = WiFi.softAPIP();
  Serial.print("  SSID : ");        Serial.println(WIFI_SSID);
  Serial.print("  Mot de passe : "); Serial.println(WIFI_PASSWORD);
  Serial.print("  Adresse IP : ");   Serial.println(IP);
  Serial.println("✅ WiFi AP démarré");
}

IPAddress getAPIP() {
  return WiFi.softAPIP();
}
