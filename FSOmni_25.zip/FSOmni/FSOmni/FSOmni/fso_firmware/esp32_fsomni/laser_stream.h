// ================================================================
// laser_stream.h — Gestionnaire Streaming Laser (ESP32 Dual-Core)
// ================================================================
// Gère la communication avec l'Arduino Uno pour transmission laser
// - Tâche dédiée sur Core 1 (non-bloquant)
// - Fragmentation automatique des messages/fichiers
// - Flow control via tx_done de l'Arduino
// - Core 0 reste libre pour WiFi/WebSocket/Capteurs
// ================================================================

#ifndef LASER_STREAM_H
#define LASER_STREAM_H

#include <Arduino.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <ArduinoJson.h>

// ================================================================
// CONFIGURATION
// ================================================================
#define LASER_CHUNK_SIZE        80      // Taille chunk données utiles (octets)
#define LASER_TX_QUEUE_SIZE     50      // Nombre max de chunks en attente
#define LASER_TIMEOUT_MS        5000    // Timeout attente tx_done (ms)

// ================================================================
// TYPES DE DONNÉES
// ================================================================

// Type de transmission
enum LaserTxType {
  LASER_TX_TEXT = 0,      // Message texte simple
  LASER_TX_FILE = 1,      // Chunk de fichier
  LASER_TX_AUDIO = 2      // Chunk audio
};

// Chunk à transmettre
struct LaserChunk {
  LaserTxType type;
  uint8_t data[LASER_CHUNK_SIZE];
  size_t length;
  uint32_t sequence;      // Numéro de séquence
  int unitId;             // ID unité destinataire
};

// Statistiques streaming
struct LaserStats {
  uint32_t chunksTotal;       // Nombre total de chunks envoyés
  uint32_t chunksFailed;      // Nombre de chunks échoués
  uint32_t chunksReceived;    // Nombre de chunks reçus
  uint32_t bytesTotal;        // Octets totaux transmis
  uint32_t bytesReceived;     // Octets totaux reçus
  float avgTxTime;            // Temps moyen transmission (ms)
  bool isBusy;                // Transmission en cours
};

// Callback pour réception laser
typedef void (*LaserRxCallback)(const uint8_t* data, size_t len, int unitId, uint32_t seq);

// ================================================================
// INITIALISATION
// ================================================================

/**
 * Initialise le système de streaming laser
 * Crée la tâche FreeRTOS sur Core 1
 * 
 * @param rxCallback Fonction appelée à la réception d'un message laser
 */
void initLaserStream(LaserRxCallback rxCallback = nullptr);

// ================================================================
// API TRANSMISSION (Non-bloquant)
// ================================================================

/**
 * Envoie un message texte par laser (non-bloquant)
 * Fragmente automatiquement si > LASER_CHUNK_SIZE
 * 
 * @param text Message à envoyer
 * @param unitId ID de l'unité destinataire (0-999)
 * @return true si ajouté à la queue, false si queue pleine
 */
bool laserSendText(const String& text, int unitId = 0);

/**
 * Envoie des données binaires par laser (non-bloquant)
 * Fragmente automatiquement si nécessaire
 * 
 * @param data Données à envoyer
 * @param length Taille des données
 * @param unitId ID de l'unité destinataire
 * @param type Type de transmission (TEXT/FILE/AUDIO)
 * @return Nombre de chunks ajoutés à la queue (0 si échec)
 */
uint32_t laserSendData(const uint8_t* data, size_t length, int unitId = 0, LaserTxType type = LASER_TX_TEXT);

/**
 * Envoie un fichier par laser en streaming (non-bloquant)
 * Lecture et envoi chunk par chunk en arrière-plan
 * 
 * @param filepath Chemin du fichier (ex: "/data/file.txt")
 * @param unitId ID de l'unité destinataire
 * @return true si démarré avec succès
 */
bool laserSendFile(const String& filepath, int unitId = 0);

// ================================================================
// CONTRÔLE
// ================================================================

/**
 * Arrête la transmission en cours et vide la queue
 */
void laserStopTransmission();

/**
 * Met en pause la transmission (garde la queue)
 */
void laserPauseTransmission();

/**
 * Reprend la transmission
 */
void laserResumeTransmission();

// ================================================================
// STATISTIQUES
// ================================================================

/**
 * Obtient les statistiques de streaming
 * @return Structure LaserStats avec les statistiques
 */
LaserStats laserGetStats();

/**
 * Réinitialise les statistiques
 */
void laserResetStats();

/**
 * Vérifie si une transmission est en cours
 * @return true si chunks en attente ou transmission active
 */
bool laserIsBusy();

/**
 * Obtient le nombre de chunks en attente dans la queue
 * @return Nombre de chunks
 */
uint32_t laserGetQueueLength();

// ================================================================
// COMMANDES ARDUINO
// ================================================================

/**
 * Envoie une commande ping à l'Arduino
 * @return true si pong reçu dans les 1000ms
 */
bool laserPing();

/**
 * Demande le statut de l'Arduino
 */
void laserRequestStatus();

// ================================================================
// RÉCEPTION (appelé automatiquement par la tâche)
// ================================================================

/**
 * Traite les messages entrants de l'Arduino (usage interne)
 * Appelé automatiquement par la tâche de streaming
 */
void laserProcessIncoming();

#endif

