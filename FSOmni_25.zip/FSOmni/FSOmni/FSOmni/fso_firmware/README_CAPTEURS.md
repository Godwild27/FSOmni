# 📡 Guide des Capteurs FSO

## 🎯 Vue d'ensemble

Le système FSO utilise **3 capteurs I2C** pour surveiller l'environnement et détecter les problèmes d'alignement laser :

| Capteur | Mesure | Utilité pour FSO |
|---------|--------|------------------|
| **BMP180/BMP280** | Température + Pression | Calcul atténuation atmosphérique |
| **BH1750** | Luminosité | Détection conditions lumineuses affectant le laser |
| **MPU6050** | Accéléromètre + Gyroscope | Détection vibrations désalignant le laser |

---

## ✅ RÉSULTATS DU SCAN I2C

### Capteurs Détectés (Confirmés par i2c_scanner - testés un par un)

```
✅ 0x68 (104) - MPU6050 (Accéléromètre/Gyroscope) - STABLE ✓
✅ 0x76 (118) - BMP280 (Température/Pression) - STABLE ✓
✅ 0x77 (119) - BMP180 (Température/Pression) - STABLE ✓
✅ 0x23 (35)  - BH1750 (Luminosité) - STABLE ✓
```

### � Configuration matérielle validée :

Tu possèdes **4 capteurs fonctionnels** :
- ✅ **BMP280** à l'adresse **0x76** (pin SDO → GND)
- ✅ **BMP180** à l'adresse **0x77** 
- ✅ **MPU6050** à l'adresse **0x68** (pin AD0 → GND)
- ✅ **BH1750** à l'adresse **0x23** (pin ADDR → GND)

### ⚠️ NOTE IMPORTANTE :

Tu as **2 capteurs de température/pression** (BMP180 + BMP280) mais avec des adresses différentes, tu **peux les utiliser tous les deux en même temps** si besoin !

Le code `sensors.cpp` détectera automatiquement celui qui est branché et l'utilisera.

**Recommandation** : Utilise le **BMP280** (plus récent, plus précis) pour ton projet FSO.

---

## 🔌 Câblage I2C (ESP32)

### Broches I2C utilisées

**Configuration actuelle dans le code** :
```
SDA (Données)  : GPIO 4
SCL (Horloge)  : GPIO 5
```

**Ces GPIO sont parfaits pour I2C !** ✅

### 🔧 Tu peux changer ces GPIO !

L'ESP32 supporte l'I2C sur **presque n'importe quel GPIO**. Pour utiliser d'autres pins :

**Modifie dans `sensors.cpp` :**
```cpp
#define I2C_SDA 4     // Change 4 → autre GPIO
#define I2C_SCL 5     // Change 5 → autre GPIO
```

**GPIO recommandés :** 4, 5, 12, 13, 14, 15, 16, 17, 18, 19, 21, 22, 23, 25, 26, 27, 32, 33

**GPIO à éviter :** 0, 1, 3, 6-11, 34-39

**Configuration actuelle : GPIO 4 (SDA) + GPIO 5 (SCL)** ✅

### Schéma de connexion

```
ESP32-S3                    Capteurs
┌──────────┐               ┌──────────┐
│          │               │ BMP180/  │
│  GPIO 4  ├───────────────┤ BMP280   │
│  (SDA)   ├───────┬───────┤          │
│          │       │       └──────────┘
│  GPIO 5  ├───────┼───────┐
│  (SCL)   ├───────┼───────┤ BH1750   │
│          │       │       │          │
│  3.3V    ├───────┼───────┤          │
│          │       │       └──────────┘
│  GND     ├───────┼───────┐
│          │       │       │ MPU6050  │
└──────────┘       └───────┤          │
                           │          │
                           └──────────┘
```

### Connexions détaillées

#### BMP180 / BMP280
| Pin Capteur | Pin ESP32 | Description |
|-------------|-----------|-------------|
| VCC | 3.3V | Alimentation |
| GND | GND | Masse |
| SDA | GPIO 4 | Données I2C |
| SCL | GPIO 5 | Horloge I2C |

**Adresse I2C** : `0x76` ou `0x77`

#### BH1750
| Pin Capteur | Pin ESP32 | Description |
|-------------|-----------|-------------|
| VCC | 3.3V | Alimentation |
| GND | GND | Masse |
| SDA | GPIO 4 | Données I2C |
| SCL | GPIO 5 | Horloge I2C |
| ADDR | GND ou 3.3V | Sélection adresse (optionnel) |

**Adresse I2C** : 
- `0x23` si ADDR → GND (défaut)
- `0x5C` si ADDR → 3.3V

#### MPU6050
| Pin Capteur | Pin ESP32 | Description |
|-------------|-----------|-------------|
| VCC | 3.3V | Alimentation |
| GND | GND | Masse |
| SDA | GPIO 4 | Données I2C |
| SCL | GPIO 5 | Horloge I2C |
| AD0 | GND ou 3.3V | Sélection adresse (optionnel) |

**Adresse I2C** : 
- `0x68` si AD0 → GND (défaut)
- `0x69` si AD0 → 3.3V

---

## 📚 Bibliothèques Requises

### PlatformIO (`platformio.ini`)

```ini
[env:esp32s3]
platform = espressif32
board = esp32-s3-devkitc-1
framework = arduino

lib_deps = 
    adafruit/Adafruit BMP085 Library@^1.2.2      ; BMP180
    adafruit/Adafruit BMP280 Library@^2.6.8      ; BMP280
    claws/BH1750@^1.3.0                          ; BH1750
    adafruit/Adafruit MPU6050@^2.2.4             ; MPU6050
    adafruit/Adafruit Unified Sensor@^1.1.14     ; Dépendance commune
```

### Arduino IDE

Aller dans **Croquis → Inclure une bibliothèque → Gérer les bibliothèques** et installer :
1. `Adafruit BMP085 Library` (pour BMP180)
2. `Adafruit BMP280 Library` (pour BMP280)
3. `BH1750` par Christopher Laws
4. `Adafruit MPU6050`
5. `Adafruit Unified Sensor`

---

## 🧪 Test des Capteurs

### Moniteur Série au démarrage

Si tous les capteurs sont bien connectés, tu devrais voir :

```
========================================
Initialisation des capteurs I2C
========================================
I2C initialisé : SDA=GPIO4, SCL=GPIO5

🔍 Détection BMP280/BMP180...
✅ BMP280 détecté à l'adresse 0x76

🔍 Détection BH1750...
✅ BH1750 détecté à l'adresse 0x23

🔍 Détection MPU6050...
✅ MPU6050 détecté à l'adresse 0x68
  Configuration: ±8g, ±500°/s, filtre 21Hz

========================================
📊 LECTURE CAPTEURS:
  Température  : 24.5 °C
  Pression     : 1013.2 hPa
  Altitude     : 12.3 m
  Luminosité   : 523.4 lux
  Accél (X,Y,Z): 0.02, -0.01, 1.00 g
  Gyro (X,Y,Z) : 0.1, -0.2, 0.0 °/s
  Vibration    : 2.3 %
  Atténuation  : 0.23 dB/km
✅ Capteurs initialisés
========================================
```

---

## 🚨 Dépannage

### Aucun capteur détecté

**Symptôme** :
```
⚠️  Aucun BMP180/BMP280 détecté
⚠️  BH1750 non détecté
⚠️  MPU6050 non détecté
```

**Solutions** :
1. ✅ Vérifier le câblage (SDA, SCL, VCC, GND)
2. ✅ Vérifier que les capteurs sont alimentés en **3.3V** (pas 5V !)
3. ✅ Ajouter des **résistances pull-up** sur SDA et SCL (4.7kΩ vers 3.3V)
4. ✅ Scanner les adresses I2C avec un sketch de scan

### Sketch de scan I2C

```cpp
#include <Wire.h>

void setup() {
  Serial.begin(115200);
  Wire.begin(4, 5);  // SDA=GPIO4, SCL=GPIO5
  Serial.println("Scan I2C...");
  
  for (byte addr = 1; addr < 127; addr++) {
    Wire.beginTransmission(addr);
    if (Wire.endTransmission() == 0) {
      Serial.printf("✅ Capteur trouvé à 0x%02X\n", addr);
    }
  }
}

void loop() {}
```

### Adresses I2C communes

| Adresse | Capteur probable |
|---------|------------------|
| `0x23` | BH1750 (ADDR → GND) |
| `0x5C` | BH1750 (ADDR → 3.3V) |
| `0x68` | MPU6050 (AD0 → GND) |
| `0x69` | MPU6050 (AD0 → 3.3V) |
| `0x76` | BMP280/BMP180 |
| `0x77` | BMP280/BMP180 (adresse alternative) |

---

## 📊 Données Envoyées à l'App Android

Le WebSocket envoie les données sous ce format JSON :

```json
{
  "type": "sensors",
  "temperature": 24.5,
  "pressure": 1013.2,
  "altitude": 12.3,
  "luminosity": 523.4,
  "accelerometer": {
    "x": 0.02,
    "y": -0.01,
    "z": 1.00
  },
  "gyroscope": {
    "x": 0.1,
    "y": -0.2,
    "z": 0.0
  },
  "vibration": 2.3,
  "attenuation": 0.23,
  "timestamp": 12345678
}
```

---

## 💡 Utilisation des Données

### BMP180/BMP280 (Température + Pression)
- **Température** : Affecte l'atténuation atmosphérique
- **Pression** : Calcul de l'altitude et de la densité de l'air
- **Usage** : Compenser automatiquement la puissance laser selon conditions

### BH1750 (Luminosité)
- **Mesure** : 0 - 65535 lux
- **Usage** : 
  - Détecter si le soleil affecte le photorécepteur
  - Ajuster la sensibilité du récepteur
  - Alerter si luminosité trop élevée

### MPU6050 (Accéléromètre + Gyroscope)
- **Accéléromètre** : Détecte vibrations et mouvements
- **Gyroscope** : Détecte rotations
- **Vibration** : 0-100% (0 = stable, 100 = vibrations fortes)
- **Usage** :
  - ⚠️ Alerter si vibration > 20% (désalignement probable)
  - 🎯 Déclencher réalignement automatique avec servos
  - 📊 Logging pour analyse de stabilité

---

## ✅ Checklist de Validation

- [ ] Les 3 capteurs sont détectés au démarrage
- [ ] La température affichée est cohérente avec l'environnement
- [ ] La pression est proche de 1013 hPa (niveau de la mer)
- [ ] La luminosité change quand tu allumes/éteins la lumière
- [ ] L'accélération Z est proche de 1.0g (gravité)
- [ ] Secouer l'ESP32 augmente le niveau de vibration
- [ ] Les données sont envoyées via WebSocket toutes les 5s

---

## 🔧 Configuration Avancée

### Modifier les broches I2C

Dans `sensors.cpp` :
```cpp
#define I2C_SDA 4     // ⬅️ Change selon ton câblage
#define I2C_SCL 5     // ⬅️ Change selon ton câblage
```

**Exemples de configurations alternatives :**

| Configuration | SDA | SCL | Utilisation |
|---------------|-----|-----|-------------|
| **Actuelle** | **GPIO 4** | **GPIO 5** | **Ta config ✅** |
| Par défaut HW | GPIO 21 | GPIO 22 | Hardware I2C (plus rapide) |
| Alternative 1 | GPIO 25 | GPIO 26 | Si 4/5 occupés |
| Alternative 2 | GPIO 32 | GPIO 33 | Loin des autres périphériques |
| Alternative 3 | GPIO 16 | GPIO 17 | Si Arduino Serial non utilisé |

**⚠️ Important** : Après changement, mets à jour aussi `i2c_scanner.ino` avec les mêmes GPIO pour tester !

### Modifier la fréquence I2C

Par défaut : 100 kHz (standard)

```cpp
Wire.setClock(100000);   // 100 kHz (standard)
// Wire.setClock(400000);   // 400 kHz (fast mode)
```

### Modifier le seuil de vibration

Dans `detectVibration()` :
```cpp
// Actuellement : 0.1g = 10%, 1.0g = 100%
float vibrationPercent = magnitude * 100.0;

// Pour plus de sensibilité :
float vibrationPercent = magnitude * 200.0;  // 0.5g = 100%
```

---

## 📞 Support

Si tu rencontres des problèmes :
1. Vérifie le moniteur série au démarrage
2. Lance le sketch de scan I2C
3. Vérifie les connexions physiques
4. Assure-toi d'utiliser 3.3V (pas 5V)
