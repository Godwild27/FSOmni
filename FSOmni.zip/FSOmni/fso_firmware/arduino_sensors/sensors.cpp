// ================================================================
// sensors.cpp — Capteurs I2C ULTRA-LÉGER (I2C direct, pas de lib)
// ================================================================

#include "sensors.h"
#include "config.h"
#include <Wire.h>

SensorData currentSensorData = {
  25.0, 1013.25, 0.0, 5000.0,
  0.0, 0.0, 1.0,
  0.0, 0.0, 0.0,
  0.0, 0.0,
  false, 0
};

// Adresses I2C
#define BMP280_ADDR 0x76
#define BH1750_ADDR 0x23
#define MPU6050_ADDR 0x68

bool bmpActive = false;
bool bh1750Active = false;
bool mpuActive = false;

// ================================================================
// I2C Write
// ================================================================
void i2cWrite(uint8_t addr, uint8_t reg, uint8_t val) {
  Wire.beginTransmission(addr);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();
}

// ================================================================
// I2C Read
// ================================================================
uint8_t i2cRead8(uint8_t addr, uint8_t reg) {
  Wire.beginTransmission(addr);
  Wire.write(reg);
  Wire.endTransmission();
  Wire.requestFrom(addr, (uint8_t)1);
  return Wire.read();
}

int16_t i2cRead16(uint8_t addr, uint8_t reg) {
  Wire.beginTransmission(addr);
  Wire.write(reg);
  Wire.endTransmission();
  Wire.requestFrom(addr, (uint8_t)2);
  int16_t val = Wire.read() << 8;
  val |= Wire.read();
  return val;
}

// ================================================================
// BMP280 Init
// ================================================================
void initBMP280() {
  Wire.beginTransmission(BMP280_ADDR);
  if (Wire.endTransmission() == 0) {
    uint8_t id = i2cRead8(BMP280_ADDR, 0xD0);
    if (id == 0x58) {
      i2cWrite(BMP280_ADDR, 0xF4, 0x27); // ctrl_meas: normal mode
      i2cWrite(BMP280_ADDR, 0xF5, 0xA0); // config: 500ms standby
      bmpActive = true;
    }
  }
}

// ================================================================
// BH1750 Init
// ================================================================
void initBH1750() {
  Wire.beginTransmission(BH1750_ADDR);
  if (Wire.endTransmission() == 0) {
    Wire.beginTransmission(BH1750_ADDR);
    Wire.write(0x10); // Continuous H-Res Mode
    Wire.endTransmission();
    bh1750Active = true;
  }
}

// ================================================================
// MPU6050 Init
// ================================================================
void initMPU6050() {
  Wire.beginTransmission(MPU6050_ADDR);
  if (Wire.endTransmission() == 0) {
    i2cWrite(MPU6050_ADDR, 0x6B, 0x00); // Wake up
    i2cWrite(MPU6050_ADDR, 0x1C, 0x10); // Accel ±8g
    i2cWrite(MPU6050_ADDR, 0x1B, 0x08); // Gyro ±500°/s
    mpuActive = true;
  }
}

// ================================================================
// INIT
// ================================================================
void initSensors() {
  Wire.begin();
  Wire.setClock(100000);
  delay(50);
  initBMP280();
  initBH1750();
  initMPU6050();
}

// ================================================================
// Lire BMP280
// ================================================================
void readBMP280() {
  if (!bmpActive) {
    currentSensorData.temperature = 25.0;
    currentSensorData.pressure = 1013.25;
    currentSensorData.altitude = 0.0;
    return;
  }
  
  // Lire température brute
  Wire.beginTransmission(BMP280_ADDR);
  Wire.write(0xFA);
  Wire.endTransmission();
  Wire.requestFrom(BMP280_ADDR, (uint8_t)3);
  int32_t adc_T = ((int32_t)Wire.read() << 12) | ((int32_t)Wire.read() << 4) | (Wire.read() >> 4);
  
  // Lire pression brute
  Wire.beginTransmission(BMP280_ADDR);
  Wire.write(0xF7);
  Wire.endTransmission();
  Wire.requestFrom(BMP280_ADDR, (uint8_t)3);
  int32_t adc_P = ((int32_t)Wire.read() << 12) | ((int32_t)Wire.read() << 4) | (Wire.read() >> 4);
  
  // Conversion simplifiée (sans calibration pour gagner de la place)
  currentSensorData.temperature = (adc_T / 5120.0) - 10.0;
  currentSensorData.pressure = (adc_P / 256.0) / 100.0;
  currentSensorData.altitude = 44330.0 * (1.0 - pow(currentSensorData.pressure / 1013.25, 0.1903));
}

// ================================================================
// Lire BH1750
// ================================================================
void readBH1750() {
  if (!bh1750Active) {
    currentSensorData.luminosity = 5000.0;
    return;
  }
  
  Wire.requestFrom(BH1750_ADDR, (uint8_t)2);
  if (Wire.available() == 2) {
    uint16_t lux = Wire.read() << 8;
    lux |= Wire.read();
    currentSensorData.luminosity = lux / 1.2;
  }
}

// ================================================================
// Lire MPU6050
// ================================================================
void readMPU6050() {
  if (!mpuActive) {
    currentSensorData.accelX = 0.0;
    currentSensorData.accelY = 0.0;
    currentSensorData.accelZ = 1.0;
    currentSensorData.gyroX = 0.0;
    currentSensorData.gyroY = 0.0;
    currentSensorData.gyroZ = 0.0;
    currentSensorData.vibration = 0.0;
    return;
  }
  
  // Lire accéléromètre (6 bytes)
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(0x3B);
  Wire.endTransmission();
  Wire.requestFrom(MPU6050_ADDR, (uint8_t)6);
  
  int16_t ax = (Wire.read() << 8) | Wire.read();
  int16_t ay = (Wire.read() << 8) | Wire.read();
  int16_t az = (Wire.read() << 8) | Wire.read();
  
  currentSensorData.accelX = ax / 4096.0;
  currentSensorData.accelY = ay / 4096.0;
  currentSensorData.accelZ = az / 4096.0;
  
  // Lire gyroscope (6 bytes)
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(0x43);
  Wire.endTransmission();
  Wire.requestFrom(MPU6050_ADDR, (uint8_t)6);
  
  int16_t gx = (Wire.read() << 8) | Wire.read();
  int16_t gy = (Wire.read() << 8) | Wire.read();
  int16_t gz = (Wire.read() << 8) | Wire.read();
  
  currentSensorData.gyroX = gx / 65.5;
  currentSensorData.gyroY = gy / 65.5;
  currentSensorData.gyroZ = gz / 65.5;
  
  // Vibration
  float magnitude = sqrt(currentSensorData.accelX * currentSensorData.accelX + 
                        currentSensorData.accelY * currentSensorData.accelY + 
                        (currentSensorData.accelZ - 1.0) * (currentSensorData.accelZ - 1.0));
  currentSensorData.vibration = constrain(magnitude * 100.0, 0.0, 100.0);
}

// ================================================================
// LECTURE TOUS CAPTEURS
// ================================================================
void readSensors() {
  readBMP280();
  readBH1750();
  readMPU6050();
  
  // Atténuation
  float temp = currentSensorData.temperature;
  float pressure = currentSensorData.pressure;
  float attenuation = 0.2 * (1.0 + (temp - 20.0) * 0.01) * (1013.25 / pressure);
  currentSensorData.attenuation = constrain(attenuation, 0.1, 5.0);
  
  currentSensorData.timestamp = millis();
  currentSensorData.valid = true;
}
