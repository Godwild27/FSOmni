// ================================================================
// config.h — Configuration Arduino Sensors V2
// ================================================================
// Arduino Uno lit les capteurs I2C à 20 Hz et envoie le résultat
// sur UART (Serial) à l'ESP32 au format JSON.
// ================================================================

#ifndef CONFIG_H
#define CONFIG_H

// ================================================================
// I2C (Arduino Uno : SDA=A4, SCL=A5 — fixé hardware, non modifiable)
// ================================================================
#define I2C_SDA A4
#define I2C_SCL A5
#define I2C_FREQ 100000  // 100 kHz

// ================================================================
// UART
// ================================================================
#define SERIAL_BAUD 115200

// ================================================================
// FRÉQUENCE LECTURE CAPTEURS
// ================================================================
#define SENSOR_READ_INTERVAL_MS 50  // 50 ms = 20 Hz

// ================================================================
// VERSION (pour message "ready" au boot)
// ================================================================
#define FIRMWARE_VERSION "Arduino Sensors V2.0"

#endif
