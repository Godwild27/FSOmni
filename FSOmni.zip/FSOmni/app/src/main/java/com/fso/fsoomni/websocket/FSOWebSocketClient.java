package com.fso.fsoomni.websocket;

import android.util.Log;

import com.fso.fsoomni.model.AppState;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public class FSOWebSocketClient {

    private static final String TAG = "FSOWebSocket";
    private static final int DEFAULT_PORT = 8080;

    private WebSocketClient client;
    private final AppState appState;
    private final Gson gson = new Gson();
    private final Map<String, CopyOnWriteArrayList<WebSocketListener>> listeners = new HashMap<>();
    private int reconnectAttempts = 0;
    private static final int MAX_RECONNECT_ATTEMPTS = 6;
    private static final int BASE_RECONNECT_DELAY_MS = 1000;

    public interface WebSocketListener {
        void onMessage(String type, JsonObject data);
        void onConnected();
        void onDisconnected();
        void onError(String error);
    }

    public FSOWebSocketClient(AppState appState) {
        this.appState = appState;
    }

    public void addListener(WebSocketListener listener) {
        addListener("*", listener);
    }

    public void addListener(String eventType, WebSocketListener listener) {
        if (!listeners.containsKey(eventType)) {
            listeners.put(eventType, new CopyOnWriteArrayList<>());
        }
        listeners.get(eventType).add(listener);
    }

    public void removeListener(WebSocketListener listener) {
        for (Map.Entry<String, CopyOnWriteArrayList<WebSocketListener>> entry : listeners.entrySet()) {
            entry.getValue().remove(listener);
        }
    }

    private void notifyMessage(String type, JsonObject data) {
        // Notify wildcard listeners
        if (listeners.containsKey("*")) {
            for (WebSocketListener l : listeners.get("*")) {
                l.onMessage(type, data);
            }
        }
        // Notify specific type listeners
        if (listeners.containsKey(type)) {
            for (WebSocketListener l : listeners.get(type)) {
                l.onMessage(type, data);
            }
        }
    }

    private void notifyConnected() {
        for (CopyOnWriteArrayList<WebSocketListener> list : listeners.values()) {
            for (WebSocketListener l : list) {
                l.onConnected();
            }
        }
    }

    private void notifyDisconnected() {
        for (CopyOnWriteArrayList<WebSocketListener> list : listeners.values()) {
            for (WebSocketListener l : list) {
                l.onDisconnected();
            }
        }
    }

    private void notifyError(String error) {
        for (CopyOnWriteArrayList<WebSocketListener> list : listeners.values()) {
            for (WebSocketListener l : list) {
                l.onError(error);
            }
        }
    }

    public void connect(String ip) {
        disconnect();

        try {
            String url = "ws://" + ip + ":" + DEFAULT_PORT;
            URI uri = new URI(url);
            
            Log.d(TAG, "Attempting WebSocket connection to: " + url);

            client = new WebSocketClient(uri) {
                @Override
                public void onOpen(ServerHandshake handshake) {
                    Log.d(TAG, "✅ WebSocket connected successfully to " + url);
                    Log.d(TAG, "Server handshake: HTTP " + handshake.getHttpStatus() + " - " + handshake.getHttpStatusMessage());
                    reconnectAttempts = 0;
                    appState.setConnected(true);
                    notifyConnected();
                }

                @Override
                public void onMessage(String message) {
                    Log.d(TAG, "📩 Message received: " + message);
                    try {
                        JsonObject json = JsonParser.parseString(message).getAsJsonObject();
                        String type = json.has("type") ? json.get("type").getAsString() : "unknown";
                        processMessage(type, json);
                        notifyMessage(type, json);
                    } catch (Exception e) {
                        Log.e(TAG, "❌ Error parsing message: " + e.getMessage(), e);
                    }
                }

                @Override
                public void onClose(int code, String reason, boolean remote) {
                    String remoteStr = remote ? "remote" : "local";
                    Log.d(TAG, "🔌 WebSocket closed (" + remoteStr + "). Code: " + code + ", Reason: " + reason);
                    
                    // Log détaillé pour diagnostiquer les déconnexions
                    if (remote) {
                        Log.w(TAG, "⚠️ Serveur a fermé la connexion. Code: " + code);
                        if (code == 1000) Log.d(TAG, "   Raison: Fermeture normale");
                        else if (code == 1001) Log.d(TAG, "   Raison: Endpoint parti (navigateur fermé)");
                        else if (code == 1006) Log.w(TAG, "   Raison: Connexion perdue anormalement (timeout/réseau)");
                        else Log.w(TAG, "   Raison inconnue: " + code);
                    }
                    
                    appState.setConnected(false);
                    notifyDisconnected();
                    
                    // Only attempt reconnect if closed by remote
                    if (remote && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
                        attemptReconnect(ip);
                    }
                }

                @Override
                public void onError(Exception ex) {
                    Log.e(TAG, "❌ WebSocket error: " + ex.getMessage(), ex);
                    appState.setConnected(false);
                    
                    String errorMsg = ex.getMessage();
                    if (errorMsg == null) {
                        errorMsg = "Erreur de connexion inconnue";
                    } else if (errorMsg.contains("failed to connect")) {
                        errorMsg = "Impossible de se connecter au serveur";
                    } else if (errorMsg.contains("Connection refused")) {
                        errorMsg = "Connexion refusée - Vérifiez que le serveur est démarré";
                    } else if (errorMsg.contains("timeout")) {
                        errorMsg = "Timeout - Le serveur ne répond pas";
                    } else if (errorMsg.contains("Network is unreachable")) {
                        errorMsg = "Réseau inaccessible - Vérifiez votre connexion WiFi";
                    }
                    
                    notifyError(errorMsg);
                }
            };

            // Timeout élevé : une TX laser de 4Ko dure ~80s, il ne faut pas déconnecter pendant
            client.setConnectionLostTimeout(120); // 120 secondes
            
            // Connect in background thread
            new Thread(() -> {
                try {
                    Log.d(TAG, "🔄 Starting WebSocket connection in background thread...");
                    boolean connected = client.connectBlocking();
                    if (!connected) {
                        Log.e(TAG, "❌ WebSocket connectBlocking returned false");
                        notifyError("Échec de la connexion au serveur WebSocket");
                    }
                } catch (Exception e) {
                    Log.e(TAG, "❌ Exception during connectBlocking: " + e.getMessage(), e);
                    notifyError("Erreur : " + e.getMessage());
                }
            }).start();

        } catch (Exception e) {
            Log.e(TAG, "❌ Failed to initialize WebSocket connection: " + e.getMessage(), e);
            notifyError("Erreur d'initialisation : " + e.getMessage());
        }
    }

    public void disconnect() {
        if (client != null) {
            client.close();
            client = null;
        }
        appState.setConnected(false);
        reconnectAttempts = 0;
    }

    private void attemptReconnect(String ip) {
        if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
            Log.w(TAG, "Max reconnect attempts reached");
            return;
        }

        int rawDelay = (int) (BASE_RECONNECT_DELAY_MS * Math.pow(2, reconnectAttempts));
        final int delay = Math.min(rawDelay, 30000); // Cap at 30s

        reconnectAttempts++;
        final int attempt = reconnectAttempts;

        new Thread(() -> {
            try {
                Thread.sleep(delay);
                Log.d(TAG, "Reconnect attempt " + attempt + " after " + delay + "ms");
                connect(ip);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }).start();
    }

    private void processMessage(String type, JsonObject json) {
        // ================================================================
        // ÉTAPE 2 : Gestion des messages laser (type numérique → string "2")
        // ================================================================

        // L'ESP32 envoie type=2 (entier), Gson le lit comme "2" (string)
        if ("2".equals(type)) {
            if (json.has("text")) {
                String receivedText = json.get("text").getAsString();
                Log.d(TAG, "📩 Message laser reçu : " + receivedText);
            }
            return; // Pas besoin du switch ci-dessous
        }

        // tx_started / tx_queued — confirmer sans erreur
        if ("10".equals(type)) {
            String status = json.has("status") ? json.get("status").getAsString() : "";
            Log.d(TAG, "📡 Statut TX : " + status);
            return;
        }

        // Erreur firmware
        if ("99".equals(type)) {
            String msg = json.has("message") ? json.get("message").getAsString() : "Erreur inconnue";
            Log.e(TAG, "❌ Erreur firmware : " + msg);
            notifyError("Erreur laser : " + msg);
            return;
        }

        // ================================================================
        // Traitement des messages de télémétrie (ancien protocole)
        // ================================================================
        switch (type) {
            case "ping":
                // Répondre au ping du serveur pour maintenir la connexion
                com.google.gson.JsonObject pongPayload = new com.google.gson.JsonObject();
                pongPayload.addProperty("timestamp", System.currentTimeMillis());
                sendMessage("pong", pongPayload);
                break;

            case "telemetry":
                if (json.has("throughput")) {
                    appState.setLastThroughput(json.get("throughput").getAsDouble());
                    // Map throughput to bar value (scale 0-20 Mbps to 0-100)
                    int barVal = (int) Math.min(100, Math.max(0, (json.get("throughput").getAsDouble() / 20.0) * 100));
                    appState.pushBarValue(barVal);
                }
                if (json.has("ber")) {
                    appState.setLastBer(json.get("ber").getAsDouble());
                }
                if (json.has("rssi")) {
                    appState.setLastRssi(json.get("rssi").getAsDouble());
                }
                if (json.has("alignment_precision")) {
                    appState.setLastAlignmentPrecision(json.get("alignment_precision").getAsDouble());
                }
                break;

            case "sensors":
            case "weather":  // Backward compatibility
                if (json.has("luminosity")) {
                    appState.setLastLuminosity(json.get("luminosity").getAsDouble());
                }
                if (json.has("attenuation")) {
                    appState.setLastAttenuation(json.get("attenuation").getAsDouble());
                }
                if (json.has("temperature")) {
                    appState.setLastTemperature(json.get("temperature").getAsDouble());
                }
                if (json.has("pressure")) {
                    appState.setLastPressure(json.get("pressure").getAsDouble());
                }
                if (json.has("altitude")) {
                    appState.setLastAltitude(json.get("altitude").getAsDouble());
                }
                if (json.has("vibration")) {
                    appState.setLastVibration(json.get("vibration").getAsDouble());
                }
                // Accéléromètre
                if (json.has("accelerometer")) {
                    JsonObject accel = json.getAsJsonObject("accelerometer");
                    if (accel.has("x")) appState.setLastAccelX(accel.get("x").getAsDouble());
                    if (accel.has("y")) appState.setLastAccelY(accel.get("y").getAsDouble());
                    if (accel.has("z")) appState.setLastAccelZ(accel.get("z").getAsDouble());
                }
                // Gyroscope
                if (json.has("gyroscope")) {
                    JsonObject gyro = json.getAsJsonObject("gyroscope");
                    if (gyro.has("x")) appState.setLastGyroX(gyro.get("x").getAsDouble());
                    if (gyro.has("y")) appState.setLastGyroY(gyro.get("y").getAsDouble());
                    if (gyro.has("z")) appState.setLastGyroZ(gyro.get("z").getAsDouble());
                }
                break;

            case "alignment":
                if (json.has("tilt")) {
                    appState.setServoTilt(json.get("tilt").getAsDouble());
                }
                break;

            case "esp_status":
                if (json.has("temp")) {
                    appState.setEspTemp(json.get("temp").getAsDouble());
                }
                if (json.has("etat")) {
                    appState.setEspEtat(json.get("etat").getAsDouble());
                }
                if (json.has("uptime")) {
                    appState.setEspUptime(json.get("uptime").getAsString());
                }
                break;

            case "channel_status":
                if (json.has("ch1")) {
                    appState.setCh1Status(json.get("ch1").getAsString());
                }
                if (json.has("ch2")) {
                    appState.setCh2Status(json.get("ch2").getAsString());
                }
                if (json.has("ch3")) {
                    appState.setCh3Status(json.get("ch3").getAsString());
                }
                break;

            case "log":
                // Log event - can be displayed in settings
                break;

            case "security_alert":
                // Critical alert
                break;
        }
    }

    public void sendMessage(String type, JsonObject payload) {
        if (client != null && client.isOpen()) {
            JsonObject msg = new JsonObject();
            msg.addProperty("type", type);
            if (payload != null) {
                for (Map.Entry<String, com.google.gson.JsonElement> entry : payload.entrySet()) {
                    msg.add(entry.getKey(), entry.getValue());
                }
            }
            client.send(gson.toJson(msg));
        } else {
            Log.w(TAG, "Cannot send message - WebSocket not connected");
        }
    }

    public void sendServoCommand(String axis, double value) {
        JsonObject payload = new JsonObject();
        payload.addProperty("axis", axis);
        payload.addProperty("value", value);
        sendMessage("servo", payload);
    }

    public void sendTinymlCommand(boolean enabled, int sensitivity, int reactivity) {
        JsonObject payload = new JsonObject();
        payload.addProperty("enabled", enabled);
        payload.addProperty("sensitivity", sensitivity);
        payload.addProperty("reactivity", reactivity);
        sendMessage("tinyml", payload);
    }

    public void sendAutoAlignCommand(boolean enabled) {
        JsonObject payload = new JsonObject();
        payload.addProperty("enabled", enabled);
        sendMessage("auto_align", payload);
    }

    public void sendGainCommand(int value) {
        JsonObject payload = new JsonObject();
        payload.addProperty("value", value);
        sendMessage("gain", payload);
    }

    public void sendChatMessage(String text) {
        JsonObject payload = new JsonObject();
        payload.addProperty("text", text);
        sendMessage("msg_out", payload);
    }

    /**
     * ÉTAPE 2 : Envoyer un message texte via laser (protocole type 2)
     */
    public void sendTextMessage(String text) {
        if (client != null && client.isOpen()) {
            JsonObject msg = new JsonObject();
            msg.addProperty("type", 2);  // MSG_TEXT_MESSAGE
            msg.addProperty("text", text);
            msg.addProperty("length", text.length());
            
            // Ajouter le unit_id si configuré
            int myUnitId = appState.getMyUnitId();
            if (myUnitId > 0) {
                msg.addProperty("unit_id", myUnitId);
            }
            // Si unit_id = 0 (non configuré), on ne l'envoie pas
            
            String jsonStr = gson.toJson(msg);
            client.send(jsonStr);
            Log.d(TAG, "📤 Message texte laser envoyé : " + jsonStr);
        } else {
            Log.w(TAG, "Cannot send text message - WebSocket not connected");
        }
    }

    public boolean isConnected() {
        return client != null && client.isOpen();
    }
}
